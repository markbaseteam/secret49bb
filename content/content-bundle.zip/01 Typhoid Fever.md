---
banner_icon: 📝
tags: flashcards, OS217/IDS
type: Exam
date: 2022-09-17
---
# Personal Questions

Infectious diseases become prevalent when it's ==undiagnosed or not clinically suspected==

Organism causing **Typhoid Fever**::*Salmonella enterica* subspecies enterica serovar typhi

Major agents of **Enteric Fever**
?

