---
type: Exam
tags: THER202, flashcards
date: 2022-10-07
points: 30
---
# Ayuda Questions
[2024] A 28-year-old G1P0 has BP of 150/90, +2 protein in the urine and +2 edema. The drug of choice is:
A. Methyldopa
B. Reserpine
C. Captopril
D. Metoprolol
?
A. Methyldopa

[2024] The following are members of the dihydropyridine class of calcium antagonists, EXCEPT:
A. Nifedipine
B. Felodipine
C. Verapamil
D. Amlodipine
?
C. Verapamil

[2024] Which of the following calcium channel antagonists can be used for tachyarrhythmias?
A. Nifedipine
B. Nitrendipine
C. Felodipine
D. Diltiazem
?
D. Diltiazem

[2024] Which of the following is/are effect/s of beta blockers?
A. Aids in the release of renin
B. They have negative inotropic and chronotropic effects, AND oppose B2 mediated vasodilation
C. They have inotropic and chronotropic effects
D. Oppose B2 mediated vasodilation
?
B. They have negative inotropic and chronotropic effects, AND oppose B2 mediated vasodilation

[2024] What is NOT a treatment of choice for pregnant hypertensive patients?
A. Methyldopa
B. Amlodipine
C. Ramipril
D. Metoprolol
?
C. Ramipril
*Recall that ACEi can cause renal dysgenesis in the offspring*

[2024] Which of the following is the mechanism of action of calcium channel blockers?
A. Binds to the alpha subunit of the calcium channel
B. Binds covalently to alpha receptors
C. Blocks renin production in the JG cells of the kidneys
D. Blocks the beta receptors in vessels and cardiac muscles
?
A. Binds to the alpha subunit of the calcium channel

[2024] A 54-year-old male has been hypertensive for 2 years but has been non-compliant with meds. He suffered an MI three days ago. His BP readings were 140-145/80-90. What is the anti-hypertensive drug of choice for this patient?
A. Amlodipine
B. Prazosin
C. Metoprolol
D. Methyldopa
?
C. Metoprolol
*Beta blockers are the antihypertensive of choice for those who have history of myocardial infarction*

[2024] Beta blockers are indicated in the following conditions:
A. Hypothyroidism
B. Heart Failure
C. Dyslipidemia
D. Hypotension
?
B. Heart Failure

[2024] According to the latest guidelines, what is the drug of choice for hypertensive patients who have diabetic kidney disease?
A. Beta blockers
B. Angiotensin Receptor Blocker
C. Calcium channel blockers
D. Alpha blockers
?
B. Angiotensin Receptor Blocker

[2024] What is the best anti-hypertensive treatment in African American or Caribbean patients?
A. Diuretic
B. Calcium channel blocker
C. ACE inhibitor
D. Beta blocker
?
B. Calcium channel blocker

[2024] Which of the ff. is combined alpha and beta antagonist?
A. Labetolol
B. Propanolol
C. Nadolol
D. Nebivolol
?
A. Labetolol

[2024] In order to appropriately prescribe for an 8-year-old suspected to have Essential hypertension, the following is/are necessary:
A. Case definition of hypertension in children
B. All on the list
C. Recommended treatment according to clinical guidelines
D. Table with normative values of blood pressure for 33children
?
B. All on the list

[2024] A patient is taking amlodipine (a CYP3A substrate) for hypertension and has been having good BP control. He decides to drink grapefruit juice (a CYP3A inhibitor) over the short term. What do you expect with his blood pressure?
A. Decrease
B. No change
C. Increase
?
A. Decrease
*Because the drug is not metabolized, it produces its effects for a longer period thus reducing blood pressure*

[2024] 4 yr old Paul was diagnosed to have non-severe community acquired pneumonia. He has complete vaccinations against Hib. The most common bacterial etiologies of this infection are the following EXCEPT:
A. S. pneumoniae
B. E. coli
C. S. aureus
D. Non-typeable H. influenzae
?
B. E. coli
*Also should include Hib and Klebsiella pneumoniae*

[2024] 4 yr old Paul was diagnosed to have non-severe community acquired pneumonia. He has complete vaccinations against Hib. The total duration of therapy for non-severe pneumonia is:
A. 10 days
B. 14 days
C. 2 days
D. 5 days
?
D. 5 days

[2024] 4 yr old Paul was diagnosed to have non-severe community acquired pneumonia. He has complete vaccinations against Hib. Paul will need to be hospitalized if he develops any of the following EXCEPT:
A. He is highly febrile
B. He is severely dehydrated
C. He develops severe respiratory distress
D. He manifests with seizures
?
A. He is highly febrile
*Bacterial pneumonia usually presents with high grade fever; therefore, it does not necessitate hospitalization unlike choices B, C, and D*

[2024] 4 yr old Paul was diagnosed to have non-severe community acquired pneumonia. He has complete vaccinations against Hib. The drug of choice for Paul is:
A. Oxacillin
B. Ceftazidime
C. Ampicillin
D. Amoxycillin
?
D. Amoxycillin
*Children < 5 y/o with Hib vaccination is prescribed Amoxicillin*

[2024] If a patient has an anaphylactic reaction to beta-lactams, an
alternative antibiotic for the treatment of non-severe pneumonia is:
A. Azithromycin
B. Clindamycin
C. Metronidazole
D. Cefuroxime
?
A. Azithromycin
*Other option is clarithromycin*

[2024] In the treatment of older adults with community acquired
pneumonia (CAP):
A. The antibiotic prescribed has broad spectrum activity
B. The antibiotic prescribed is different from that prescribed in younger adults
C. The antibiotic prescribed is dependent on the mode of excretion from the body
D. The antibiotic prescribed is based on the most likely pathogen causing CAP
?
D. The antibiotic prescribed is based on the most likely pathogen causing CAP

[2024] In the management of community acquired pneumonia, it is recommended that antibiotic treatment should be initiated:
A. As soon as diagnosis is made
A. Chest x-ray evidence of pneumonia
B. After collection of blood and sputum for culture
C. In an older patient with unstable vital signs
?
A. As soon as diagnosis is made
*Best answer according to guidelines*

[2024] Risk factors for severe COVID-19 disease are the following EXCEPT:
A. Allergic Rhinitis
B. Obesity
C. Cancer
D. Age more than 65 years
?
A. Allergic Rhinitis
*Should also include smoking and underlying noncommunicable diseases*

[2024] What antiviral has proven efficacy for MODERATE COVID (based on HPAC Unified algorithm):
A. Hydroxychloroquine
B. Remdesivir
C. Ivermectin
D. None on the list
?
D. None on the list

[2024] Which antibiotic is necessary to treat MODERATE COVID?
A. Cefuroxime
B. Oseltamivir
C. None on the list
D. Ivermectin
?
C. None on the list

[2024] The following are warning signs for patients with moderate COVID,
and the patient must be brought to the medical facility/emergency
room immediately, EXCEPT:
A. Fever and cough
B. Difficulty of breathing
C. Cyanosis
D. Chest pain
?
A. Fever and cough

[2024] What non-pharmacologic management is/are necessary for a confirmed MODERATE COVID Case?
A. Rest and hydration
B. Massage
C. Breathing training
D. Low salt diet
?
A. Rest and hydration

[2023] 47. What diet was best demonstrated to be effective in lowering BP?::DASH Diet

[2023]  What thiazide diuretic is preferred in lowering BP because of its prolonged half life and proven reduction in the risk of CVD?::Chlorthalidone

[2023] Susan has difficult-to-treat hypertension. Her BP readings were 160-170/80-90 mmHg on two antihypertensive medications for the past six months. Her primary care physician decided to maximize her medications. She is presently on four antihypertensive medications and it seemed to be in control with BP readings 130-140/70-75 mmHg. However, two weeks ago, her right big toe became painful and inflamed. Which of the following medications may have caused this?
A. Chlorthalidone
B. Amiloride
C. Triamterene
D. Spironolactone
?
A. Chlorthalidone
*Thiazides are known to increase uric acid levels and predisposes to development of gout. Amiloride ADRs include anemia, hyperkalemia, and neutropenia. Triamterene is associated with hyperK, arrhythmia, and anaphylaxis. Spironolactone is linked to anaphylaxis, SJS, TEN, and renal failure*

[2023] What electrolyte would you monitor when your patient is using an ACE inhibitor?
A. Sodium
B. Potassium
C. Uric Acid
D. Calcium
?
B. Potassium
*ACEi and ARBs are known to cause hyperK.*

[2023] Common ADR of ARB::Angioedema

[2023] Which of the following classes of drug should NOT be combined with an ACE-inhibitor?
A. Calcium channel blocker
B. Direct renin inhibitor
C. Loop diuretic
D. Thiazide diuretic
?
B. Direct renin inhibitor

[2023] Which of the following drugs should NOT be combined with beta blockers because of increased risk of bradycardia and heart block?
A. Verapamil
B. Nicardipine
C. Felodipine
D. Amlodipine
?
A. Verapamil
*Non-DHP CCBs block tachycardias in Calcium-dependent cells which slows down HR*

[2023] Allan, who was diagnosed with congestive heart failure, started to experience difficulty breathing and paroxysmal nocturnal dyspnea. On physical exam, his BP was 140/80 and chest PE showed inspiratory fine crackles on bibasal lung fields. This drug class is the preferred diuretic in patients with symptomatic heart failure?
A. Thiazide diuretic
B. Potassium sparing diuretic
C. Loop diuretic
D. All of these
?
C. Loop diuretic
*Loop diuretics are more effective and the mainstay for heart failure*

[2023] This drug is considered first line treatment in hypertensive patients with ischemic heart disease or failure::Beta blockers

[2023] This is a direct renin inhibitor:
A. Minoxidil
B. Guanfacine
C. Milrinone
D. Aliskiren
?
D. Aliskiren
*Inhibits the action of conversion of angiotensinogen to angiotensin I* 

[2023] The following drug is not recommended for adult low risk CAP with a stable comorbidity:
A. Azithromycin
B. Amoxicillin
C. Clarithromycin
D. Clindamycin
?
D. Clindamycin
*Clindamycin is often used for staphylococcus infections*

[2023] The following statement is correct regarding the antibiotic resistance pattern of S. pneumoniae in the Philippines?
A. Penicillin resistance reflects that of other countries with more than 30% resistance
B. Co-trimoxazole resistance has decreased since 2004
C. Has low resistance for Penicillin at 1%
D. Chloramphenicol has very high resistance and should never be used
?
C. Has low resistance for Penicillin at 1%
*Specifically for NM and Oral preparations only*

[2023] Which is the most appropriate drug for the treatment of adult low-risk CAP in a patient with a stable medical comorbidity?
A. Ceftazidime
B. Trimethoprim-Sulfamethoxazole
C. Amoxicillin-clavulanate
D. Cefpirome
?
C. Amoxicillin-clavulanate
*A and D are IV cephalosporins*

[2023] Which of the following inhibits bacterial DNA gyrase made in high concentrations of its active stereoisomer and has broad spectrum of activity to cover against pneumococcus and pseudomonas?
A. Aztreonam
B. Minocycline
C. Neomycin
D. Levofloxacin
?
D. Levofloxacin
*Only fluoroquinolone of the choices which inhibits DNA gyrase*

[2023] 2nd Generation Cephalosporin that is the least suitable for low risk CAP?::Cefoxitin (*IV option unlike Cefuroxime and Cefaclor*)

[2023] Which of the following drugs can cover for atypical organisms?
A. Amoxicillin
B. Linezolid
C. Azithromycin
D. Clindamycin
?
C. Azithromycin

[2023] Which of the following drugs is a logical choice for individuals with low risk CAP without stable comorbidities and who are allergic to penicillins and cephalosporins?
A. Amoxicillin
B. Clindamycin
C. Tetracycline
D. Clarithromycin
?
D. Clarithromycin

[2023] True statement about the use of Penicillins for community acquired pneumonia in adults:
A. High incidence of penicillin resistant pneumococci decreases its utility
B. It may be used to cover for Mycoplasma, Chlamydia, and Legionella
C. Amoxicillin covers for Streptococcus pneumoniae and H. influenzae
D. It is considered highly toxic to humans and is not recommended.
?
C. Amoxicillin covers for Streptococcus pneumoniae and H. influenzae

[2023] This drug is flagged with relative contraindications due to its effect on QT prolongation:
A. Amoxicillin-clavulanate
B. Cefixime
C. Clarithromycin
D. Cefuroxime
?
C. Clarithromycin
*Macrolides and quinolones have small chance for QT elongation*

[2023] Which of the following is the least recommended drug for adult low-risk CAP due to high rates of resistance to it?::Cotrimoxazole

[2023] Drug associated with QTc prolongation and Achilles tendon rupture
A. Erythromycin
B. Cotrimoxazole
C. Levofloxacin
D. Clindamycin
?
C. Levofloxacin
*Fluoroqunolones prolong QTc interval and causes tendinitis that risk tendon rupture*

[2023] When treating low risk adult pneumococcal CAP in an individual with a stable comorbidity, the recommended duration of treatment using cefuroxime together with azithromycin is
A. 5-7 days
B. 3-5 days
C. 7-10 days
D. 1-3 days
?
B. 3-5 days
*The addition of Azithromycin shortens the time of using antibiotics*

---
# Personal Questions
Refers to people whose BP do not dip during nighttime or sleeping and are at higher risk for cardiovascular disease::Non-dippers

When can hypertension be diagnosed without multiple measurements?
?
- Hypertensive emergencies (≥160/80 mmHg)
- End-organ damage

What is the therapeutic and target BP threshold for elderly?::150 mmHg is the therapeutic threshold while the target BP is < 140/90 due to stiffening of arteries

Contraindications for Beta blockers (4)
?
- Unstable congestive heart failure
- Asthma
- COPD
- Heart blocks

Top 3 antibiotics that S. pneumoniae are resistant to in the Philippines
?
- Cotrimoxazole
- Tetracycline
- Penicillin (M)

Top 3 antibiotics that H. influenzae are resistant to in PH
?
- Cotrimoxazole
-  Tetracycline
- Ampicillin

Currently preferred agents for pneumonia::Beta lactam with beta lactamase inihibitors

Recommended duration of treatment for low to moderate risk CAP::5 days (if afebrile within 48 hours and with normal vital signs)

Pharmacotherapy for low risk CAP with stable comorbidity
?
- Co-amoxiclav 1 g PO BID / Cefuroxime axetil 500 mg PO BID ±
- Azithromycin 500 mg PO daily / Clarithromycin 500 mg PO BID

Pharmacotherapy for Moderate Risk CAP
?
- Ampicillin-sulbactam 1.5g IV q6 / Cefuroxime sodium 1.5g IV q8 / Ceftriazone 2g IV q24 +
- Azithromycin 500 mg PO daily / Clarithromycin 500 mg PO BID / Levofloxacin 750 mg PO daily

Pharmacotherapy for High Risk CAP with no risk for Pseudomonas aeruginosa
?
- Ceftriaxone 2g IV q24 / Ertapenem 1g IV q24 +
- Azithromycin 500 mg IV daily or Levofloxacin 750 mg IV daily

Pharmacotherapy for High Risk CAP at risk for Pseudomonas aeruginosa
?
- Piperacillin-Tazobactan 4.5 g IV q6 / Cefepime 2 g IV q8-12 / Meropenem 1g IV q8 +
- Azithromycin 500 mg IV daily

Indications for Empiric Therapy for CAP in children
?
- Clinical signs and symptoms of PCAP with ≥1 of the ff
	- Elevated WBC
	- Elevated CRP
	- Elevated Procalcitonin
	- Imaging findings
		- Alveolar infiltrates on CXR 
		- Unilateral solitary lung consolidation, air bronchograms, or pleural effusion on lung ultrasound

Management for non-severe PCAP
?
Amoxicillin trihydrate 40-50 mkd q8 for 7d or 80-90 q12 for 5-7 d

Management for non-severe PCAP involving penicillin resistant S. pneumoniae or beta lactamase producing H. influenzae
?
Amoxicillin clavulanate 80-90 mkd q12 for 5-7d or Cefuroxime 20-30 mkd q12 for 7d for those with *high level of penicillin-resistant pneumococci or beta-lactamase producing H. influenzae*

Management for severe PCAP with Hib vaccination
?
Pen G 200,000 units/kg/d q6

Management for severe PCAP with no, incomplete, or unknown Hib vaccination status
?
Ampicillin 200 mkd q6 if no, incomplete, or unknown Hib vaccination status

Management for severe PCAP with pencilllin-resistant pneumococci or beta lactamase producing H. influenzae
?
- Cefuroxime 100-150 mkd q8 
- Ceftriaxone 75-100 mkd q12-24 
- Ampicillin-Sulbactam 200 mkd q6

Management for severe PCAP with suspected Staphylococcal infection from clinical findings or CXR
?
Clindamycin 20-40 mkd q6-8

Management for severe PCAP with life-threatening conditions like Sepsis or Shock
?
Vancomycin 40-60 mkd q6-8



