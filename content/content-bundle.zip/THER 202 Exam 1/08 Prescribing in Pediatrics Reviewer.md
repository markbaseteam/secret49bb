---
type: Exam
date: 2022-10-07
tags: THER202, flashcards
points: 5
---
# Ayuda Questions
[2024] How many mL of Cefuroxime per dose should a 30 kg child take if the recommended dose is 20 mg/kg/day in two divided doses (Preparation: 250 mg/5ml)?
A. 6 ml
B. 3 ml
C. 10 ml
D. 12 ml
?
A. 6 ml

[2024] Which of the following can lead to medication adherence in children?
A. Practical and convenient drug dosage form
B. Corporal punishment if child refuses the drug
C. Giving tablet instead of syrup
D. Letting the child decide whether to take the medication or not
?
A. Practical and convenient drug dosage form

[2024] An 18-kg-child with fever will need how many mL of Paracetamol if the only preparation available is 250 mg/5 ml? (Dose is 10-15 mg/kg/dose every 4-6 hours):
A. 1.8
B. 0.8-1.25
C. 3
D. 5
?
D. 5

[2024] A 15-year-old child weighing 85 kg was diagnosed to have atypical pneumonia. A doctor decided to give Azithromycin. This drug is normally given to adults as 500 mg/tablet 1 tablet once a day for 3 days. The dose for children is 10 mg/kg/day once a day for 3 days. The doctor will be correct in prescribing which of the following dosing regimen:
A. 500 mg/tablet 1 tablet once a day for 3 days
B. 500 mg/tablet 1.7 tablet once a day for 3 days
C. 200 mg/5 ml 10 ml once a day for 3 days
D. 200 mg/5 ml 21.25 ml once a day for 3 days
?
A. 500 mg/tablet 1 tablet once a day for 3 days
*The patient is already an adolescent who can handle tablets*

[2024] True statements which rationalize the use of amoxicillin-clavulanic acid as empiric therapy for urinary tract infections in children EXCEPT:
A. E. coli is the most common pathogen found
B. IV treatment is preferred in treating all patients with UTI
C. Amoxicillin-clavulanic acid has a good safety profile
D. The majority of E.coli cultured in the urine in 2020 is resistant to amoxicillin
?
B. IV treatment is preferred in treating all patients with UTI

[2024] Which of the following is NOT necessary for you to prescribe your chosen P-drug to a 3-year-old child diagnosed to have Pediatric Community Acquired Pneumonia:
A. Dose
B. Weight
C. Available formulation
D. BMI
?
D. BMI

[2024] Which of the following limits the conduct of clinical drug trials in the pediatric population?
A. Impossible regulatory requirements
B. Parental disagreement
C. Need for microassays
D. Rarity of disease
?
D. Rarity of disease

[2024] IV antibiotics are recommended to be shifted to oral antibiotics in the following once the appropriate criteria are met, EXCEPT for:
A. Toddler with lower respiratory tracts infections
B. 24-year old female with urinary tract infections
C. Neonates with bacterial meningitis
D. 10-year old male with skin and soft tissue infections
?
C. Neonates with bacterial meningitis

[2024] Which of the following drugs is paired with the reason for its involvement in tragedies in pediatric pharmacotherapy?
A. Sulfonamide- immature kidney function
B. Thalidomide- increased body water in the fetus
C. All on the list
D. Chloramphenicol- immature drug metabolizing enzyme
?
D. Chloramphenicol- immature drug metabolizing enzyme
*Sulfonamide can cause kernicterus and this is from immature hepatic function not renal.*

[2023] How many mL of cefuroxime per dose should a 20 kg child take if the recommended dose is 20 mg/kg/day in two divided doses (Preparation: 250 mg/5mL)?
A. 2 mL
B. 4 mL
C. 8 mL
D. 10 mL
?
B. 4 mL
$$20 kg\times \frac{20mg}{1kg}=400mg× \frac{5mL}{250mg}=8mL\div2doses=4mL$$

[2023] Which of the following laws gives additional 6 months of marketing exclusivity for drug companies if they conduct studies in children:
A. Pediatric Rule
B. Child Medication Safety Act
C. Generics Act
D. Best Pharmaceuticals for ChIldren Act
?
D. Best Pharmaceuticals for ChIldren Act

[2023] What preparation of Paracetamol will best promote adherence
for a 2 year old (12 kg) child with fever?
A. 100 mg/mL
B. 250 mg/5 mL
C. 500 mg/tablet
D. 120 mg/5 mL
?
A. 100 mg/mL
*For 2 y/o, give the lowest dose that's effective for the shortest period of time.*

[2023] An 18kg child initially diagnosed to have Pneumonia consults for persistent fever. He has been taking prescribed amoxicillin 100 mg/ ml/ 2 ml every 8 hrs for 2 days during the time of consult. If the therapeutic dose of amoxicillin is 30-50 mg/kg/day, is the patient receiving the right dose?
A. Yes
B. No
?
A. Yes
$$100 \frac{mg}{mL}× 2mL  × \frac{24h}{8h}=600 mg \ daily ÷ 18kg=33.33 \frac{mg}{kg} daily$$

---
# Personal Questions
What drug is linked with development of **kernicterus** in neonates?::Sulfondamide 

What drug is linked with development of **Gray Baby Syndrome** in neonates::Chloramphenicol

Why does **chloramphenicol** have intense adverse reactions in neonates?::Immature **hepatic enzymes** does not allow for efficient glucuronidation allowing it to accumulate

==Thalidomide== exposure in the uterus results in ==phocomelia==

In the **pediatric setting**, the most common type of hypertension is ==secondary hypertension from renal parenchymal or renovascular disease==

In the pediatric setting, **urinary tract infections** are most likely from ==structural abnormalities like Vesicoureteral Reflux==

What are limitations in clinical studies for pediatric drugs? (4)
?
- **Ethical** hurdles (informed consent and non-invasiveness)
- **Microassays** are needed (sample volume is smaller)
- **Stratification** of population in ≥5 categories due to differing characteristics per age group
- Difficulty in predicting **long-term effects** during maturation

Act that provides an incentive of **6 months** additional marketing exclusivity for drug companies conducting studies on children:::Best Pharmaceuticals for Children Act of 2002

Off-label drug use of **Ciprofloxacin** in pediatric population::Severe infection and shigellosis (*Recall that Cipro causes arthropathy and cartilage toxicity*)

Off-label drug use for Alprostadil in children::Maintain patency of PDA

What dose should be given if the computed dose for a pediatric patient exceeds the adult dose?::The normal dose for the adult population

Why is dose scaling challenging for pediatric use of drugs?::Linear scaling will not account for **metabolic function and growth** of the patient

==Allometric== scaling provides a more reliable way of dose adjustment for children as it accounts for ==physiologic changes of the body==

==Model-based PK and PD== scaling is a reliable way for pediatric dose adjustment as it accounts for ==disease factors and developmental growth==

What is the most common cause for **medical errors** in prescribing for children?::Dose computation

Elixir:::Drug preparation with *evenly* distributed dissolved molecules (no need to shake)

Suspension:::Drug preparation with *unevenly* distributed dissolved molecules (shake before use)

The **dosing interval** is a function of the drug's ==half life and therapeutic index==

What is the difference between **adherence and compliance**?::Adherence implies an active role by the patient in collaborating with the prescriber while compliance is just following the demands of the prescriber

Factors that affect Adherence (5)
?
- Socioeconomic
- Provider-patient or Healthcare system factors
- Condition-related
- Therapy-related
- Patient-related

