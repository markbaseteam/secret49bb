---
type: Exam
date: 2022-09-28
tags: THER202, flashcards
points: 10
---
# Quiz Questions
Clinical significance of drug interaction is greater when the precipitant drug?
A. Has high protein binding capacity
B. Has high toxic-therapeutic ratio
C. Has narrow therapeutic index
?
A. Has high protein binding capacity
*As the question pertains to a precipitant drug, high protein binding capacity would allow increased levels of the other drug in circulation. Choices B and C is more applicable for the object drug instead*

A counterfeit drug refers to?
A. Medicinal product that contains >80% of active ingredient
B. Unregistered imported drug without prescription
C. Drug containing authorized trademark and trade name
D. Medicinal product with correct ingredient and amount
?
B. Unregistered imported drug without prescription
*Choices A, C, and D are the opposite of the definition of counterfeit drug*

Aim of pharmacovigilance except?
A. Improve patient safety
B. Treat individuals who experienced ADRs
C. Improve public health safety
?
B. Treat individuals who experienced ADRs
*The main concern of pharmacovigilance is prevention not therapy*

A preventable error refers to a medication error wherein?
A. Harm does not occur
B. Harm is observed
C. There is potential harm
D. Considered a near miss
?
B. Harm is observed
*Medication error should occur and eventual harm should be observed. Potential error is that of which a medication error occurs but no harm happens*

The ff. statements is/are true regarding off-label drug use
A. Prescribing drug without license from regulatory agency
B. Prescribing currently available drug for indication approved by FDA
C. Prescribing drug in dosage form for population with no FDA approval
D. AOTA
?
C. Prescribing drug in dosage form for population with no FDA approval
*The drug should be licensed to be considered OLDU. The indication must not be approved by the FDA to be an OLDU*

# Personal Questions
What constitutes a counterfeit drug?
?
- Correct ingredients but not correct **amount**
- Wrong **ingredients**
- No **active** ingredients
- With adulterants or **impurities**, or issue of drug quality
- Deliberate and fraudulent **mislabeling** with respect to identity and/or source (e.g., fake package)
- Unauthorized **trademark**, trade name, or other identification marks or prints
- Drug product refilled in containers by unauthorized **persons**
- Unregistered **imported** drug without prescription
- Drug with **<80**% of active ingredient

What are the domains of rational drug use? (4)
?
- Efficacy
- Safety
- Suitability
- Cost

Why can't pre-clinical trials identify post-treatment effects (5)
?
- Clinical trials involve **small** numbers
- **Concomitant** diseases and drugs are not normally included in study
- **Special** patient groups are not represented
- **Limited periods** of pre-clinical trials cannot identify long term effects
- Clinical trials cannot predict use of drugs in **clinical settings**

Aims of Pharmacovigilance (4)
?
- Improve **patient care and safety** 
- Improve **public health and safety**
- Contribute to **assessment** of benefit, harm, effectiveness, and risk of medicines and **encourage** safe, rational, and effective use
- Promote **understanding, education, and clinical training** on pharmacovigilance and effective communication to public

Types of Medication Errors (5)
?
- Prescribing
- Dispensing
- Medication administration
- Patient adherence
- Transcribing

==Gabapentin== is used off-label for ==alcohol withdrawal syndrome==

==Melatonin== is used off-label for ==sleep problems in children==

==Montelukast== is used off-label for ==COPD==

Subtype of off-label drug use brought about by rare diseases that do not have enough for licensing treatment::Orphan drugs

Reasons for off-label drug use (4)
?
- Drug not studied and approved for **specific populations**
- **Life-threatening/terminal** medical conditions
- Drugs from **drug class** with FDA approval
- Similar pathologic/physiologic functions

Long-term intake of **isoniazid** and **nitrofurantoin** leads to?::Hepatotoxicity
Long term intake of NSAIDs and herbal products containing aristocholic acid results in?::Nephrotoxicity
Neuroleptic agent use is associated with what ADR?::Tardive dyskinesia

Why was cisapride pulled out from the market?::Lead to **ventricular arrhythmia**
Why was unisom pulled out from the market?::CNS depressant effects were advertised to the public and used for self-harm

==Dextrometorphan== is cough medicine that can produce ==dissociative experiences== when taken at high doses

Steps in identifying ADRs (4)
?
1. Identify precipitant and object drug
2. Classify interaction as pharmaceutical, pharmacokinetic, or pharmacodynamic
3. Subclassify effect as additive, synergistic, potentiating, or  antagonistic
4. Perform necessary interventions

High doses of ==gingko biloba== is associated with induction of ==CYP2C9== resulting in development of ADRs to ==thrombolytics like warfarin==

Red flags for possible dangerous drug interactions (5)
?
- Drug has narrow therapeutic index
- Drug is inducer/inhibitor of another drug's metabolism
- Drug affects clearance of another drug
- Drug is highly protein bound
- Drug has low toxic-therapeutic ratio
