---
type: Exam
date: 2022-10-07
tags: THER202, flashcards
points: 5
---
# Ayuda Questions
[2023, 2024] In your Ther 201 research activity, you used an 80% proof lambanog as the solvent to extract the bioactive compounds from your plant of interest. What method of traditional preparation is demonstrated in this scenario?
A. Infusion
B. Poultice
C. Tincture
D. Decoction
?
C. Tincture
*Tinctures are alcohol and water extracts containing active chemicals*

[2024] A 50 year old teacher experiencing itchy and sore throat and occasional dry cough has a number of plants in her backyard. Which among the following preparations would help her with her complaint?
A. Drink boiled bayabas leaves
B. Eat lots of ampalaya
C. Drink a decoction of sambong leaves
D. Drink a tea preparation of ginger rhizome
?
D. Drink a tea preparation of ginger rhizome

[2023, 2024] Philippine traditional medicine EXCEPT:
A. Usually involves the use of medicinal plants
B. Does not include therapeutic massage and use of aromatic oils
C. Includes concept of the humors and the four elements of nature
D. Is not supported by legislation in the Philippines
?
D. Is not supported by legislation in the Philippines

[2023, 2024] Integrative Medicine
A. Cannot be included in the defined skill set of modern-day healers
B. Has no significant role in complicated diseases
C. Is most useful and relevant in primary health care setting
D. Aims to empower patients and transforms both healthcare provider and user
?
D. Aims to empower patients and transforms both healthcare provider and user

[2024] Which of the following pharmacologic agents is derived from herbal products?
A. Aspirin
B. Celecoxib
C. Penicillin
D. Ranitidine
?
A. Aspirin
*Comes from bark of white willow*

[2023] A neighbor complains of dry reddish lesions on the arms, face, hands, and trunk of the body that is itchy. Using your clinical eye, you observe red, annular, scaly patches with central clearing and an active border. Which of the following will you consider giving?
A. Tsaang gubat stems
B. Makabuhay leaves
C. Niyog-niyogan seeds
D. Akapulko leaves
?
D. Akapulko leaves
*Akapulko is registered as an antifungal and the described lesion seems to fit ringworm infection*

[2023] Which of the following pharmacologic agents is derived from herbal products?
A. Loratadine
B. Paclitaxel
C. Ranitidine
D. Atorvastatin
?
B. Paclitaxel
*Derived from the Pacific Yew Tree (Taxus brevifolia)*

[2023] Which of the following is true?
1. Sambong (Blumea balsamifera), one of the recognized “Sampung Halamang Gamot”, is used as an anti-urolithiasis because of its ability to inhibit calcium oxalate formation.
2. Reported side effects of Sambong leaf tablets include constipation, epigastric pain, and flatulence
3. The seeds, fruits, leaves, or roots of Niyog-niyogan (Quisqualis indica) have reported anthelmintic activity against Ascaris.
4. Adverse effects of overuse of Niyog-Niyogan include nausea, vomiting, diarrhea, abdominal pain, and unconsciousness.
A. I and II are true
B. I, II, III, and IV are true
C. Only I is true
D. I and III are true
?
B. I, II, III, and IV are true

[2023] You wish to study the antibacterial effect of Plant X that is being used by the albularyo of an indigenous community. Upon talking with the locals, you learn that they use decoctions of Plant X as a wash and that this has been effective for them. Given this, what would you expect to be the properties of the active compound?
A. Heat stable and water soluble
B. Heat stable and lipid soluble
C. Heat labile and water soluble
D. Heat labile and lipid soluble
?
A. Heat stable and water soluble
*Decoctions involve boiling over a long period of time using plants that have water-soluble chemicals*

[2023] A 77/male with difficulty and pain when urinating was diagnosed to have kidney stones. According to the doctor, surgery is not yet needed, but he must be closely monitored and perform lifestyle changes. He was advised to take a diuretic medicine, drink plenty of water, and prevent eating salty food. However, the patient asked if there are any alternatives in the medicine that was prescribed. Which among the following would be best for him?
A. Drink boiled bayabas leaves
B. Drink a decoction of sambong leaves
C. Drink a tea preparation of ginger rhizome
D. Eat a lot of ampalaya
?
B. Drink a decoction of sambong leaves
*Sambong is used as a diuretic for edema or urolithiasis*

---
# Personal Questions
Key Differences of Herbal Products from Conventional Drugs (3)
?
- Long term use of herbs does not assure favorable **risk:benefit ratio**
- **PK** is not absolutely required for use
- Dosing regimens are extrapolated from **traditional use** and from pharmacologically active concentrations in vivo

Similarities between Herbal and Synthetic Medicine (3)
?
- **Efficacy, safety, and toxicity** are evaluated
- Undergo pre-clinical and clinical **trials**
- Both have herb-herb and herb-drug **interactions**

==Aspirin== is derived from the ==bark of white willow== and used for ==fever, pain, inflammation, and [[Thrombosis]]==

==Oseltamivir== is derived from ==star anise== and used for ==influenza A and B==

==Atropine== is derived from Belladonna and acts as an ==antidote for cholinergic drug or organophosphate overdose and for bradycardia==

==Tiotropium== is derived from Belladonna and used for ==bronchospasms, COPD, and asthma==

==Metformin== is derived from ==French Lilac== and used for ==type 2 DM==

==Artemether== is derived from ==Qinghasu== and used for ==chloroquine-resistant Plasmodium falciparum infection==

==Sodium chromoglycate== is derived from ==Khellin or Khella== and is used for ==asthma, allergic conjunctivitis, and allergic rhinitis==

==Quinines== are derived from ==Cinchona bark== and is used for ==plasmodium infections==


==Herbal food supplements== are herbal products classified by the FDA as a ==food product== registered with an ==FR== number containing ≥1 of the ff: ==vitamins, minerals, herbs, amino acids, or dietary substances== and is used to ==increase total daily intake of its components==

==Traditionally used herb products== are herbal drugs registered under a ==THPR== number and refer to ==preparations from plant materials whose claim is based only on experience of long usage (≥5 decades)==

Requirements for FDA registration of traditionally used herbal products (3)
?
- Documented **prolonged and permanent** uneventful use
- Absence of unsuspected potential for systemic **toxicity, carcinogenicity, and teratogenicity**
- Evidence based on **medical or pharmaceutical literature**

==Herbal medicines== refer to finished labeled medicinal herb products containing plants or plant material as its active ingredient registered under ==HMR== number with ==specific therapeutic claim/s==

==Infusion== preparation is done for ==delicate herbs, leaves, and fresh tender plants== and is done ==similar to tea where boiled water is poured over the herbs and allowed to steep==

==Decoction== preparation is the method of choice for ==tough or fibrous plants, barks, roots, or water-soluble chemical containing material== involving ==boiling of water until the material begins to soften to release its active constituents==

==Tincture== preparation refers to an ==alcohol and water extract== used for plants that have ==active chemicals that are not very soluble in water==

==Maceration== preparation is the easiest method wherein ==fresh/dried plant is simply covered in cold water and soaked overnight then strained== and is used in plants that are ==very tender, fresh, or those with delicate chemicals that is heat labile and denatured by alcohol==

==Poultice and Compress== preparations can be applied directly to skin for topical pain relief prepared by ==chewing leaves, meshing by hand, or using mortar and pestle==

Indications for Lagundi
?
- Asthma
- Colds
- Fever
- Dysentery
- Pain
- Skin disease
- Headache
- Rheumatism
- Sprain
- Contusion
- Insect Bite

Indications for Yerba Buena
?
- Pain (headache or stomachache)
- Rheumatism
- Arthritis
- Coughs and colds
- Swollen gums
- Toothache
- Menstrual and Gas Pain
- Nausea and Fainting
- Insect Bites
- Pruritis

Indications for Sambong
?
- Edema
- Diuresis
- Urolithiasis
- Diarrhea

Indications for Tsaang Gubat
?
- Diarrhea
- Stomachache

Indications for Niyug-niyogan::Anti-helmintic 

Indications for Bayabas/Guava
?
- Wound cleaning
- Diarrhea
- Toothache

Indications for Akapulko
?
*Antifungal*
- Tinea flava
- Ringworm
- Athlete's foot
- Scabies

Indications for Ulasimang Bato::Elevated uric acid (rheumatism and gout)

Indications for garlic
?
- Hypertension
- Toothache

Indication for Ampalaya::Diabetes Mellitus