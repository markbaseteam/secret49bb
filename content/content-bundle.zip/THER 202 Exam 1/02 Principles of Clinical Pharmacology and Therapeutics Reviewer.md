---
type: Exam
date: 2022-09-28
tags: THER202, flashcards
points: 10
---
# Quiz Questions
Which of the ff. is not a factor in bioavailability?
A. Renal metabolism
B. Intestinal wall metabolism
C. Liver metabolism
D. Absorption
?
A. Renal metabolism
*Bioavailability refers to the fraction of unchanged drug reaching systemic circulation following administration. Renal metabolism is not a factor because it has reached systemic circulation at that point.*

In the log dose-effect curve, adding a competitive antagonist will?::Shift the curve parallel to the right

Which of the ff. will not affect half-life?
A. Plasma protein binding
B. Elimination rate constant
C. Dose
D. Volume of distribution
?
C. Dose
*The dose will not affect the half-life as it is the time needed to reduced the amount of drug in the body by half (no matter what dose is given)*

Which property promotes good drug absorption?
A. Polar drug
B. Large molecule
C. Lipid soluble
D. Ionized drug
?
C. Lipid soluble

Which process is not part of disposition?::Absorption (Disposition = Distribution + Elimination = DME)

# Personal Questions
==Arithmetic== scale dose-response curve is ==hyperbolic== in shape asymptotic to the ==Emax==

==Log== scale dose-response curve is ==sigmoidal== in shape with a ==linear== portion 

EC50/ED50:::Concentration/Dose producing 50% of maximal response
Emax:::Maximal effect produced by drug (measures **efficacy**)
Efficacy (Intrinsic Activity):::Ability of *bound* drug to change receptor in a way that **produces effect**
Kd:::Concentration of drug such that it occupies 50% of total number of receptors at equilibrium
Drug Potency:::Amount of drug needed to produce desired effect

**Drug potency** is determined by ==affinity and efficacy==

==Spare receptors== allow for **maximal response** without total receptor occupancy resulting in increased ==sensitivity==  of the system

Which receptor has the fastest response time?::Ion channel receptors
Which receptor has the slowest response time::Intracellular receptors

**Agonists** tend to ==downregulate== receptors over time resulting in ==tolerance==

**Antagonists** tend to ==upregulate== receptors over time resulting in ==withdrawal rebound effect==

**Elimination** is ==metabolism and excretion==

What drugs are better absorbed by the body?
?
- Non-ionized
- Small molecules
- Lipid-soluble 

Factors affecting distribution of drugs
?
- Ionization
- Capillary permeability
- Blood flow
- Plasma protein binding

One Compartment Approach:::The body is a single process where drug distribution is instantaneous and even

Multicompartment Approach:::The body is divided into a central (blood flow) compartment and peripheral compartment (w/o blood flow) where drug distribution is instantaneous and even within a compartment and there is an equilibrium maintained between compartments

Phase I metabolic reactions
??
- Oxidation
- Reduction
- Hydrolysis

Phase I metabolic reactions produce ==more polar but not necessarily inactive== forms of the drug and are mediated by ==CYP enzymes==

Phase II metabolic reactions
??
- Glucuronidation
- Sulfation
- Acetylation
- Methylation

Phase II metabolic reactions produce ==polar and inactivated== forms of drugs

Enzyme responsible for metabolizing **isoniazid, procainamide, and caffeine**::N-acetyltransferase 2

Phase III metabolic reactions involve ==transporters==

==P-glycoprotein== is an **efflux pump** that uses ATP with broad substrate specificity that can be found in ==intestines, kidney tubules, brain, liver, bile canaliciuli, placenta, and cancer tissue==

Metabolic ==inhibitors== reduce the elimination rate of substrate drugs such that high doses results in ==toxicity== and includes ==grapefruit juice, Cimetidine, Erythromycin, and Itraconazole==

Metabolic ==inducers== heighten expression of CYP enzymes such that lower than expected levels result in ==treatment failure==, and includes ==rifampin, barbiturates, and St. John's Wort==

==Codeine== is a **prodrug** that is converted to ==Morphine== by the enzyme ==CYP2D6==

The concentration of a drug becomes **negligible** after ==4 to 5== half lives

Clearance:::Volume of drugs processed per unit of time

How is the elimination rate, clearance, and volume of distribution connected?
?
$$k=\frac{CL}{V_D}$$

Formula for Absolute Oral Bioavailability
?
$$F=\frac{AUC_{PO}}{Dose_{PO}}\times \frac{Dose_{IV}}{AUC_{IV}}$$

Formula for Loading Dose
?
$$LD=Target\ Concentration\times V_d$$

Formula for Maintenance Dosing Rate
?
$$Dosing\ rate=Elimination\ rate=CL\times Plasma\ Concentration$$

Formula for Maximum Dosing Interval
?
$$MDI=\frac{ln\left[ \frac{C_{mtc}}{C_{mec}} \right]}{k_e}$$
- mtc is the minimum toxic concentration
- mec is the minimum effective concentration

Steps in formulating a dosing regimen (6)
?
1. Compute daily maintenance dose
2. Compute maximum dosing interval
3. Convert dosing interval to factor of 24 hours
4. List possible options by dividing total daily dose by number of doses in a day
5. Look at possible preparations in market
6. Choose most convenient dose

Measure of Linearity
?
$\frac{AUC}{Dose}$ or $\frac{C_{max}}{Dose}$ is constant

==Phenotyping== is the use of drugs to determine the relationship between ==parent compound and metabolite==

==Genotyping== is the process used for inferring the ==effect of drug concentration== provided that there is a ==phenotype-genotype association==

Preventable Causes of Adverse Reactions (5)
?
- Inappropriate polypharmacy
- Failure to establish and adhere to clear therapeutic goals
- Failure of medical personnel to attribute new signs and symptoms to drug therapy
- Lack of priority given to scientific study of ADR mechanisms
- General ignorance of basic and applied pharmacology and therapeutic principles



