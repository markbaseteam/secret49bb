---
type: Exam
date: 2022-10-07
tags: THER202, flashcards
points: 5
---
# Ayuda Questions
[2023, 2024] How would you classify this prescription according to the generics law?
Rx: Laban Leni-cetamol [Paracetamol] 500 mg/tablet ---- #5
Sig. Take one tablet as needed for fever
?
Erroneous Prescription
*The brand name precedes that of the generic name*

[2023, 2024] What is the correct action of the pharmacist when it comes to erroneous prescriptions?
?
- Fill the prescription
- Keep and report the prescription

[2023, 2024] Which of these physicians is not required to prescribe only drugs which are listed in the Philippine National formulary?
A. A resident physician in PGH
B. A Doctor to the Barrio who practices in Samar
C. The attending physician of a patient who is not a PhilHealth member admitted in the Pay wards of PGH
D. The company physician of the Supreme Court
?
C. The attending physician of a patient who is not a PhilHealth member admitted in the Pay wards of PGH
*All government related institutions are required to use generic naming. Since C is the only one not bound by PhilHealth, it is safe to prescribe drugs not in the PNF*

[2023, 2024] Which of the following statements is true regarding the writing of brand names in the prescription according to the generics law?
A. Brand names should be written in bold letters
B. The brand name should precede the generic name of the drug
C. Writing of brand names is required according to the law
D. Writing of brand names is not required by the law
?
D. Writing of brand names is not required by the law

[2024] The evidence for or against drugs for treatment of specific conditions is dynamic based on updates of clinical researches. In the example of low dose aspirin in the lecture, based on the current evidence should it be prescribed for a 52-year old newly diagnosed woman with Type 2 diabetes with no hypertension or other cardiovascular risk factors?
A. No because there is insufficient evidence of benefit for women with Type 2 DM within her age group.
B. No because there is strong evidence of harm from gastrointestinal bleeding.
C. Yes because she has Type 2 diabetes which imposes increased cardiovascular risks
D. Yes because she is already more than 50 years old
?
A. No because there is insufficient evidence of benefit for women with Type 2 DM within her age group.

[2023] You come across a prescription for an antibiotic with the words “Do not substitute”. What kind of a prescription is this according to the generics law?
A. An impossible prescription
B. A violative prescription
C. An erroneous prescription
D. A correctly written prescription
?
B. A violative prescription
*Do not substitute is an offense against the Generics Act*

[2023] You are a new prescriber and you used an old textbook to make a prescription for an anti-diabetic drug called Rosiglitazone (Avandia) which is no longer registered with the Philippine FDA and has been withdrawn from the market. This is an example of:
A. An erroneous prescription
B. A correctly written prescription
C. A violative prescription
D. An impossible prescription
?
D. An impossible prescription

[2023] Which of these statements regarding the Generics law is true?
A. The law only covers doctors and not dentists
B. It covers biologics and biosimilar drugs like insulin or vaccines
C. It has no penal sanctions
D. A doctor who habitually violates this law can have his license revoked
?
D. A doctor who habitually violates this law can have his license revoked

[2023] Which of these laws has brought down the prices of most medications in the Philippines to levels that are the lowest in Asia?
A. Cheaper Medicines Act of 2008
B. Generics Act of 1988
C. Presidential Executive Order 104 or the Modified Drug Retail Price of 2019
D. None of these
?
D. None of these
*Trick question as PH prices are not the lowest in Asia*

---
# Personal Questions
The **Generics Act of 1988** (RA 6675) is tasked to ==promote, require, and ensure production of adequate supply, distribution, use, and acceptance of medicines identified by their generic names==

Key Implications of the Generics Act in Prescribing Practice (4)
?
- Prominent writing of generic name
- Brand name may be written but is not required and should be in parentheses under the generic name
- Disallows writing of no substitution
- All doctors are encouraged to educate patients on generics and their rights

**Generic drugs** are drug products that are comparable to branded or reference listed drug in terms of ==dosage form, strength, route of administration, quality, performance, characteristics, and intended use==

Pillars of National Drug Policy (5)
?
- Assurance of **safety, efficacy, and usefulness** of pharmaceutical products through quality control
- Promote **rational use** of drugs by health professionals and public
- **Self-reliance** of local pharmaceutical industry
- **Tailored/targeted procurement** of drugs by government
- **People empowerment** to assist exercising informed choices

Sector that had the most resistance against the Generics Act::Private Professional Sector

Who is required to use generic names for drugs? (4)
?
- All government agencies and personnel
- All medical, dental, and veterinary practitioner
- Any organization/company involved in manufacturing, importation, repackaging, marketing, and/or distribution of drugs and medicine
- Drug outlets must inform buyer of all drug products with the same generic name and corresponding price

Drugs under Maximum Drug Retail Pricing (5)
?
- Amolidipine
- Atorvastatin
- Azithromycin
- Cytarabine
- Doxorubicin

What are erroneous prescriptions?
?
- Brand name before generic name
- Generic name in parentheses
- Brand name not in parentheses
- More than 1 drug in a prescription form

What are violative prescriptions?
?
- Generic name not written
- Generic name not legible
- Brand name indicated and instruction of no substitution

What are impossible prescriptions?
?
- Only generic name written but is not legible
- Generic name does not match brand name
- Both generic and brand name not legible
- Drug product not FDA registered