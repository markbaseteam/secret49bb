---
type: Exam
date: 2022-10-07
tags: THER202, flashcards
points: 5
---
# Ayuda Questions
[2024] JS, 34/M, needs a prescription for eye drops. He needs Timoptic 0.5% in his right eye 2x a day. It comes in 5cc bottles. What is the prescription appropriate for JS?
A. R/ Timolol ophthalmic 0.5% solution 5cc/bottle --- #1
    (Timoptic)
    Sig: Place 1 drop in the right eye once a day
B. R/ Timolol ophthalmic solution 0.5% solution 5cc/bot---#1
   (Timoptic)
    Sig: Place 1 gtt in the right eye once a day
C. R/ Timolol ophthalmic solution ----#1
    (Timoptic)
    Sig: Place 1 drop in the R eye once a day
D. Timolol ophthalmic 0.5% solution 5cc/bottle-------#1
    (Timoptic)
     Sig: Place 1 drop in the right eye once a day 
?
D. Timolol ophthalmic 0.5% solution 5cc/bottle-------#1
(Timoptic)
*Sig:* Place 1 drop in the right eye once a day


[2024] SLW, 51/M, suddenly experienced itchiness after taking an antibiotic for cough. You decided to stop the antibiotics and opted to shift the medication into another class of antibiotics. Which is the most appropriate for prescription order for the patient?
A. R/ Ciprofloxacin 500 mg/tab-----#14
    Sig: Take 1 tab twice a day for 14 days
B. R/ Ciprofloxacin 500 mg/tab-----#28
    Sig: Take 1 tab twice a day for 14 days
C. R/ Ciprofloxacin 500 mg/tab-----#28
    Sig: Take 1 tablet twice a day for 14 days
D. R/ Ciprofloxacin 500 mg/tab-----#28
    Sig: Take 1 tab BID for 14 days

[2024] HMG, 3/F, was having watery diarrhea for 2 days. At the clinic, she is awake, alert, not in distress with HR 80 bpm, RR 14, T 36.5. She has slightly dry oral mucosa but good skin turgor. As the attending physician, you prescribed her with ORS for the diarrhea
A. R/ Oral rehydration solution sachet --- #10
    Sig: Mix 1 sachet 1 cup dH2O and let the patient drink the solution after each episode of diarrhea
B. R/ ORS sachet ---#10
    Sig: Mix 1 sachet in 200 mL dH2O after each episode of diarrhea
C. R/ Oral rehydration solution sachet ---- #10
    Sig: Mix 1 sachet in 1 cup distilled water and let the patient drink the solution after each episode of diarrhea
D. R/ Oral rehydration solution sachet ---- #10
    Sig: Mix 1 sachet in 200 mL distilled water after each episode of diarrhea
?
C. R/ Oral rehydration solution sachet ---- #10
    Sig: Mix 1 sachet in 1 cup distilled water and let the patient drink the solution after each episode of diarrhea

[2024] CS, 21/F, is diagnosed to have breast CA. She is undergoing chemo and is on 2nd cycle. She started to vomit every time she undergoes chemo. OTC meds do not work. Her oncologist decided to use Zofran before chemo and asked you to write the prescription. What is the most appropriate order for the patient?
A. R/ Ondansetron 24 mg/tab----#3
    (Zofran)
    Sig: Take 1 tablet 30 minutes before chemotherapy
B. R/ Zofran 24 mg/tab-----#3
    Sig: 1 tab before chemo
C. R/ Ondansetron 24 mg/tab----#3
    Sig: Take 1 tablet 30 minutes before chemotherapy
D. R/ Ondansetron 24 mg/tab----#3
    (Zofran)
    Sig: 1 tab PO 30 min before chemo
?
A. R/ Ondansetron 24 mg/tab----#3
    (Zofran)
    Sig: Take 1 tablet 30 minutes before chemotherapy

[2024] ER, 32/M, was admitted at the ICU for NSTEMI. He underwent PCI with stenting, and has been recuperating well post-procedure. The cardiologist asked you to write a prescription for an antiplatelet as part of his discharge disorders. How will you write the prescription order for RPT?
A. R/ Plavix 75 mg/tab ---- #30
    Sig: Take 1 tablet once a day after a meal
B. R/ Clopidogrel (Plavix) 75 mg/tablet ----- #30
    Sig: Take 1 tablet once a day in the morning after a meal
C. R/ Clopidogrel 75 mg/tab----#30
    Sig: Take 1 tab PO
D. R/ Clopidogrel 75 mg/tab----#30
    Sig: Take 1 tablet once a day after a meal
?
B. R/ Clopidogrel (Plavix) 75 mg/tablet ----- #30
    Sig: Take 1 tablet once a day in the morning after a meal

[2023] This is an instruction from a prescriber to a dispenser
A. Discharge summary
B. Prescription
C. Treatment plans
D. History form
?
B. Prescription

[2023] Which of the ff. is not part of the prescription?
A. Date of prescription
B. Dosage form and total amount
C. Symptoms of the patient
D. Name and strength of the drug
?
C. Symptoms of the patient

[2023] What does S stand for in the prescription
A. Symbol
B. Sigma
C. Signa
D. As directed
?
C. Signa

[2023] We are obligated as physicians to do what in writing prescriptions?
A. To use decimals
B. To write clearly
C. To avoid erasures
D. To use symbols
?
B. To write clearly

[2023] What does R/ mean?::Recipe

[2023] Armand, 6/M, was diagnosed with pneumonia with greenish sputum. You prescribe him with Amoxicillin (Amoxi). It is available in suspension form 250 mg/5mL. You computed and his dose was 5 mL every 8 hours. How will you write the instruction?
A. Sig: 5mL q8
B. Sig: Take 5 mL every 8 hours after a meal for 7 days
C. Sig: Take 2 tsps. every 8 hours after a meal
D. Sig: Take 5 mL q 8 hours after a meal
?
B. Sig: Take 5 mL every 8 hours after a meal for 7 days

[2023] Ricky, 45/M, is hypertensive with highest BP of 145/90. You plan to give him ACEi to lower his BP. Which of the ff. is the write prescription?
A. R/ Captopril 20---#30
    Sig: Take 1 tablet before breakfast
B. R/ Captopril 20 mg/tab----#30
    Sig: 1 tab OD
C. R/ Captopril 20 mg/tab---#30
    Sig: Take 1 tablet once a day before breakfast
D. R/ Captopril 20 mg/tab---#30
    Sig: Take 1 tablet before breakfast to lower BP < 130/80
?
D. R/ Captopril 20 mg/tab---#30
    Sig: Take 1 tablet before breakfast to lower BP < 130/80

[2023] Joseph, 50/M, suddenly experienced toothache. Which of the ff. is the right prescription for NSAID?
A. R/ Ibuprofen 500 mg/tab---#10
    Sig: 1 tab prn
B. R/ Ibuprofen 500 mg/tab---#10
    Sig: Take 1 tablet on a full stomach only if with pain
C. R/ Flanax 500 mg/tab---#10
    Sig: Take 1 tablet on a full stomach only if with pain
D. R/ Ibuprofen 500 mg/tab---#10
    Sig: As needed for pain
?
B. R/ Ibuprofen 500 mg/tab---#10
    Sig: Take 1 tablet on a full stomach only if with pain

[2023] Honey, 60/F, had a stroke 3 months ago. Which of the ff. is th right prescription for Clopidogrel?
A. R/ Plavix 80 mg/tab---#30
    Sig: Take 1 tablet every morning after breakfast
B. R/ Clopidogrel (Plavix) 80 mg/tab---#30
    Sig: Take 1 tablet every morning after breakfast
C. R/ Clopidogrel (Plavix) 80 mg/tab---#30
    Sig: Take 1 tab once a day
D. R/ Clopidogrel (Plavix) 80 mg/tab---#30
    Sig: Take 1 tab OD
?
B. R/ Clopidogrel (Plavix) 80 mg/tab---#30
    Sig: Take 1 tablet every morning after breakfast

[2023] Faith, 28/F, diagnosed to have trichomonas infection. You plan to prescribe her with Metronidazole oral for 10 days. Which of the ff. is the right prescription?
A. Metronidazole 500 mg/tab---#30
    Sig: Take 1 tablet every 8 hours on a full stomach for 10 days
B. R/ Metronidazole---#30
    Sig: 1 tab q8 for 10 days
C. R/ Metronidazole 500 mg/tab---#30
    Sig: Take 1 tablet every 8 hours on a full stomach for 10 days
D. R/ Metronidazole 500 mg/tab---#30
    Sig: Take 1 tablet every 8 hours
?
C. R/ Metronidazole 500 mg/tab---#30
    Sig: Take 1 tablet every 8 hours on a full stomach for 10 days

---
What are prescriptions for? (3)
?
- Treatment plan in **writing**
- Order to **pharmacist** to serve patient's needs
- **Instruction** to patient to behave in certain ways 

Why prescribe correctly? (4)
?
- Ensure **patient** integrity
- Ensure **physician** integrity
- Ensure **successful/optimal** outcome
- Maintain **paper trail** for accountability

Parts of Prescription (5)
?
- Superscription
- Inscription
- Subscription
- Signa
- Physician Information

Contents of the Superscription (3)
?
- Date
- Name, Address, Weight, and Age of Patient
- R/ (Recipe)

Contents of the Inscription (2)
?
- Body of prescription 
- Generic name with amount/strength of drug

What does the subscription of the prescription contain?::Instructions to the pharmacist

What does signa of a prescription contain?
?
- Instruction to patient on how to take prescribed medication
- Labeling instruction to pharmacist

