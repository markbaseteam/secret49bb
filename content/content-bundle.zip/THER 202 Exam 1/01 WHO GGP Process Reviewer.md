---
type: Exam
date: 2022-09-28
tags: THER202, flashcards
points: 5
---
# Quiz Questions
If a patient desires to take a **tablet orally once daily** instead of the syrup form of a drug needing to be taken three times a day orally, this is a consideration based mainly on?
A. Cost
B. Efficacy
C. Safety
D. Suitability
?
D. Suitability
Note that the patient *desires* to shift to the tablet from the syrup thus, it is more suitability compared to the other choices mentioned. Suitability also covers the appropriate route and manner of administration.

The **synthesis and execution** of a pharmacotherapeutic plan in the WHO guide to good prescribing is done by?::Writing the prescription

The following is considered false with regards to **determining the P-drug** using the WHO Guide to good prescribing.
A. The P-drug stands for personalized drug for the patient
B. Cost is the most important determinant of the prescription
C. Safety concerns are to be ranked and frequencies determined
D. Even if the drug analysis for efficacy and safety are below par, analysis is to be continued to determine overall rating of a drug
?
B. Cost is the most important determinant of the prescription
*Cost is not part of the equation but is a considerable side note. Efficacy should be the most important consideration*

That part of verifying the suitability of the P-drug which deals not only with the mechanism of drug action, but also **complemented by the best available clinical data related to the action of the drug** is?::Efficacy

Second step of WHO GGP?::Specify the therapeutic objectives

# Personal Questions
What are the steps of WHO GGP
?
1. Define patient's **problem**
2. Specify therapeutic **objectives**
3. Select **P-drug** based on comparative efficacy, safety, cost, and suitability
4. Start the treatment by writing the correct **prescription**
5. Counsel patient on **appropriate use** of medicine (give information, instructions, and warnings)
6. Make appropriate arrangements for **follow-up** and monitoring

Hows of Good Prescribing (4)
?
- Consult national and international treatment **guidelines**
- Find out **rationale** behind drug selection in guidelines
- Check **appropriateness** for current case
- Use **problem-based, student-centered** learning

What does **defining the patient's problem** entail?
?
Diagnosis and concurrent problems of the patient (may even include comorbidities)

What does **specifying therapeutic objectives** involve?
Specific things that have to be accomplished to rectify the patient's condition

**Concepts** to examine and analyze for any recommended drug or drug class in determining the P-drug (4)
?
- Efficacy
- Safety
- Suitability
- Cost





