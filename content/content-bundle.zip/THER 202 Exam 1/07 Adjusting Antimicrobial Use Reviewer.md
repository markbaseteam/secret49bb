---
type: Exam
date: 2022-10-07
tags: THER202, flashcards
points: 10
---
# Ayuda Questions
[2023, 2024] The following statements are parts of the antimicrobial creed EXCEPT:
A. The broadest spectrum is required always
B. Microbiology guides therapy whenever possible
C. Minimize the duration of therapy
D. Indications should be evidence-based
?
A. The broadest spectrum is required always

[2023, 2024] Advantages of switching from IV to oral conversion of antibiotics include the following EXCEPT:
A. Saves both medical and nursing time
B. Early discharge and reducing the likelihood of hospital-acquired infection
C. Increases patient discomfort and does not improve mobility
D. Reduction in costs
?
C. Increases patient discomfort and does not improve mobility

[2024] Which of the following route of antibiotics is preferred for a 2-week-old neonate with severe infection?
A. Intramuscular
B. Oral
C. Intravenous
D. Rectal
?
C. Intravenous

[2024] IV antibiotics are recommended to be shifted to oral antibiotics when:
A. The patient has a malabsorptive syndrome
B. The patient has repeated episodes of vomiting
C. The patient is clinically improving and may take oral medications
D. The patient is highly febrile
?
C. The patient is clinically improving and may take oral medications

[2024] TRUE of treating infectious diseases:
A. Getting a specimen after the 1st dose of antibiotic is ideal
B. All fevers must be treated with an antimicrobial
C. Guidelines from the United States is always directly applicable to the Philippines
D. Local resistance data is very important
?
D. Local resistance data is very important

[2024] What is a FALSE statement with regards to EMPIRIC Therapy?
A. Should be directed against the most likely pathogens based on the patient's history, physical examination, age of the patient, and local epidemiology
B. Administration of antimicrobials prior to obtaining results from cultures
C. Necessary to be given in life-threatening infections
D. Shifting of antibiotics depending on the culture results
?
D. Shifting of antibiotics depending on the culture results
*This does not applicable as a statement for empiric therapy*

[2024] Responsible use of antibiotics includes the following EXCEPT:
A. Using antibiotics only when necessary
B. Prescribing monotherapy in most cases
C. Administering broad-spectrum antibiotics always to ensure eradication of the organism
D. Being aware of local antimicrobial resistance patterns to guide the selection of empiric therapy
?
C. Administering broad-spectrum antibiotics always to ensure eradication of the organism

[2023] The following are examples of EMPIRIC therapy EXCEPT:
A. Discontinue ceftriaxone and shifting to ciprofloxacin when a UTI is caused by Klebsiella pneumonia was found to be resistant to ceftriaxone
B. Voriconazole started in a patient suspected of having pulmonary aspergillosis
C. Starting ceftazidime plus amikacin was initiated in a patient with febrile neutropenia
D. Amoxicillin-clavulanate started in a patient with presumed community acquired pneumonia
?
A. Discontinue ceftriaxone and shifting to ciprofloxacin when a UTI is caused by Klebsiella pneumonia was found to be resistant to ceftriaxone
*This is an example of definitive therapy*

[2023] True statement on De-escalation therapy:
A. Defined as a change in antibiotic therapy from broad- to a narrower-spectrum agent
B. Cannot be done in culture-negative patients
C. Is defined as shifting from IV to oral with the same spectrum of activity
D. Culture-based de-escalation can increase antibiotic resistance
?
A. Defined as a change in antibiotic therapy from broad- to a narrower-spectrum agent

[2023] IV antibiotics are recommended be shifted to oral antibiotics in the following once the appropriate criteria are met EXCEPT for:
A. Neonates with sepsis
B. Lower respiratory tract infections
C. Urinary tract infections
D. Skin and soft tissue infections
?
A. Neonates with sepsis
*Neonates have erratic and delayed GI drug absorption thus, shifting to oral is not an option*

[2023] Which is the most narrow-spectrum penicillin among the
following:
A. Piperacillin
B. Penicillin
C. Amoxicillin
D. Oxacillin
?
D. Oxacillin
*Oxacillin coverage is only against staph or strep organisms*

[2023] Examples of antibiotic misuse include:
A. Given when they are not needed
B. Self-medication
C. Continued when they are no longer necessary
D. All of these
?
D. All of these
*Others ways include wrong dosing, broad spectrum use, wrong antibiotic given*

[2023] Minnie is a 6-year old who was noted to have several crusted lesions on her right arm. She scratched an insect bite in that area and later developed a low-grade fever. Her physician suspects it is due to S. aureus. She is well enough to be treated as an outpatient. Which penicillin is an appropriate drug to give Minnie?
A. Benzathine penicillin
B. Cloxacillin
C. Gentamicin
D. Piperacillin
?
B. Cloxacillin
*MSSA is the main pathogen for impetigo and the recommended antibiotic is either cloxacillin or oxacillin*

[2023] True of definitive therapy, EXCEPT:
A. Is given to prevent infection after exposure
B. Is started after culture and sensitivity results are known
C. May also result in de-escalation therapy
D. Must ensure drug chosen has penetration into the infected organ
?
A. Is given to prevent infection after exposure

[2023] Important etiologic agents for community acquired bacterial meningitis in a 5-year-old are the following EXCEPT:
A. Streptococcus pneumoniae
B. Neisseria meningitidis
C. Haemophilus influenzae
D. Pseudomonas aeruginosa
?
D. Pseudomonas aeruginosa

---
# Personal Questions
Components of the IMINDME Antimicrobial Creed
?
- Is the antibiotic necessary
- Microbiology guides therapy when possible
- Indications should be evidence-bsaed
- Narrowest spectrum required
- Dosage appropriate to site and type of infection
- Minimize duration of therapy
- Ensure monotherapy in most cases

What is de-escalation therapy?::Change in antibiotics from broad-spectrum to narrower spectrum or from multiple antibiotics to single antibiotic

Advantages of Switch Therapy (Parenteral to Oral Conversion)
?
- Reduced likelihood for hospital-acquired bacteremia and infected IV lines
- More likely to receive antibiotics at correct times and miss fewer doses
- Reduced risk for adverse effects and errors in preparation
- Reduce patient discomfort and enable mobility and possibility for earlier discharge
- Save medical and nursing time
- Reduce treatment costs

Indications for Switch Therapy (COMS)
?
- Clinical improvement
- Oral route not compromised
- Markers showing trend going towards the normal
- Specific indication or deep seated infection not present

Contraindications for Switch Therapy
?
- NPO or cannot use oral route
- Unreliable absorption of oral medication
- Neonate
- Infective endocarditis
- Bacterial meningitis

Why is oral medication not recommended for neonates? (3)
?
- Decreased gastric acid production in first few days of life
- Delayed gastric acid emptying time
- Lack of enzymes that de-esterify orally administered antibiotic esters like Chloramphenicol

How long should the oral therapy last when doing switch therapy?::Give for the remaining time needed to complete the IV regimen

Characteristics of Drugs for use in Switch Therapy
?
- Should target the same etiologic agent (*main consideration*)
- Similar or superior bioavailability
- Equivalent/closely related agent used for IV therapy in spectrum of antimicrobial activity if etiologic agent cannot be identified

Antibiotics with action against Gram-positive cocci 
?
*VPLDT*
- Vancomycin
- Penicillin (Oxacillin and Cloxacillin)
- Linezolid
- Daptomycin 
- Teicoplanin

Antibiotics with targeted activity against gram negative bacteria
?
- Colistin
- Aztreonam

Antibiotics used for atypical pathogens
?
- Macrolides
- Fluoroquinolones

Anti-pseudomonal agents (7)
?
- Cephalosporin (Cefepime and Ceftazidime)
- Piperacillin-Tazobactam
- Carbapenem (Meropenem and Imipenem)
- Ciprofloxacin
- Colistin
- Aztreonam
- Aminoglycoside (Gentamicin, Amikacin, Tobramycin)

Antibiotics for Anaerobes (6)
?
- Co-amoxiclav
- Piperacillin-Tazobactam
- Cefoxitin
- Carbapenem (Meropenem, Imipenem, Ertapenem)
- Metronidazole
- Clindamycin

Penicillin agent with the longest half-life::Benzanthine Penicillin (IM)

Coverage of Natural Penicillins
?
- Strep
- Pneumococcus
- Meningocccus
- Oral anaerboes
- Spirochetes
- Listeria
- Corynebacteria
- Neisseria meningitidis

Anti-staphylococcal penicillins
?
*Officially called Penicillinase-resistant penicillins*
- Methicillin (*recall MRSA*)
- Oxacillin
- Cloxacillin

Unique coverage of Aminopenicillins
?
- Oral anaerobes
- Susceptible H. influenzae

Penicillins with Pseudomonas aeruginosa activity
?
- Carbenicillin
- Ticarcillin
- Piperacillin-Tazobactam

Cephalosporin linked with Kernicterus::Ceftriaxone

Indications for First Generation Cephalosporins
?
Alternative treatment for MSSA or streptococcal skin, bone, joint, and pharyngeal infection

Only second generation cephalosporin with anaerobic coverage::Cefoxitin

Third generation cephalosporin used for meningitis due to its good safety and CSF penetration::Cefotaxime

Most broad-spectrum beta lactam::Carbapenem

Mechanism of Action for Cotrimoxazole
?
- Sulfamethoxazole competitively inhibits dihydrofolic acid synthesis
- Trimetrophrim competitively inhibits synthesis of tetrahydrofolic acid

Indications for Cotrimoxazole
?
- Typhoid fever
- Otitis media
- Sinusitis
- Pneumonia
- Chronic bronchitis exacerbation
- Bone and joint infections
- Pneumocystis carinii pneumonia

Mechanism of Action of Aminoglycosides::Inhibits 30S ribosomal subunit of bacteria

Mechanism of Action of Tetracycline::Inhibits 30S ribosomal subunit of bacteria

**Tetracycline** is the drug of choice for ==cholera, leptospirosis, and atypical pathogens==

Tetracyline increases the metabolism of the ff:
?
- Rifampicin
- Phenytoin
- Phenobarbital
- Carbamazepine

MOA of Macrolides::Binds to 50S ribosomal subunit of bacteria

Macrolides have a lot of drug interactions due to ==its effect on CYP450 enzymes==

MOA of Chloramphenicol::Inhibits transpeptidation by binding to the 50S ribosomal subunit

Chloramphenicol ==palmitate== is the oral preparation with ==greater== bioavailability and is hydrolyzed in the ==small intestines==

Chloramphenicol ==succinate== is the IV form with ==lower== bioavailability and is hydrolyzed in the ==lungs, liver, and kidneys==

Antibiotic linked to development of optic neuritis, bone marrow aplasia, and Grey Baby Syndrome::Chloramphenicol

Most common ADR for clindamycin::Diarrhea

MOA of Linezolid::Prevents the assembly of the 70S ribosomal initiation complex by binding to the interface of the 50S ribosome

Antibiotic that can cause development of Serotonin Syndrome, myelosuppression, and lactic acidosis::Linezolid

==Vancomycin== is a ==natural histamine releaser== thus, a skin test is useless

Antibiotic associated with **red man syndrome** (flushing, hypotension, chills)::Vancomycin

MOA of Quinolones::Inhibit DNA synthesis through action on DNA gyrase and topoisomerase IV

Respiratory Quinolones (3)
?
*Also the third generation quinolones*
- Levofloxacin
- Gatifloxacin
- Moxifloxacin

==Nalidixic Acid== is a quinolone that can cause ==tendinitis, tendon rupture, and prolonged QTc==

