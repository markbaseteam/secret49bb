---
banner_icon: 📝
tags: THER202
type: Exam
date: 2022-10-07
---
```dataview
TABLE 
points as Points
FROM "01_Academics/03 Exam Reviewers/THER 202 Exam 1" AND #flashcards
SORT points desc
```
