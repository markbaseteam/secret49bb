---
type: Exam
date: 2022-10-07
tags: THER202, flashcards
points: 15
---
# Ayuda Questions
[2024] The following are principles of prescribing during pregnancy EXCEPT:
A. Use treatment in the lowest possible dose
B. Assess the benefit and risk to mother and fetus
C. Establish a clear indication
D. Use newer drugs which are better chemically and thus with less side effects
?
D. Use newer drugs which are better chemically and thus with less side effects

[2024] The most commonly prescribed drugs for therapeutic reasons is:
A. Analgesics
B. Gastrointestinal drugs
C. Vitamins
D. Respiratory Drugs
?
B. Gastrointestinal drugs

[2024] A 30 year old woman on oral contraceptive pills was diagnosed to have pulmonary tuberculosis and was advised to go on short course chemotherapy (INH+RIF+PZA+EMB). What needs to be done to the dosage of oral contraceptive pills? (Hint: this is a pharmacokinetic interaction)
A. Decrease
B. Increase
C. No change
?
B. Increase
*Recall that with rifampicin is linked with reduction of plasma estrogen concentrations thus, there is a need to increase OCP dosing*

[2024] A 24-year-old woman diagnosed to have seizure disorder recently found out she is pregnant and plans to discontinue her medications. Which of the following statements are true?
A. The fetal organs are formed during the first trimester, so congenital abnormalities due to drugs may arise more during this time
B. None of her medicines will harm the fetus as they will not cross the placenta
C. Drugs often cause impairment of growth during the first trimester
D. She should not plan to breastfeed whilst taking medicine
?
A. The fetal organs are formed during the first trimester, so congenital abnormalities due to drugs may arise more during this time

[2024] A 32 yo G2P1 seeking consult at 6 weeks for initial prenatal care. Her previous child has spina bifida. How much folate should you prescribe?
A. There is insufficient evidence that folic acid can prevent neural tube defects
B. 40 micrograms per day
C. 400 micrograms per day
D. 4 milligrams per day
?
D. 4 milligrams per day

[2024] T or F. An older patient with normal creatinine level is indicative of normal renal function::False (*eGFR is used to check renal function in geriatric patients*)

[2023, 2024] What is the most important pharmacokinetic parameter to consider in elderly patients?::Clearance

[2024] Which statement describes the change that affects the pharmacokinetics of drugs in older patients:
A. Decrease in glomerular filtration rate with increasing age
B. Decrease in lean body mass and total body water
C. Multiple drug use causing risk for drug-drug interactions
D. Slowing of gastrointestinal motility resulting in slower absorption
?
A. Decrease in glomerular filtration rate with increasing age

[2024] If clearance is decreased by 50%, how will you adjust your
regimen?::Decrease maintenance dose by 50%

[2024] If there are no studies available for a certain hepatically cleared drug, and the patient is Child-Pugh Class C, you should give how many percent of the usual maintenance dose?
?
The drug must not be given
*Class A involves 50% the dose and B is 25% the dose*

[2024] For high extraction ratio drugs, liver cirrhosis can affect?
A. Systematic clearance
B. Both
C. Bioavailability
?
B. Both

[2023] Which of the following antihypertensives has been reported to be associated with congenital hypocalvaria, renal tubular dysgenesis, oligohydramnios, and neonatal hypotension?
A. Magnesium sulfate
B. Clonidine
C. Captopril
D. Sodium nitroprusside
E. Labetalol
?
C. Captopril
*Recall that renal dysgenesis is linked to the administration of ACEi in pregnancy*

[2023] Reproductive outcomes after exposure to toxicants include:
A. Developmental delay
B. Healthy offspring
C. Abortion
D. Abortion AND Developmental delay only
E. All of these
?
E. All of these

[2023] A 24-year old woman is 20 weeks pregnant with her first child. She is complaining of fever and cough with yellowish phlegm for the past 4 days and concerned about the possible effects of Paracetamol and Cefuroxime that you would like to prescribe to her. Which of the following statements is TRUE?
A. The fetal organs are formed during the first trimester, so congenital abnormalities due to drugs are less at the current gestational age
B. Cefuroxime is a category D drug
C. None of her medicines will harm the fetus as the will not cross the placenta
D. She should not breastfeed whilst taking medicine
?
A. The fetal organs are formed during the first trimester, so congenital abnormalities due to drugs are less at the current gestational age
*She is already in her second trimester and birth defects are unlikely to occur at this point*

[2023] The same patient taking Cefuroxime and Paracetamol wants you to elaborate further on the drug classifications in pregnancy. Which of the following statements regarding the old US FDA classification is NOT correct:
a. Human studies have not been performed; animal studies may or may not show risk; potential benefits may justify potential risk
b. Contraindicated in pregnancy
c. Controlled studies showed no fetal risks. Human studies done with possible risk to human fetus and possible animal risk
d. AOTA are correct
?
c. Controlled studies showed no fetal risks. Human studies done with possible risk to human fetus and possible animal risk
*Cefuroxime is category B meaning that animal studies show no evidence of harm to the fetus but there is inadequate studies in pregnant women*

[2023] Changes that occur as maternal adaptation to pregnancy which may affect pharmacodynamics and kinetics is/are:
A. Increased cardiac volume
B. Increased albumin
C. Increased progesterone-activated renal metabolism
D. Increased hepatic metabolism
E. Increased gastrointestinal motility
?
A. Increased cardiac volume
*Pregnant women have decreased albumin, increased progesterone-activated hepatic metabolism, and reduced GI motility*

[2023] Challenges of medication adherence in the pediatric population include which of the following:
A. Palatability of medication
B. Inappropriate route of administration
C. Calculation error
D. Inappropriate measuring device
?
A. Palatability of medication
*Palatability and frequency are the determinants of adherence in the pediatric populations*

[2023] A strategy for preventing pneumonia in older adults:
A. Immunization against influenza
B. Immunization against pneumonia
C. Immunization against influenza and pneumonia
D. Immunization against either influenza or pneumonia
?
C. Immunization against influenza and pneumonia
*All patients ≥60 y/o are recommended to get pneumonia and flu vaccines*

[2023] In the treatment of older adults with community acquired
pneumonia (CAP):
A. The antibiotic prescribed is dependent on how it is absorbed in the body
B. The antibiotic prescribed is different from that prescribed in younger adults
C. The antibiotic prescribed has broad spectrum activity
D. The antibiotic prescribed is based on the most likely pathogen causing CAP
?
D. The antibiotic prescribed is based on the most likely pathogen causing CAP

[2023] The age-related physiologic change that may affect the absorption of a drug:
A. Increased gastrointestinal tract motility
B. Altered pH of gastric contents
C. Dry mouth
D. Faster gastric emptying
?
B. Altered pH of gastric contents
*As the question specifically states absorption, B is the correct answer*

[2023] Aging causes decreased lean body mass and total body water. Prescribing a water-soluble antibiotic will result in which of the following:
A. Decreased clearance
B. Increased volume of distribution
C. Decreased plasma protein binding
D. Higher bioavailability
?
A. Decreased clearance

[2023] A hypothetical drug is eliminated solely by the kidneys. Because of renal dysfunction, the clearance of the drug is decreased by 50% and the volume of distribution is increased by 20%. What happens to the loading dose?
?
The LD is increased by 20% as it is directly proportional to Vd

[2023] A hypothetical drug is eliminated solely by the kidneys. Because of renal dysfunction, the clearance of the drug is decreased by 50% and the volume of distribution is increased by 20%. What happens to the maintenance dose?
?
The MD is decreased by 50% as it is directly proportional to the CL of the drug

[2023] A hypothetical drug is eliminated solely by the kidneys. Because of renal dysfunction, the clearance of the drug is decreased by 50% and the volume of the distribution is increased by 20%. What happens to the half life?
?
Increased by 140%
$$T_{\frac{1}{2}}=\frac{ln 2 \times V_d}{CL}\to \frac{1.2 V_{d}×ln 2}{0.5\times CL}=2.4T_{\frac{1}{2}}\to+140\%$$

[2023] One or more of the following may happen to a high hepatic extraction ratio drug in the presence of a decrease in hepatic function by 70%
A. Volume of distribution is decreased
B. Clearance is decreased; AND Bioavailability is increased
C. Clearance is decreased; AND Volume of distribution is decreased
D. Bioavailability is increased
E. Clearance is decreased
?
D. Bioavailability is increased

---
# Personal Questions
Pre-existing conditions that need attention in pregnancy (6)
?
- Asthma
- Psychiatric illness
- Hematologic problem
- Seizures
- Hypertension
- Diabetes mellitus

What is the leading cause of infant mortality?::Birth defects

Causes of birth defects ranked in descending frequency (4)
?
1. Multifactorial
2. Chromosomal abnormality
3. Environmental
4. Twinning/Multiple births

Parameters that determine susceptibility of fetus to ADRs (4)
?
- Type of drug
- Duration of exposure
- Dosage of exposure
- Status of the mother and the fetus

Period of gestation where the child is most susceptible to teratogens::Embryonic period

When does the neural tube form?::30 days post-conception

When does the heart develop?::4th week AOG (also when the limb buds appear)

Period of gestation where the child is less susceptible to teratogenic effects but may still be susceptible to developmental toxicity::Fetal period

US FDA class ==A== refer to drugs with ==no associated fetal risks== and includes ==prenatal vitamins and thyroid hormones==

US FDA class ==B== refer to drugs with ==fetal that is not demonstrated for human and animal studies== and includes ==Penicillin, Acetaminophen, Insulin, and Nystatin==

US FDA class ==C== refer to drugs with ==possible fetal risk but there are no human studies available for confirmation== and include ==Furosemide, Aspirin, and Chlorpromazine==

US FDA class ==D== refer to drugs with ==evidence of fetal risk but the benefits outweigh the risks== and includes ==Progestin, Diazepam, Corticosteroids, Aspirin, Pethidine, and Tetracycline==

US FDA class ==X== refer to drugs with ==proven fetal risk where the risks outweigh the benefits== and includes ==isotretinoin==

What are the limitations of the US FDA Categories for Pregnancy Drugs? (3)
?
- Drugs in market are not required to be assigned a category until after December 1983
- Outcomes of animal studies cannot be assumed to be applicable for human studies
- Class B and C drugs must be cautiously prescribed as only animal data is available

Antimicrobials to avoid in pregnancy (8)
?
*SAFe Moms Take Really Good Care*
- Sulfonamide
- Aminoglycoside
- Fluoroquinolone
- Metronidazole
- Tetracycline
- Ribavirin
- Griseofulvin
- Chloramphenicol

Why is sulfonamide contraindicated in pregnancy?::Causes kernicterus

Why is aminoglycoside contraindicated in pregnancy?::Has **ototoxic** effects

Why is fluoroquinolone contraindicated in pregnancy?::Causes abnormal **cartilage** development

Why is tetracycline contraindicated in pregnancy?::Causes **teeth discoloration**
When is the trimester of risk for tetracyline?::Second and third trimesters (≥20 weeks AOG)
Teratogenic dosing and length of exposure for tetracyclines::≥1 g daily for 3 days

**Nitrofurantoin** is associated with harm during the ==late (near term or term), during labor and delivery, or when onset of delivery is imminent== as it causes ==hemolytic anemia==

Possible adverse effects of Cotrimoxazole in pregnancy (4)
?
- Cleft palate
- Neural tube defect
- CV abnormality
- Clubfoot

Drugs aside from antimicrobials that are contraindicated in pregnancy (10)
?
*Live TV WARPLAN*
- Live vaccine
- Thalidomide
- Valproic acid
- Warfarin
- ACEi
- Retinoids
- Phenytoin
- Lithium
- Aminopterin (Methotrexate)
- NSAID

Vaccines contraindicated during pregnancy (4)
?
*Mr. M. Pol's Live Yellow Chicken*
- MMR
- Polio
- Yellow Fever
- Chickenpox (Varicella)

Babies exposed to this ==Valproic Acid== present with ==tall forehead, medial eyebrow deficiency, flat nasal bridge, broad nasal root, shallow philtrum, and long upper lip== 

Babies exposed to ==Warfarin== develop ==Di Sala Syndrome== presenting with ==hypoplastic nasal bridge, brachydactyly, pectus carinatum, corpus callosum agenesis, and congenital heart defects==

Babies exposed to ==ACE inhibitors== are at risk for developing ==renal dysgenesis==

ADRs of Retinoids in pregnancy (3)
?
- CNS defects
- Craniofacial defects (microtia, micrognathia, cleft lip and palate)
- Cardiovascular defects (conotruncal and aortic arch defects)

Babies exposed to ==Phenyton== develop ==Fetal Hydrantoin== Syndrome presenting with ==IUGR, microcephaly, hypoplastic nails and distal phalanges, and developmental delay==

Babies exposed to ==lithium== can develop ==Ebstein's anomaly==

ADRs of Aminopterin in pregnancy (4)
?
- Anencephaly
- Meningocoele
- Hydrocephalus
- Cleft lip or palate

Vaccines that can be started postpartum or during lactation
?
- Herpes zoster
- Live attenuated flu vaccine
- MMR
- Varicella
- Smallpox

Antibiotics that can be given in pregnancy (3)
?
- Penicillin
- Cephalosporin
- Erythromycin

Antifungal given during pregnancy::Cotrimazole

Anti-TB drug contraindicated in pregnancy::Pyrazinamide

First-line drugs for nausea and vomiting in pregnancy
?
- Pyridoxine and doxylamine
- Emetrol

Pain relief drugs used during pregnancy
?
- Paracetamol (first-line)
- Ibuprofen
- Naproxen

Drugs of choice for diarrhea in pregnancy (2)
?
- Kaolin
- Pectin

Drugs of choice for hypertensive pregnant patents (3)
?
- Methyldopa
- Hydralazine
- Beta blockers except for Atenolol

**Magnesium sulfate** increases risk for ==fetal and neonatal bone demineralization== from prolonged use but is still recommended for use in ==prevention and treatment of seizures in preeclampsia and eclampsia, neuroprotection at <32 weeks AOG, and short-term prolongation of pregnancy==

==Hydralazine== is associated with risk for ==cleft palate, malformed craniofacial bones, neonatal thrombocytopenia, and lupus==

Blood chemistry changes in pregnancy (4)
?
- Increased number of blood cells
- Increased number of clotting factors
- Increased fibrinolytic activity
- Iron deficiency and anemia

Cardiovascular changes in pregnancy (3)
?
- Tachycardia
- Increased CO, HR, and SV

Respiratory changes in pregnancy (4)
?
- Superior displacement of diaphragm
- Reduced functional reserve capacity

GI changes in pregnancy (2)
?
- Nausea and vomiting
- Heartburn and acidity

Physiologic factors increased in pregnancy
?
- Coagulation factors
- Fibrinogen
- Heart rate
- Cardiac output
- Blood volume
- GFR
- Proteinuria
- RBC mass
- WBC count

Physiologic factors decreased in pregnancy 
?
- Albumin
- Antithrombin III activity
- Systemic vascular resistance
- Hematocrit
- Hemoglobin
- BUN:Creatinine
- Ureteral motility
- Gut motility
- pCO2/HCO3

Pathophysiology of constipation in pregnancy
?
Increased levels of progesterone causes inhibited release of motilin which reduces movement of GIT smooth muscles and there is release of relaxin which causes intestinal gut hypomotility

Pathophysiology of acid reflux in pregnancy
?
Progesterone causes the gastroesophageal valve to relax allowing for gastric acid to go into the esophagus

Constipation in pregnancy usually occurs in ==the first two trimesters==

Morning sickness usually resolves by ==14 weeks== AOG

Heartburn usually occurs in the ==second/third== trimester of pregnancy

Factors that determine placental transfer (6)
?
- Lipid solubility
- Degree of ionization
- Protein binding
- Surface area available for diffusion
- pH
- Molecular weight

Mechanisms of Teratogenesis (6)
?
- Disruption of metabolism of folic acid
- Formation of ROS 
- Maternal conditions affecting the fetus
- Genetic factors of fetus
- Direct alteration of key genetic sequences in embryogenesis
- Paternal factors

Clinical findings that is linked to CAP in elderly (4)
?
- Unexplained deterioration of mental health
- Delirium, disorientation, and weakness
- New onset of recurrent falling and functional decline
- Urinary incontinence (particularly those with dementia)

Most common CAP pathogen for elderly with *comorbidities*::Enteric gram negative bacilli

Factors to consider when prescribing for older populations (4)
?
- Drug allergies
- ADRs and drug-drug interactions
- Comorbidities
- **Physical or cognitive function**

How is renal function measured for elderly patients?::Calculation of eGFR using CKD-EPI (reduced mass and blood flow in elderly means that the serum creatinine is not adequate for assessment)

Guide questions when prescribing new medications to older population (5)
?
- Is medication necessary?
- What are the therapeutic **endpoints**?
- What are the **risks and benefits**?
- Can one medication **treat more than one condition**?
- What is the **administration time** of other medicines being taken by the patient? 

Axioms of prescribing in older populations (3)
?
- One disease, one drug, once a day
- Go low and slow (half usual dosing)
- Fix the can'ts (read, afford, open, remember, swallow)

Formula for Dose Adjustment
?
$$\frac{F_1 Dose_1}{CL_1}=\frac{F_2 Dose_2}{CL_2}$$

Formula for Half-life
?
$$t_{\frac{1}{2}}=\frac{ln2}{k}=\frac{ln2\times V_d}{CL}$$

Formula for Bioavailability
?
$$F= \frac{AUC_{PO}}{Dose_{PO}} \times \frac{Dose_{IV}}{AUC_{IV}}$$

Formula for Maximum Dosing Interval
?
$$MDI=\frac{ln\left[ \frac{C_{mtc}}{C_{mec}} \right]}{k_e}=\frac{ln\left[ \frac{C_{mtc}}{C_{mec}} \right]\times Plasma\ drug\ concentration}{Clearance}$$

In **high extraction ratio** drugs, ==blood flow== is negligible thus, the hepatic clearance is equivalent to ==1==

In **low extraction ratio** drugs, ==intrinsic clearance== is negligible thus, the hepatic clearance is equivalent to the ==blood flow==

Child-Pugh Class A::Dosing recommendation that reduces dose to 50%
Child-Pugh Class B::Dosing recommendation that reduces dose to 25%
Child-Pugh Class C::Drug is not affected by liver disease or TDM

