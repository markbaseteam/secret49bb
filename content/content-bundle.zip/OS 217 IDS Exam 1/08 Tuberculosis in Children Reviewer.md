---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[08 Tuberculosis in Children]]

[2023, 2024] Child has significant contact with adolescent/adult with TB, negative TST, normal CXR, and asymptomatic. What stage is the child in?::Exposure stage

[2023, 2024] TB stage where individual inhales droplet nuclei containing MTB that becomes established intracellularly in lungs and LNs::Infection

[2024] Aina is 4 years old, brought to you for a gradually increasing painless swelling over the R cervical area, over a period of 2 months. There was also on and off low-grade fever and she was observed to have lost weight in the last 4 weeks (described as loosening of clothes). PE: firm, discrete, mobile nodes on the L cervical area; matted nodes on the R with inflammation of the overlying skin. Pertinent history and workups: -Grandmother presently treating for TB (3rd month tx)- PPD 14 mm induration. Best treatment for this case is?::2 months HRZE and 4 months HR (prolonging treatment is only done for bone and joint TB)

[2023] A 2 year old toddler was brought to the OPD due to **chronic cough**. The patient was previously prescribed with antibiotics with temporary relief of the cough. She was also given anti histamines to control her allergies. However after 1 month, there was still note of cough. The child was also noted to be significantly below the normal weight and height. What test will be most appropriate to check for TB infection in this patient?::Tuberculin Skin Test or PPD (Pediatric TB is usually a clinical diagnosis and lab confirmation is usually never established except for TST or IGRA)

[2024] Clue to the presence of extrapulmonary TB?
A. Ascites with neutrophilic predominance with negative culture
B. Chronic lymphadenopathy (cervical)
C. CSF lymphocytic pleocytosis with elevated protein and low glucose and a positive bacterial isolate on culture
D. Exudative pleural effusion, PMN predominance, negative cultures
?
B. Chronic lymphadenopathy (cervical)

# Personal Questions
Risk factors for TB in children
?
- Household or close contact with case of smear or culture positive PTB
- Recent exposure
- Age < 5 y/o
- HIV and other immunocompromised condition
- Severe malnutrition

Stage of TB where the person shared an enclosed space for extended periods within the day with index case 3 months prior to TB diagnosis:::Exposure Stage of TB

Most frequent exposure setting in TB::Household

State of persistent immune response to stimulation by MTB antigens with no evidence of clinical manifestations of active TB:::Latent TB infection

Hallmark of latent TB infection::Reactive TST or IGRA+ result

Prophylaxis for infected TB patients::Isoniazid

Elements of TB Primary Complex described by Ghon
?
- Primary focus
- Lymphangitis
- Regional LAD

Classic radiographic features of TB
?
- Segmental or lobar airspace consolidation
- Ipsilateral hilar and mediastinal LAD and/or effusion
- Atelectasis

Clues to suspect EPTB
?
- Ascites with lymphocytic predominance and persistent negative cultures
- Chronic cervical LAD
- CSF lymphocytic pleocytosis with elevated protein and low glucose
- Exudative pleural effusion, lymphocytic predominance, and persistent negative cultures
- Monoarticular joint inflammation with persistent negative cultures
- Persistent sterile pyuria
- Unexplained pericardial effusion, constrictive pericarditis, and calcifications
- Vertebral osteomyelitis involving the thoracic spine in setting of immunosuppression

Signs and symptoms suggestive of TB (Presumptive TB <15 y/o)
?
- Coughing and wheezing ≥ 2 weeks especially if unexplained
- Unexplained fever ≥ 2 weeks
- Unexplained weight loss or FTT
- Close contact with known TB case + fatigue, reduced playfulness, reduced activity, not eating well, or anorexia ≥ 2 weeks
- CXR findings of PTB

Presumptive EPTB in Children < 15 y/o
?
- Gibbus deformity of recent onset
- Painless, enlarged cervical LAD ± fistula
- Nuchal rigidity and/or drowsiness suggestive of meningitis
- Pleural or pericardial effusion
- Distended abdomen (liver and spleen) + Ascites
- Non-painful enlarged joint
- Tuberculin hypersensitivity (erythema nodosum, phlyctenular conjunctivitis)

Screening modality for Active PTB in children < 15 y/o?
?
- Sputum and/or extrapulmonary sample especially for those ≥8 years old
- Xpert MTB/Rif test
- Chest X-ray

Bacteriologically confirmed TB means positive results in which tests?
?
- Xpert MTB/Rif
- Sputum microscopy
- TB Lamp
- TB Culture


Differentiate new vs. retreatment TB
?
New TB means that the patient has never been treated before or underwent <1 month of treatment while retreatment means that patient underwent treatment for ≥1 month regardless of completion

TB resistant to both isoniazid and rifampicin:::Multidrug resistant TB (MDR-TB)

TB resistant to isoniazid, rifampicin, fluoroquinolone, and ≥1 group A drug (Levofloxacin, Moxifloxacin, Bedaquiline, and Linezolid):::Extensive drug-resistant TB (XDR-TB)

TB previously treated, declared cured, or treatment completed but presently have bacteriologic or clinical TB::Relapse

TB previously treated, treatment failed, and sputum/CS positive at 5 months treatment::Treatment Failure

TB previously treated, lost to follow-up for ≥2 months, and diagnosed with bacteriologic or clinical TB::Treatment lost to follow-up

Goals of TB Treatment
?
- **Cure** patient by rapidly eliminating most bacteria (main)
- Prevent **death** from active TB and late effects
- Prevent **relapse** by eliminating dormant bacteria
- Prevent drug **resistance** by drug combination
- **Decrease transmission** by treating as soon as diagnosed
- Achieve prior goals with **minimal toxicity**

Unique considerations for TB in children
?
- Fewer mycobacterial organisms
- Extrapulmonary disease is more common
- Children tolerate higher doses of anti-TB medications per kg body weight and experience fewer side effects
- Drugs may be modified in children to form they can tolerate

Indication for 2HRZE/10HR TB treatment
?
- EPTB of CNS, bones, joints
- MTB, RIF sensitive or indeterminate

Drug dosing of HRZE in children
?
- 10 (7-15) mg/kg Isoniazid
- 15 (10-20) mg/kg Rifampicin
- 35 (30-40) mg/kg Pyrazinamide
- 20 (15-25) mg/kg Ethambutol

Fixed Dose Combination for TB treatment
?
- 50 mg Isoniazid
- 75 mg Rifampicin
- 150 mg Pyrazinamide