---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[07 Approach to Fever and Infections in Immunocompromised Hosts]]

[2023, 2024] A 34/F undergoes a living related kidney **transplant**. Two weeks after transplant she develops a fever. Her sister, who donated the kidney, feels well. On examination, the patient appears comfortable. Her VS are stable, and O2 is 98% at room air. She has a R-sided IJ catheter. There is no surrounding erythema, but it is tender to touch. There are minimal rales at both lung bases. There is mild pitting edema, 1+ bilaterally. Which type of infection is most likely?
A. Nosocomial infection
B. An opportunistic infection
C. A donor-derived infection
D. A reactivation of latent infection
?
A. Nosocomial infection
*Days 0-30 means donor-derived or nosocomial*

[2023, 2024] A 20 year-old gentleman, with history of CML underwent **splenectomy** a few months ago. Which of the following vaccines should he be immunized with?
A. Influenza vaccine
B. Meningococcal vaccine
C. Haemophilus type B vaccine
D. HPV vaccine
?
B. Meningococcal vaccine

[2023, 2024] Neutropenia is generally defined as?::ANC <500 cells/mm3

[2023, 2024] A 35 year old female with h/o idiopathic cardiomyopathy underwent cardiac transplantation. Which is the drug of choice to prevent toxoplasma reactivation?
A. Dapsone
B. Azithromycin
C. Pentamidine
D. Trimetophrim-Sulfamethoxazole
?
D. Trimetophrim-Sulfamethoxazole
*TMP-SMX is the most frequently used agent for prophylaxis in heart transplants*

[2023, 2024] A 45 year-old presents with neutropenic fever. He has been on levofloxacin as outpatient. Which of the following antimicrobials would be most appropriate as initial monotherapy?
A. Amikacin
B. Ertapenem
C. Ceftazidime
D. Moxifloxacin
?
C. Ceftazidime
*Other ones recommended are cefepime, piperacillin-tazobactam, imipenem-cilastatin, and meropenem (Beta lactams with anti-pseudomonal activity)*

[2023, 2024] A 45 year old presents with fever, cough, weight loss 8 months after kidney transplantation. She is on cotrimoxazole for prophylaxis. She had history of TB exposure in the past, and is not on isoniazid because of a drug allergy. This infection is most likely:
A. Donor-derived infection
B. Opportunistic infection
C. Allograft infection
D. Reactivation of latent infection
?
D. Reactivation of latent infection
*Patient is already 8 months post-transplant hence A is not likely. D is more likely as there is noted TB exposure but did not get INH prophylaxis*

# Personal Questions
Pathology and associated pathogens of Humoral immunity defects
?
- Pathology: Recurrent sinopulmonary infections
- Pathogens (SIN): Strep pneumoniae, H. influenzae, Neisseria

Pathology and associated pathogens of Cellular immunity defects
?
- Pathology: Disseminated infection or pulmonary infection
- Pathogens: HHV, Adenovrius, Listeria, HPV, TB, Nocardia, PCP, Cryptococcus, Endemic Fungi

Pathology and associated pathogens of Phagocytic Immunity Defects
?
- Pathology: Recurrent skin, lung, or liver cold abscesses
- Pathogens: S. aureus, CoNS, Strep viridans, E. coli, P. aeruginosa, K. pneumoniae

Patients with ==multiple myeloma== has a problem with hypogammaglobulinemia making them prone to ==Strep pneumoniae== infections

Patients with ==Hodgkin Lymphoma== have abnormal ==T cell== function making them prone to infection with ==intracellular== pathogens

Formula for Absolute Neutrophil Count
?
$$ANC=WBC\times\frac{Bands+Segmenters}{100}$$

==Mucositis== from chemotherapy results in ==malabsorption, bacterial translocation, and increased risk for infection==

Management for High-risk cancer patients with fever?::IV monotherapy with anti-pseudomoonal beta-lactam (Cefepime, Carbapenem, Piperacillin-Tazobactam)

Additional Antimicrobials given to manage complications in cancer patients with fever e.g., Hypotension and Pneumonia
?
- Aminoglycosides
- Fluoroquinolones
- Vancomycin

Indications for Catheter Removal in Immunocompromised Patients
?
- Tunnel-site erythema regardless of blood cultures
- Blood culture shows gram positive cocci (except for coagulase-negative ones)
- Blood culture shows Gram-negative bacteria
- Blood culture shows Fungal Infection

Management for exit-site erythema with negative blood cultures in immunocompromised patients with catheter
?
- Catheter removal unnecessary unless not responsive to treatment
- Begin treatment for Gram positive cocci

Management of tunnel-site erythema in immunocompromised patients
?
- Catheter removal
- Treat for gram positive cocci pending blood cultures

Management for Coagulase-negative Staphylococci infected catheter in immunocompromised patient
?
- Line removal but may not be needed if stable and responsive to antibiotics
- Begin with Vancomycin with Linezolid, Quinupristin/Dalfopristin, and Daptomycin as alternatives

Most infections in solid organ transplant recipients occur in the first ==few months== post-transplant

Donor-derived infections mostly happen ==1 month== post-transplant and the main differential is ==hospital-acquired infection==

Most common cause of fever in transplant patients from **day 31 to the 4th month** post-transplant
?
- Viral pathogens
- Allograft rejection

Prophylaxis used to prevent most UTI and opportunistic infections::Trimetophrim-Sulfamethoxazole

Most notorious and common pathogen in solid organ transplant recipients::CMV

Pre-engraftment Phase of HSCT (Day 0-30)
??
- Phase of HSCT where Chemotherapy wipes out immune system
- Susceptible to HSV, aerobic bacteria (bacterial infections are more common especially in neutropenic patients)

Engraftment phase of HSCT (30-100)
??
- Phase of HSCT susceptible to opportunistic infections e.g., CMV, adenovirus

Hematologic transplant from an identical twin:::Syngeneic HSCT
Hematologic transplant from sibling or unrelated donor:::Allogeneic HSCT
Hematologic transplant from self:::Autologous HSCT
Immunologic reaction by donor lymphocytes against recipient causing inflammation of target tissues:::Graft-vs-Host Disease



