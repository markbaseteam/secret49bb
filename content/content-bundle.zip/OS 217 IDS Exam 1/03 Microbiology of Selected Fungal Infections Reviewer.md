---
tags: OS217/IDS, flashcards, 
type: Exam 
---
lecture:: [[03 Microbiology of Selected Fungal Infections]]

[2023, 2024] A 20/M came from a vacation in Acapulco, Mexico and developed fever, cough, and body malaise. Chest x-ray revealed pulmonary infiltrates and hilar lymphadenopathy. Fungal culture of respiratory secretions incubated at 37 degrees Celsius yielded narrow-based budding yeast cells. If this fungus was grown at 25 degrees Celsius, what will you expect to find?
A. Hyphae with chlamydoconidia
B. Oval conidia on short and long hyphal branches
C. Arthroconidia
D. Tuberculate macroconidia
?
D. Tuberculate macroconidia
*Mexico origin with narrow-bsed budding yeast cells indicate that this is Histoplasmosis and the tuberculate macroconidia is used to refer to the round macroconidia with spikes*

[2023, 2024] Biopsy of a verrucous nodule on the upper lip of a 60 year-old male who recently came from a vacation in California revealed spherules on the dermis. Which of the following is the infectious propagule of the fungus that caused the patient’s disease?
A. Arthrospore
B. Blastospore
C. Chlamydospore
D. Phialospore
?
A. Arthrospore
*Patient has Coccidioidomycosis where arthroconidia refer to barrel-shaped viable elements when hyphae degenerate*

[2023, 2024] Which of the following endemic mycoses has the widest distribution in terms of geographic niche?
A. Histoplasmosis
B. Blastomycosis
C. Coccidioidomycosis
D. Paracoccidioidomycosis
?
A. Histoplasmosis

[2023, 2024] Which of the following endemic fungi is present in the Philippines?
A. Histoplasma capsulatum
B. Blastomyces dermatitidis
C. Coccidioides posadasii
D. Paracoccidioides brasiliensis
?
A. Histoplasma capsulatum
*Histoplasma capsulatum and Talaromyces marneffei are the endemic fungi mentioned in the lecture that is present in PH*

[2023, 2024] Filipinos are at higher risk compared to other races in acquiring which of the following diseases?
A. Disseminated histoplasmosis
B. Disseminated blastomycosis
C. Disseminated coccidioidomycosis
D. Disseminated paracoccidioidomycosis
?
C. Disseminated coccidioidomycosis
*Filipino > African-American > Native American > Hispanic > Asian is the hierarchy of risk for Coccidioides immitis infection*

[2023] True of endmic fungi
A. Ubiquitous
B. Confer immunity
C. Cause disease among immunocompetent individuals only
D. AOTA
?
B. Confer immunity
*A is wrong as they have a designated region and C is wrong as it also affects immunocompromised patients*

[2023] Which of the ff. is true about blastomycosis?
A. Dogs are carriers
B. Contact with soil with dog excreta is a risk factor for this disease
C. Primary blastomycosis infection occurs in the lungs
D. Blastomycosis can spread from person to person
?
C. Primary blastomycosis infection occurs in the lungs
*Blastomycosis causes primary pulmonary infections*

# Personal Questions
Unique properties of Endemic Mycoses
?
- Thermally dimorphic
- Limited to certain geographic regions
- Primary systemic pathogens

Genera of Endemic Fungi
?
- Blastomyces (Body)
- Histoplasma (Heat)
- Coccidioides (Changes)
- Paracoccidioides (Phase)
- Talaromyces (Too)

Endemic fungi are called thermally dimorphic because?
?
- Filamentous molds (saprobes) at 25ºC in environment
- Yeasts (parasitic) at 37ºC in human body

Geographic region of Histoplasma capsulatum var. capsulatum::Midwest US
Geographic region of Histoplasma capsulatum var. duboisii::Africa
Geographic region of Blastomyces dermatidis::Midwest US and parts of Africa
Geographic region of Coccidioides immitis::San Joaquin Valley, California; Southwest US; Northern Mexico and South America
Geographic region of Paracoccidioides brasiliensis::Central and South America especially Brazil

Endemic fungi found in PH
?
- Histoplasma capsulatum
- Talaromyces marneffei

Culture media for endemic fungi
?
- Sabouraud dextrose agar for saprobes (25ºC)
- Brain Heart infusion agar with blood for yeast (37ºC)

Most rapid and cost-effective method for laboratory diagnosis of endemic mycoses::Direct microscopy
Why is diagnosis of Histoplasmosis with **Histoplasmin Skin Test** not recommended?::Unable to distinguish past and present infection and affects subsequent serologic testing
Skin test used to check for Coccidioidomycosis but is unable to distinguish past and current infection::Spherulin (Coccidioidin) Skin Test

==Skin and bone== lesions are commonly seen in ==Africa== with **Histoplasma capsulatum var. duboisii** infections

Soil content that enriches Histoplasma capsulatum growth::High nitrogen content enriched with bird and bat droppings

==Histoplasmosis== have ==white suede-like== colonies with ==pale yellow-brown== reverse

Fungi with large, thick-walled, spherical macroconidia with spike-like projections on short conidiophores often termed as tuberculate macroconidia::Histoplasma capsulatum

Difference in yeast form between H. capsulatum var. capsulatum and var. duboisii
?
- Capsulatum variety is thin-walled, small, and oval
- Duboisii has larger and thicker form
- Both have narrow bases

Most frequent clinical form of blastomycosis::Ulcerative skin lesions and lytic bone lesions
Ecological niche of Blastomyces dermatidis::Decaying organic matter
Blastomyces species common in SE and Southcentral US::Blastomyces dermatitidis and gilchristii
Blastomyces species common in Western Canada and US::Blastomyces helices
Blastomyces species common in Africa and Middle East::Blastomyces percursus
Blastomyces species common in South Africa::Blastomyces emzantsi

Fungal cutaneous infection produces papular, pustular, indolent, ulcerative-nodular, or verrucous lesions with crusted surfaces and raised serpiginous borders::Blastomyces
Common sites of Cutaneous Blastomyces::Face, Scalp, Neck, Hands

Ecologic niche of Coccidioidomycosis::Soil that experiences little to no precipitation, alkaline pH, and usually deserts enhanced by bat and rodent droppings
Very virulent mycoses that become spherules upon reaching the lungs::Coccidioidomycosis
Most common site for disseminated and secondary coccidioidomycosis::Skin especially in face and head

Differentiate primary and secondary coccidioidomycosis
?
- Primary if elevated IgM and disseminated if elevated IgG
- Primary spontaneously resolves and may not need treatment while disseminated needs systemic therapy

Endemic fungi with white to gray moist and glabrous colonies that develop abundant aerial mycelia creating tan to brown or lavender coloration::Coccidioides immitis

Risk Factors for Coccidioidomycosis
?
- Infant/Elderly
- Male
- Filipino > African-American > Native American > Hispanic > Asian
- Late pregnancy and postpartum periods
- Depleted cell-mediated immunity e.g., cancer, chemotherapy, steroids, HIV

Most common clinical form of Paracoccidioidomycosis::Ulcerative lesions of oral and nasal cavity
Ecologic niche of Paracoccidioidomycosis::Soil with high humidity and rich vegetations
Endemic fungi producing white or brownish colonies with septate hyphae and intercalated chlamydoconidia::Paracoccidioides brasiliensis

Parasitic Form of Paracoccidiodes brasiliensis
??
- Oval to round cells with double refractile walls
- Similar to mariner's or pilot's wheel

Mycoses primarily involving HIV patients in Thailand and South China that can mimic other conditions and have molluscum contagiosum like skin lesions::Talaromycosis
Saprobic form of Talaromyces marneffei::Sporulating structures similar to Penicillium with red pigment diffusing in agar

Parasitic form of Talaromyces marneffei
??
- Divides by fission 
- Transverse septum
- More pleomorphic and elongated than histoplasmosis