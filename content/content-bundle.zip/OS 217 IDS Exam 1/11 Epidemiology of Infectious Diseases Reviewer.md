---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[11 Epidemiology of Infectious Diseases]]

[2023, 2024] A 50-year-old housewife with **fever, jaundice and right upper quadrant pain** consulted at the Emergency Department. Vital signs: BP: 90/60, HR = 104/min RR = 18/min, temp. = 39.5°C. PE: (**+) Murphy’s sign**. The patient underwent endoscopic retrograde cholangio-pancreatography (ERCP). Culture of the bile showed heavy growth of Escherichia coli. The growth of E. coli most likely indicates?
A. Carrier state
B. Colonization
C. Contamination
D. Clinical infection
?
D. Clinical infection
*Symptomatic + bacteriologic confirmation*

[2023,2024] First necessary component in chain of COVID-19 infection::SARS-CoV-2 (Infectious agent is the first necessary component in chain of infection)

[2023, 2024] Globally and in the Philippines, which of the following infectious diseases has been showing a decreasing trend in the number of new cases in the past 5 years?
A. Dengue fever
B. Human immunodeficiency virus infection
C. Malaria
D. Tuberculosis
?
C. Malaria

[2023, 2024] The ff. diseases are transmitted mainly through direct contact except?
A. Leprosy
B. Rabies
C. Measles
D. Non-gonococcal urethritis
?
C. Measles
*Measles is highly contagious and is also transmitted with airborne spread not just person-to-person*

[2023] Host factor that influences exposure and found to be associated with increased risk for TB:
A. Urban dwelling
B. Low-socioeconomic status
C. Malnutrition
D. Previous hospitalization
?
A. Urban dwelling

[2023] A 30-year-old nurse underwent screening for hepatitis as part of a requirement of the hospital where she applied. Her physical examination was normal. The result of the hepatitis serology was **positive for Hepatitis B surface antigen**. The presence of Hepatitis B surface antigen indicates?::Carrier state (Asymptomatic but positive for HBsAg)

[2023] Symptom screening, doing chest x-ray and treating latent TB among the household contacts of a patient with smear positive PTB is an example of:
A. Primary prevention of TB disease.
B. Secondary prevention of TB disease.
C. Tertiary prevention of disabilities from TB disease.
D. Prevention of TB overtreatment.
?
B. Secondary prevention of TB disease.
*The aim of secondary prevention is to reduce mortality and morbidity through early detection of disease*

[2023] The way by which an infectious agent is transported through the environment and spread to other hosts is determined by the following except:
A. Ability to survive away from the host
B. Mode of transmission
C. Ability to infect non-human hosts
D. Ability to cause severe disease
?
D. Ability to cause severe disease

[2023] Separating or restricting the movement of asymptomatic family member and neighbors who may have been exposed to a person with confirmed COVID-19 infection is called?::Quarantine (Considering that the patient is asymptomatic it is quarantine but if the patient is symptomatic, it is isolation)

# Personal Questions
==Distribution== in epidemiology of infectious diseases refers to the ==burden of disease== 

==Determinants== in epidemiology of infectious diseases refer to the ==exposures and host factors==

Categories of Infectious Diseases that cause the most deaths
?
- Lower respiratory tract infection
- Neonatal conditions
- Diarrheal diseases

Categories of Infectious diseases in PH causing the most deaths
?
- LRTI
- Tuberculosis
- Neonatal conditions particularly, neonatal sepsis

Top infectious killer in the world::Tuberculosis

The number of deaths and new infections of HIV are on a ==downward== trend in recent years 

Endemic disease that have been prevalent for a sufficient time to be **relatively stable and predictable** in terms of mortality and morbidity:::Established infectious diseases

Diseases recognized in **human host** for the first time:::Newly emerging infectious disease

Diseases that have historically infected humans but **reappear in new locations or in resistant forms or reappear after apparent control or unusual circumstances**:::Re-emerging infectious diseases

Factors contributing to Emerging Infectious Diseases
?
- Change in **demographics and behavior** (host)
- **Microbial** adaptation and change (agent)
- Changes in **technology and industry** (environment)
- Breakdown of **public health** measures
- International **travel and commerce**

For an infection to occur, a **pathogenic/infectious  agent** must be ==present and able to replicate in normally sterile site of host eliciting inflammation==

Unapparent infection reaction between agent and host limited to an immune response::Subclinical Infection
Presence of organisms in tissues (can **replicate and be cultured**) without clinical and subclinical infection:::Colonization
Colonized individual but shows no evidence of disease and **able to transmit organism**:::Carrier
Presence of organisms on **body surface or inanimate object**:::Contamination
Refers to the ability of an agent to **spread or be transported** through the environment:::Infectiousness

Determinants of Infectiousness
?
- Characteristics of portals of **entry and exit**
- Ability to **multiply** in environment
- **Survive** away from host
- Infect **nonhuman** hosts

Ability of agent to **enter, survive, and multiply** in host:::Infectivity
Measure of infectivity::Secondary Attack Rate

Formula for **Secondary Attack Rate**
?
$$SAR=\frac{Infected\ after\ Exposure}{Susceptible\ and\ Exposed}$$

Measure of **transmission potential** of disease::Basic Reproduction Value (No transmission = 1.0)

Refers to the extent to which **overt or clinical disease** is produced by infected population (clinical disease/infected):::Pathogenicity

Refers to the **disease-producing** potential of pathogen in terms of **range of manifestations** of illness in host:::Virulence

Ability of agent to produce **systemic or local immunologic reaction** in host:::Immunogenicity/Antigenicity

Disease influence of alleles on gene CCR5::Partial protection from acquiring HIV and developing AIDS
Disease influence of **globin** gene alleles::Partial protection against **malaria**
Disease influence of absent **Duffy blood group** on RBCs::Complete protection against **Vivax malaria**
Disease influence of **blood group O**::Increased susceptibility to **severe cholera**

HIV Risk Populations
?
- Inject drugs
- Female sex workers
- Gay men or men who have sex with men
- Transgender women

Occasional occurrence of disease at irregular intervals::Sporadic
Low level of frequency of disease at moderate intervals::Endemic
Gradual increase of occurrence of disease beyond endemic level but not to epidemic proportions::Hyperendemic
Sudden increase in case incidence above expected level::Epidemic

Epidemic curve with abrupt onset and gradual descent with single peak::Point Source Outbreak
Epidemic curve with abrupt onset over extended period of time::Continuous common source outbreak
Epidemic curve with ≥2 clusters of cases in time separated by one median of incubation period::Person-to-person outbreaks
Epidemic curve with peaks that merge into bigger waves in each generation::Disseminated outbreak with propagated spread

Refers to sequestration of **symptomatic patients** at home or hospital to prevent infection::Isolation
Separation of asymptomatic exposed persons to control infection in community::Quarantine
Non-quarantine measures to reduce contact between persons::Physical Distancing



