---
tags: OS217/IDS, flashcards, 
type: Exam
---
lecture:: [[05 Principles of Laboratory Diagnosis]]

[2023, 2024] Which of the following statements accurately describes the diagnosis of microbial infections?
A. The diagnosis of a microbial infection begins with an assessment of clinical and epidemiologic features, leading the the formulation of a diagnostic hypothesis
B. The clinical diagnosis is established by the application of microbiologic laboratory methods
C. The etiologic diagnosis suggests several possible etiologic agents based on knowledge of infectious syndromes and their courses
D. Etiologic diagnosis precedes and guides the approach to clinical diagnosis
?
A. The diagnosis of a microbial infection begins with an assessment of clinical and epidemiologic features, leading the the formulation of a diagnostic hypothesis
*Clinical diagnosis should precede etiologic diagnosis*

[2024] Gene sequencing refers to the technique used to determine?::Base sequence in the nucleic acid

[2024] Which of the ff. test results is suggestive of early, acute, infection? (Left to Right: A, B, C, and D)
![[COVID Test Quiz.png]]
?
C
*A is negative. B indicates past infection. D indicates possible transition from acute to resolution/chronic phase*

[2023, 2024] Which of the following statements is true regarding nucleic acid-based testing for infectious diseases?
A. The conventional polymerase chain reaction involves multiple cycles of denaturation, annealing, and elongation of the genetic material
B. Nucleic acid-based tests only detect viable, replicating infectious pathogens
C. Multiple pathogens can be detected via real-time polymerase chain reaction
D. All nucleic acid based tests require thermal cycler for operation
?
A. The conventional polymerase chain reaction involves multiple cycles of denaturation, annealing, and elongation of the genetic material
*B is wrong as non-viable cells can be detected as long as there are nucleic acids. C is wrong as this is supposed to be multiplex PCR instead. D is wrong as there is LAMP which does it all in one temperature*

[2023, 2024] Which of the ff. is true regarding immunoassays?
A. Seroconversion happens when antibodies are detected during the convalescent phase but not in the acute phase.
B. Antibodies are quantified by titers, the highest serum concentration demonstrating activity in immunoassays.
C. Detection of IgM antibodies indicates recovery from an infection.
D. Paired specimens, usually collected at onset of illness and another three days after, are compared.
?
A. Seroconversion happens when antibodies are detected during the convalescent phase but not in the acute phase.
*Seroconversion is also when there is 4x rise in titers. B is supposed to be highest serum dilution. C should be acute infection. D is wrong as it is supposed to be weeks and not days*

[2023] Which of the ff. statements is correct regarding specimen collection?
A. Inappropriate specimen can mislead clinician to wrong diagnosis
B. Quantity of specimen is crucial to arrive at correct diagnosis
C. Specimen type will not matter for test with high specificity and very high sensitivity
D. Failure at level of specimen is the most common reason for failing to establish clinical diagnosis
?
A. Inappropriate specimen can mislead clinician to wrong diagnosis
*B is wrong as quality is more important . C is incorrect as specimen choice is crucial. D is wrong as it is supposed to be etiologic diagnosis.*

[2023] All of the ff. are true of nucleic acid probe except?
A. Attaches to dsDNA
B. Short nucleic acid chain
C. Made of either DNA or RNA
D. Labeled with marker for detection
?
A. Attaches to dsDNA
*The probe must attach to ssDNA in order to be able to bind for detection as it relies on complementary base pairing with the target sequence*

# Personal Questions
Most common reason for failing to establish *etiologic* diagnosis or suggesting a wrong diagnosis::Failure at level of specimen collection

Refers to samples where findings are always diagnostic::Direct tissue or fluid samples
Samples that are localized in a sterile site but must pass through site with flora during collection::Indirect samples
Samples where pathogenic and non-pathogenic organisms mix together::Samples from microbiota sites

First line lab test for bacterial identification::Gram staining
Staining used to distinguish bacterial groups from each other::Differential Staining

Primary stain, mordant, decolorizer, and counterstain in Gram Stain
?
- PS: Crystal violet 
- M: Lugol's Iodine
- D: 95% alcohol
- CS: Safranin

Primary stain, mordant, decolorizer, and counterstain in Acid-Fast Staining
?
- PS: Carbolfuchsin
- M: Heat
- D: Acid Alcohol
- CS: Methylene Blue

Special stain used to visualize capsule of *Cryptococcus*::India Ink

==Dark field== microscopy is usually done in very thin bacteria like ==Leptospira and Treponema==

Media used to satisfy growth requirements of organisms to permit isolation and propagation:::Nutrient Media
Media used to seek out specific pathogens in sites with extensive microbiota:::Selective Media
Media containing substances designed to demonstrate biochemical or other features of specific pathogens or organism groups:::Indicator media

Cells used for Viral Culture
?
- Bacterial cells
- Chicken embryo cells
- Monolayers of human/animal cells

Cytopathic effect of Entrovirus::Rapid rounding of cells progressing to complete cell destruction
Cytopathic effect of Herpesvirus::Focal areas of swollen, rounded cells
Cytopathic effect of Paramyxovirus::Focal areas of fused cells

Indicator of microorganism growth in Broth Microdilution Assay::Turbidity
Viability indicators like ==resazurin== colors viable cells ==violet== and non-viable cells ==pink== in **Broth Microdilution Assays**

Immunoassay involving incorporation of antibodies in agar and putting antigen in a well::Radial Immunodiffusion Assay (Precipitation Test)
Immunoassay where antibodies are conjugated to latex particles or beads:::Agglutination Assay
Immunoassay used for **viruses**::Neutralization Assay

==Direct== ELISA detects for ==antigens== 

==Indirect== ELISA detects for ==antibodies== by ==coating antigen into wells then adding patient's serum==

==Sandwich== ELISA detects for ==antigens==

Refers to the highest serum dilution demonstrating activity::Titers
Refers to the appearance of specific antibody in convalescent serum that was previously absent in acute serum and vice versa:::Seroconversion
