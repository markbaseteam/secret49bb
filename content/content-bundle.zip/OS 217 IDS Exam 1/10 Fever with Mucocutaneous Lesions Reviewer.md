---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[10 Fever with Mucocutaneous Lesions]]

[2023, 2024] Sansa, a 2-year old female, was brought to the clinic for **low-grade fever**. On examination, you noted **maculopapular rash** from the face to the trunk and generalized lymphadenopathy. Upon checking the oral mucosa, you noted small red spots on the soft palate. The most probable clinical diagnosis is?::Rubella (low grade fever with Forscheimer spots)

[2024] How is congenital CMV infection best diagnosed?::Reactive CMV IgM result

[2023, 2024] Arya, a 1-year-old female, presented with fever, **cough, coryza and conjunctivitis**, maculopapular rash, and **Koplik** spots on the 3rd day of illness. The most probable cause of the disease is?::Rubeola virus (3C's and Koplik spots of measles)

[2023, 2024] Pete, a 13-year old male, presented with generalized, pruritic **vesicular rash in crops**, mild fever and coryza on the 5th day of illness. The most probable cause of this disease is?::Varicella Zoster

[2024] Which of the ff regarding Roseola infection is false?
A. High grade fever persists for 3-7 days followed by an erythematous maculopapular rash lasting for hours to days
B. Virus persists and may reactivate
C. Treatment is supportive
D. PCR test may differentiate between primary and reactivation or viral persistence
?
D. PCR test may differentiate between primary and reactivation or viral persistence
*PCR can only detect presence of virus*

[2023, 2024] This disease is characterized by a typical cutaneous lesion that has an **elliptical vesicle surrounded by an erythematous halo**. The long axis of the lesion is oriented along the skin lines usually caused by **Enteroviruses, HSV, but most commonly Coxsackievirus A16**.::Hand-foot-and-mouth Disease

[2023, 2024] Which of the following clinical scenarios has the lowest risk for varicella complications:
A. Person > 15 y/o
B. Infant < 1 y/o
C. Immunocompromised person
D. Neonate of women with rash onset within 10 days before or 48 hours after delivery
?
D. Neonate of women with rash onset within 10 days before or 48 hours after delivery
*A, B, and C are at increased risk. D would be high risk if it was within 5 days of delivery instead*

[2024] Which of the ff. does not present with vesicular exanthema?
A. Varicella
B. Entroviruses
C. Herpes Simplex
D. Fifth Disease
?
D. Fifth Disease
*Fifth disease is also called erythema infectiosum hence, the exanthem is supposed to be erythematous*

[2023] Kao, a 1-year old male presented with fever and irritability. On examination, you noted **tender submandibular adenopathy, ulcerative enanthem on gingiva and mucous membranes of mouth, and perioral vesicular lesions**. No other lesions in the body was noted. The most common mode of transmission for this disease?
?
Direct contact with infected oral secretions or lesions
*Kao has gingivostomatitis caused by HHV-1and they are transmitted via contact with infected oral secretions*

[2023] An illness recognized as erythema infectiosum with mild systemic symptoms, fever and a distinctive facial rash is also known as?::Fifth Disease (Parvovirus B19 infection causing slapped cheek appearance)

# Personal Questions
==Rubella== is a virus of the **Togaviridae** family with ==one== antigenic type

What can inactivate Rubella
?
- Chemical agents
- UV light
- Low pH
- Heat

Peak season of Rubella::Late winter to spring

Case features of Rubella
??
- Acute onset generalized maculopapular rash starting from face going down
- T ≥ 37.2ºC (low grade fever)
- Arthralgia or arthritis in adolescents and adults
- LAD
- Conjunctivitis

Paramyxoviridae virus with one antigenic type::Rubeola
Inactivating factors of Measles::Heat and Light

Case features of Measles
??
- Generalized rash > 3 days
- T > 38.3ºC
- Cough, Coryza, Conjunctivitis

==Koplik Spots== are spots located on the ==posterior of 3rd molar at back of palate== during early stages of viremia in **measles**

Rashes in measles usually begins at the ==hairline, forehead, and upper neck== spreading to ==trunk and extremities== in 3 days

Management for measles
?
- Symptomatic management with NSAIDs
- Oral Vitamin A supplementation for 2 days

Peak season of VZV::Summer

Reactivation of VZV with dermatomal distribution:::Herpes Zoster (Shingles)

Vesicular lesions concentrated in the areas of eczematous involvement in HSV infections:::Eczema herpeticum

Major etiologic agents for Hand foot mouth disease?
- Coxsackievirus A16
- Enterovirus A71

Clinical Features of Hand-foot-and-mouth Disease
??
- Mouth or throat pain
- Low grade fever
- Papulovesicular lesions on anterior of mouth, hands, feet, and buttocks

Typical cutaneous lesions of Hand-foot-and-mouth disease
?
- Elliptical vesicle surrounded by erythematous halo
- Long axis of lesion oriented along skin lines
- Starts as eryhtematous macules progressing to vesicles then superficial ulcers

==Nikolsky sign== refers to the exfoliation of skin from slight rubbing and is a sign of ==Staphylococcal scalded skin syndrome==

Gold standard of diagnosis for meningococcal disease::Blood, CSF, or skin culture

Management of Meningococcal disease::Penicillin or Ceftriaxone

Fever with mucocutaneous lesions that are emergences
?
- Staphylococcal scalded skin syndrome
- Meningococcal disease

Diagnostic criteria for Kawasaki Disease
?
- Fever for ≥5 days and ≥4 of the ff in the absence of other illness
	- Bilateral conjunctival injection
	- Oral findings (red cracked lips, strawberry tongue, erythema of oropharynx)
	- Cervical LAD
	- Dermatitis (≤5 days of fever onset; diffuse, maculopapular sparing face)
	- Distinct findings on extremities (erythema and/or induration)

Management of Kawasaki Disease
?
- IVIg 2g/kg over 10-12 hours
- High dose aspirin for febrile children and low dose aspirin when fever resolves
- Corticosteroids as needed

Most severe complication of Kawasaki Disease::Coronary Artery Aneurysm (regular 2D echo is indicated)