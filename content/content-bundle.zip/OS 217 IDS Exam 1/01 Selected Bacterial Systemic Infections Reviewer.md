---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[01 Selected Bacterial Systemic Infections]] %% fold %% 

[2024] This microbe does not Gram stain well because it lacks a cell wall:
A. Ureaplasma
B. Leptospira
C. Legionella
D. Rickettsia
?
A. Ureaplasma
*These Little Microbes May Unfortunately Lack Real Color But Are Everywhere*
*Treponema, Leptospira, Mycobacteria and Mycoplasma, Ureaplasma, Legionella, Rickettsia, Chlamydia, Bartonella, Anoplasma, Ehrlichia*

[2023, 2024] Which is responsible for the acid-fast property of *Mycobacterium tuberculosis*?
A. Cord Factor
B. Mycolic Acid
C. Peptidoglycan
D. AOTA
?
B. Mycolic Acid
*Lipids specifically mycolic acid is responsible for acid fast reaction while the peptidoglycan is for granuloma formation and cord factor is a virulence factor*
*2023 answered D but this is incorrect*

[2023, 2024] What is the classic egg-based medium used to isolate Mycobacterium tuberculosis?::Lowenstein-Jensen medium

[2024] A 40-year-old male had been in good health until he began experiencing a chronic cough. Over the following six weeks, the cough gradually worsened and became productive. He also noticed weight loss, fever, night sweats, and coughing blood. Supposed a research team is interested in isolating the etiologic cause, which culture media will support the growth of the etiologic agent?
A. Lowenstein-Jensen agar
B. Thayer-Martin Agar
C. MacConkey Agar
D. Saboraud Agar
?
A. Lowenstein-Jensen agar
*Fever, night sweats, and weight loss is the triad for tuberculosis hence the need to use LJA (B is for Neisseria, C is for Lactose-fermenting enterics, and D is for fungi)*

[2023] Which of the ff. is characteristic of Mycobacterium tuberculosis?
A. Facultative aerobe
B. Intracellular organism
C. Motile
D. Spore-forming
?
B. Intracellular organism
*Recall that this allows for latent TB infections. A is incorrect since they are obligate aerobes, C is incorrect as they are non-motile, and D is incorrect as they are non-spore-forming*

[2023] The National TB Program advocates sputum microscopy for the diagnosis of pulmonary TB. What is the acceptable staining procedure used in the community for this purpose?::Ziehl-Neelsen Staining (NTP Manual 6th Ed. recommends either Ziehl-Neelsen technique or fluorescence micrsocopy)

## Personal Questions
Gram Negative Bacteria
?
- Treponema (These)
- Leptospira (Little)
- Mycobacteria (Microbes)
- Mycoplasma (May)
- Ureaplasma (Unfortunately)
- Legionella (Lack)
- Rickettsia (Real)
- Chlamydia (Color)
- Bartonella (But)
- Anoplasma (Are)
- Ehrlichia (Everywhere)

Risk Factors for Leptospirosis Infection
?
-   Farm and agricultural workers
-   Pet shop workers
-   Veterinarians
-   Sewer workers
-   Abattoir workers
-   Meat handlers
-   Military personnel
-   Survivors of natural disasters
-   Engaging in recreational water sports

How is Leptospirosis transmitted?::Directly entry through **minor cuts or abrasions** or indirectly from **contaminated water or soil**

Refers to the pathogenic species of Leptospires with >250 serovars::Leptospira interrogans

Representative non-pathogenic leptospire::Leptospira briflexa

How many species of Leptospira are pathogenic?::10 species (out of 22 total)

Structural features of Leptospira
?
- Protoplasmic cylinder surrounded by plasma membrane and **peptidoglycan** layer (Gram positive)
- Outer sheath composed of **glycosaminoglycans**
- Periplasmic **flagella** oriented *axially* anchored at both ends to propel in **corkscrew-like fashion**

Basis of classification for Leptospira and determines the specificity of human immune response::Outer envelope specifically its large amounts of **lipopolysaccharides**

Growth medium for Leptospira::Simple media enriched with vitamins (B2 and B12), long chain fatty acids, and ammonium salts

Energy source for Leptospira::Oxidation of long fatty acids

Water pH where Leptospira can survive for weeks::Alkaline pH

Candidate Virulence Factors for Leptospirosis
?
- Lipopolysaccharides
- Adhesion molecules
- Hemolysins
- Outer membrane proteins and other surface proteins

Clinical Manifestations of Leptospirosis
?
- Initial fever and flu-like symptoms (1-2 weeks)
- Systemic disease involving liver, kidneys, and CNS (>3 weeks) resulting in infectious jaundice, marsh fever, and Weil's disease

Most commonly used media for Leptospirosis composed of animal protein in serum or bovine serum albumin with polysorbate:::Fletcher's Media (EMJH Semisolid Media)

Gold standard test for Leptospirosis::Microagglutination testing

Serological test that uses IgM antibodies to detect Leptospirosis::LEPTO Dipstick

Causative agent of Typhoid fever::Salmonella enterica serovar typhi

Gram negative rod with **peritrichous flagella** that are non-lactose fermenters, produce H2S, and forms acid in glucose and mannose::Salmonella typhi

Mechanism of multiplication of Salmonella typhi::Uses cytoskeleton of macrophages to transport itself to the Golgi apparatus for multiplication

Antigens of Salmonella typhi used for agglutination testing and serologic classification
?
- O antigen is found in the somatic cell wall and is heat stable and alcohol resistanct
- H antigen is found in the flagella and is heat labile

Antigen responsible for invasiveness of Salmonella typhi allowing it to use macrophages as vehicles to avoid immune system detection:::Vi/K/Surface/Envelope Antigen of Salmonella Typhi

Virulence Factors of Salmonella typhi responsible for adherence
?
- Cell wall
- Fimbriae
- V1 Antigen
- Cytotoxin

Virulence Factors of Salmonella typhi responsible for evading phagocytosis
?
- Cell wall
- Fimbriae
- Capsule
- Flagella

Virulence factor of Salmonella typhi responsible for allowing survival in phagocytes::Capsule (O) antigen

Virulence factor of Salmonella typhi responsible for elaboration of toxins::Enterotoxin (similar to cholera) and Cytotoxin (similar to E. coli)

Characteristic symptom involving rose spots on the abdomen + Hepatomegaly/Splenomegaly for acutely ill patients:::Typhoid Belly

Specimens that can be used to detect Typhoid fever throughout the course of infection::Stool and Bone marrow aspirate

Media for Salmonella typhi::MacConkey agar or Salmonella/Shigella agar

O antigens of Typhoid fever detected by commercial agglutination test kits::A, B, C1, C2, D, and E

ELISA kit used to detect IgM and IgG antibodies against outer membrane proteins of Salmonella typhi:::Typhidot

Energy source for Mycobacterium tuberculosis::Oxidation of simple carbon compounds

The lipid coat of M. tuberculosis protects it from ==cationic proteins, lysozyme, and phagocytes==

==Phospholipids== of M. tuberculosis is responsible for ==caseation necrosis==

==N-glyclylmuramic acid== is a component of the peptidoglycan layer of M. tuberculosis that causes ==granuloma formation== when combined with ==mycolic acids==

==Protein== components of M. tuberculosis is responsible for ==tuberculin skin reaction and formation of antibodies==

**Polysaccharides** of M. tuberculosis is said to induce ==immediate hypersensitivity reactions==

==Cord factor== is formed by ==trehalose-6,6'-dymycolate== found in virulent M. tuberculosis strains that acts to ==inhibit leukocyte migration and cause chronic granuloma formation and mitochondrial damage==

==Lipoarabinomannan== is a heteropolysaccharide component of M. tuberculosis that ==inhibits macrophage activation by IFN-gamma and induces macrophage secretion of TNF-alpa== resulting in ==caseation necrosis and chronic granuloma==

Cells where M. tuberculosis reside in
?
- Monocytes
- Reticuloendothelial cells
- Giant cells

Decontamination of suspected M. tuberculosis specimen is done by?::Adding NaOH and possibly N-acetylcysteine

Fluorochrome staining for M. tuberculosis is composed of ==auramine and rhodamine== and allows for faster screening but positive smears have to be confirmed with ==Ziehl-Neelsen staining==

Agar-based media used to culture M. tuberculosis usually for investigating morphology, susceptibility, biochemical testing, and growing stock cultures::Middlebrook media (7H10 and 7H11)

Diagnostic modality for detection of M. tuberculosis employing radioactive palmitic acid:::BACTEC system

Indications for Xpert MTB/RIF
?
-   Presumptive drug-resistant TB
-   PLHIV with signs and symptoms of TB
-   Smear negative adults with CXR findings suggestive of TB
-   Smear negative children
-   Extrapulmonary TB

In vitro detection of TB using IFN-gamma release assay and is unaffected by BCG vaccination::TB Quantiferon

