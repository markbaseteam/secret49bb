---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[06 Fever of Unknown Origin]]

[2023, 2024] Among the following causes of fever among returned travelers, this infection is most likely to present as FUO:
A. MERS
B. Amebic meningioendephalitis
C. Latent syphilis
D. Hepatitis
?
D. Hepatitis
*Also includes malaria, enteric fever, TB, dysentery, and dengue*

[2024] Among the following, this is most likely to cause HIV-associated FUO
A. Pneumocystis pneumonia
B. GI lymphoma
C. Esophageal candidiasis
D. Eosinophilic folliculitis
?
B. GI lymphoma

[2024] In a patient who has undergone open cholecystectomy and who presents with nosocomial FUO, which of the following possible causes should you first rule out because of the risk that the patient’s condition will rapidly deteriorate:
A. Pulmonary atelectasis
B. Intraabdominal abscess
C. Drug fever from antibiotics
D. Phlebitis from peripheral IV line
?
B. Intraabdominal abscess

[2023, 2024] 25/M fever 38-40.1ºC for past 10 days with anorexia, easy fatiguability, and headache and who has recently travelled to Mindoro Oriental. Which of the ff. is the most likely etiology of fever?
A. Acute Katayama Fever for Schistosomiasis
B. Naegleria Meningitis
C. Plasmodium vivax malaria
D. Acute filariasis
?
A. Acute Katayama Fever for Schistosomiasis
*Mindoro oriental is a geographic region where Schistosomiasis is endemic. Naegleria meningitis usually causes death in 5 days.*

[2023, 2024] 54/M received **cytarabine** as part of treatment of AML 2 weeks ago. The patient presents with FUO while in hospital. The ANC is 282/μL, Hb is 75 g/dL, PLT is 40 x 10^9/L. Choose best course of action:
A. Send 3 sets of blood cultures with each set composed of blood drawn from 2 separate sites
B. Perform Chest CT to check for leukemic infiltrates in lungs
C. Do PET scan to check bone marrow response to chemotherapy
D. Start empiric broad-spectrum antibiotics
?
D. Start empiric broad-spectrum antibiotics
*Neutropenia is indication for empiric antibiotics*

[2023, 2024] Leading etiology of FUO in most developing countries:: Infection

[2023, 2024] 40/M fulfills criteria for FUO. Patient is MSM who experienced weight loss of 15% over past 2 months. On PE, several enlarged cervical LNs. Biopsy of LN is likely to be useful if suspecting?
A. Acute HIV infection
B. Infectious mononucleosis
C. TB lymphadenitis
D. Bartonellosis
?
C. TB lymphadenitis

[2023] 33 y/o jail inmate who was FUO + weight loss, anorexia, difficulty sleeping, this etiology of FUO should be high on the list of differential diagnoses:
A. HIV
B. Leptospirosis
C. Amebic liver abscess
D. Fulminant Hep B
?
A. HIV
*HIV prevalence is 15 times higher than general population*

[2023] True of patient with FUO who has normal vital signs and no new signs and symptoms in addition to fever, and is still without a diagnosis after 6 months:
A. The patient should take anti-pyretic before noon each day to lower core temperature setopint
B. Naproxen test should be performed to rule out adult Still's diease
C. Likelihood of occult infection increases
D. Patient's prognosis is generally good
?
D. Patient's prognosis is generally good

# Personal Questions
Definition of Classic FUO
?
- T > 38.3ºC (101ºF) on several occasions
- D > 3 weeks
- Observed in >2 outpatient visits or 3 days in hospital without known cause or 1 week of intelligent and invasive ambulatory investigation

DDX of mildly elevated procalcitonin (0.15-2 ng/mL)
?
- Localized mild to moderate bacterial infection
- Non-infectious systemic inflammatory response syndrome
- Untreated end-stage renal disease

DDX of markedly elevated procalcitonin (>2 ng/mL)
?
- Bacterial sepsis
- Severe localized bacterial infection
- Severe non-infectious inflammation
- Some carcinomas

Principle of Naproxen Test::Reduction of fever after Naproxen administration points to a non-infectious cause of fever most likely a malignancy (many conflicting reports)

Most common neoplastic diagnosis of FUO::Lymphoma

As the duration of fever increases, the likelihood of an ==infectious== cause of FUO ==decreases==

Definition of **Nosocomial FUO**
??
- T ≥38.3ºC (101ºF) on several occasions (>3 days)
- Receiving **acute care** and infection was not manifest or incubation on admission
- 3 days of investigation (includes ≥2 days of incubation of cultures)

Beginning point in approach to Nosocomial FUO::Original surgical or procedural field

Nosocomial FUO associated with diarrhea, abdominal pain, or taking long course of antibiotics::Clostridium difficile colitis

Definition of **Neutropenic FUO**
??
- T ≥ 38.3ºC (101ºF) on several occasions
- Neutrophil count < 500/μL or expected to fall to that level in 1-2 days 
- 3 days of investigation
- Cultures are negative after 48 hours

Risk Factors for Neutropenia
?
- Recent chemotherapy for cancer
- Receiving medications aside from chemotherapy that can cause neutropenia
- Hematologic conditions e.g., Leukemia and Aplastic Anemia

Management for Neutropenic FUO::Provide **empiric antibiotics** as they are at high risk for Sepsis and Septic Shock

Definition of HIV-associated FUO
?
- T ≥ 38.3ºC (101ºF) on several occasions
- Over a period of >3 weeks for outpatients or >3 days for hospitalized paitents
- Confirmed HIV infection

