---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[13 Common Arthropod-borne Infections]]

[2023, 2024] This disease is least likely to be spread through the bite of an infected Aedes species mosquito:
A. Dengue
B. Zika
C. Japanese encephalitis
D. Chikungunya
?
C. Japanese encephalitis
*JEV is transmitted by Culex tritaeniorhynchus mosquitoes while the other choices are transported by Aedes mosquitoes*

[2023, 2024] A 9-year old boy was brought to the emergency room because of **intermittent high-grade fever for 5 days, persistent vomiting and abdominal pain**. At the emergency room, the patient had a temperature of 39.2 deg C, BP of 90/60, RR 32/min. There was note of mild **epistaxis** but no melena, extremities were warm with full pulses and capillary refill time of 2 seconds. Blood count showed hemoglobin of 10g/L, hematocrit 0.42, WBC count 4500, and platelet count 180,000. **Dengue IgM antibody test was positive**. Based on the WHO 2009 Classification, this patient has:
A. Probable Dengue
B. Dengue without warning signs
C. Dengue with warning signs
D. Severe Dengue
?
B. Dengue without warning signs
*Patient has warning signs of dengue with confirmed infection from IgM reactivity.*

[2023, 2024] A 4-year old suspected to have dengue fever was brought in on the second day of illness. The best laboratory test for **rapid confirmation** of dengue infection during this stage of illness is by doing:
A. Dengue IgM antibody test
B. Dengue IgG antibody test
C. Dengue NS1 antigen test
D. Dengue viral culture
?
C. Dengue NS1 antigen test
*Antibody testing are indirect methods of detection and not as sensitive as antigen testing. Antigen tests are faster, more specific, and appropriate for acute phase specimens*

[2023, 2024] After **resolution of a febrile illness** for 5 days, a patient who presents with **coalescing erythematous rash** surrounding areas of normal skin similar to “isles of white in a sea of red” is in what phase of Dengue?
A. Incubation phase
B. Febrile phase
C. Critical phase
D. Recovery phase
?
D. Recovery phase
*Convalescent rash occurs during the recovery phase due to gradual ECF absorption happening 48-72 hr after critical period*

[2024] A patient diagnosed to have **Chikungunya** should be monitored for the development of which of the following sequelae during the convalescent phase of illness:
A. Arrhythmia
B. Convulsions
C. Fluid overload
D. Chronic arthritis
?
D. Chronic arthritis
*Chronic joint symptoms occur for >12% of patients*

[2024] A 25-year old mother with known travel to Latin America delivered a preterm infant with **microcephaly, intracranial calcifications, bilateral cataracts, and clubfeet**. Diagnostic test is **least likely** to be relevant in determining the etiologic agent in the infant:
A. Cytomegalovirus viral culture
B. Dengue virus IgG test
C. Zika virus PCR test
D. Rubella IgM test
?
B. Dengue virus IgG test
*Dengue is not part of the TORCHS infections list*

[2023, 2024] Which of the following clinical findings is observed during the Critical Phase of Dengue:
A. Fever, headache, retro-orbital pain
B. Muscle, bone, and joint pains
C. Ascites, pleural effusion, and melena
D. Fever, conjunctivitis, pruritic erythematous rash
?
C. Ascites, pleural effusion, and melena
*A and B are from the febrile phase of dengue. D is more commonly seen in Chikungunya and Zika infections*

[2023] Based on WHO 2009 case classification, which of the ff. patients suspected to have Dengue based on high grade fever should be classified as **"Dengue with Warning Signs"**?
A. 1/M with colds and mild epistaxis
B. 14/F with anorexia and diarrhea
C. 17/M with cold clammy skin and weak pulses
D. 15/F with lethargy, severe abdominal pain, vomiting
?
D. 15/F with lethargy, severe abdominal pain, vomiting

[2023] A 17-year old with fever, generalized rash, and **multiple joint swelling** but with **no bleeding, normal platelet count and no increasing hematocrit** most probably has?
?
Chikungunya
*Dengue, Zika, and Chikunguya all have fever, rash, arthralgia, myalgia, conjunctivitis etc. Dengue has hemorrhagic complications. Chikungunya is the one most associated with multiple joint swelling*

[2023] Standard diagnostic test to determine the diagnosis of an 8year old boy who presents with fever followed by behavioral changes, seizures, facial grimacing, lip smacking, and abnormal movements of the extremities:
A. Chikungunya-specific IgM in serum
B. Chikungunya-specific IgG in CSF
C. Japanese encephalitis-specific IgM in serum
D. Japanese encephalitis-specific IgG in CSF
?
C. Japanese encephalitis-specific IgM in serum
*JE typically presents with coryza, diarrhea, and rigors after non-specific febrile illness. Seizures and abnormal behavior is also observed. Standard JE diagnosis is with JE-specific IgM capture ELISA*

# Personal Questions
Warning Signs of Dengue
?
- Severe abdominal pain/tenderness
- Mucosal bleeding
- Clinical fluid accumulation
- Persistent vomiting
- Lethargy, liver enlargement, abnormal lab test

Diseases caused by Aedes sp.
?
- Dengue
- Chikungunya
- Yellow Fever
- Lymphatic Filariasis
- Zika

Diseases caused by Anopheles sp. 
?
- Lymphatic filariasis
- Malaria

Diseases caused by Culex ep.
?
- Japanese Encephalitis
- Lymphatic filariasis
- West Nile Fever

Disease caused by Psorophora sp.::West Nile Fever

Refers to a viral agent introduced or spread among humans by certain arthropods e.g., mosquitoes::Arbovirus

Most prevalent serotype in PH since 2013::DENV1
Age group with highest prevalence of dengue::Children < 15 years old

*Aedes aegypti* is confined in the ==tropic and sub-tropic==  environments and thrives in ==water-filled== breeding sites typically feeding and resting ==indoors==

*Aedes albopticus* are found in the tropics and sub-tropics but can also survive in ==temperate== regions and is more active ==out==doors

Dengue virus infects ==immature dendritic== cells in the skin then mature and migrate

Dengue IgM appears by day ==3 to 5== of illness and peaks by ==week 2== after onset gradually declining to undetectable levels over the next ==2 to 3 months==

Dengue IgG is detected by ==the end of first week== slowly increasing by day ==9-10== of illness and persisting for ==decades==

Secondary dengue infection pathogenesis
?
1. Immune complex formation between second DENV and the non-neutralizing antibodies from the first dengue infection
2. Immune complex infects mononuclear phagocytes via Fc receptors due to suppressed innate immune responses
3. Intracellular infection generates inflammation resulting in **antibody-dependent enhancement**

Earliest hematologic abnormality in dengue infections::Decreased total WBCs

Tourniquet Test Procedure
?
1. Measure BT
2. Inflate BP to (SBP+DBP)/2
3. Count total petechiae visible within 1 in2 area (positive if >20)

**Critical phase** refers to the period of ==plasma leakage from increased vascular permeability== 


Hematologic anomalies in critical phase of dengue::Progressive leukopenia followed by rapid progression of thrombocytopenia with hemoconcenration (+20% Hct)

Management of hypovolemic shock in dengue patients::Give minimum fluid that will maintain hemodynamic balance and acceptable urine output (0.5 ml/kg)

Criteria for severe dengue
?
- Lives in or travels to dengue-endemic area with 2-7 day fever and any of the ff clinical manifestations:
	- Severe plasma leakage leading to shock and fluid accumulation with respiratory distress
	- Severe bleeding
	- Severe organ involvement (AST/ALT ≥ 1000, Seizures, Myocarditis, Renal Failure)

Acute phase specimen tests for dengue (< 5 days from fever onset)
?
- Virus isolation
- PCR
- Nucleic acid amplification
- NS1 antigen test

Convalescent phase testing (≥5 days from fever onset)
?
- IgM detection
- Elevated IgG titers (≥1280 by HIA)
- IgM or IgG seroconversion

Main management aim during the febrile phase of dengue::Prevent dehydration
Main management aim during recovery phase of dengue::Prevent fluid overload

Management for active bleeding or low Hct despite adequate fluids in dengue patients::Packed RBCs (5-10 mL/kg) or Fresh Whole Blood (10-20 mL/kg)

Characteristic Triad of Acute Phase Chikungunya
?
- Sudden onset fever
- Rash 
- Arthralgia

Joint Affectation Pattern in Chikungunya
?
- Bilateral symmetric joint pains
- Mostly in the wrists, elbows, fingers, knees, and ankles

Principal vertebrate and amplifying hosts of Japanese Encephalitis::Pigs and aquatic birds

Classic Japanese Encephalitis presentation::Parkinsonian syndrome with mask-like facies, tremors, cogwheel rigidity, and choreathetoid movements

