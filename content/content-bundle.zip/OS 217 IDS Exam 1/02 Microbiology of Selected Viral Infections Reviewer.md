---
tags: OS217/IDS, flashcards, 
type: Exam
---
lecture:: [[02 Microbiology of Selected Viral Infections]]

[2023, 2024] Which is not true about the SARS-CoV-2 Sputnik V vaccine?
A. Sputnik V utilizes adenovirus type 26 and type 5 as vaccine vectors.
B. The adenovirus vector contains the SARS-CoV-2 gene coding for viral polymerase.
C. Ad26 is the vector used for the first dose, while Ad5 is used for the booster dose
D. Patients with preexisting neutralizing antibodies against adenoviruses may need higher doses or more boosters compared to patients who are seronegative.
?
B. The adenovirus vector contains the SARS-CoV-2 gene coding for viral polymerase.
*Sputnik V uses Ad26 for first dose and Ad5 for second dose. Vaccine is non-replicating vaccine and uses the gene coding for S protein*

[2023, 2024] An HIV patient came to the ER and was diagnosed with pure red cell aplasia. Which of the following is not true about Parvovirus B-19?
A. The virus enters the cell through the B antigen
B. Viral infection in adults may present as joint pains
C. Viral infection in children may present as a “slapped cheek” facial rash
D. Erythroid progenitor cells are a main site of viral replication
?
A. The virus enters the cell through the B antigen
*The P antigen is the receptor for Parvo B19 and not the site of entry*

[2024] A 3-year old patient presented with perioral lesions. Which of the following is not true about infections with herpesviruses?
A. Reactivation is common
B. Repeat disease is always more severe
C. The viruses can become latent in sensory ganglia
D. Acyclovir is monophophorylated by viral kinase
?
B. Repeat disease is always more severe
*Repeat disease is usually milder than the first infection*

[2024] Which of the ff. is not a DNA virus?
A. Adenovirus
B. Hepatitis B virus
C. Parvovirus B19
D. MERS-CoV
?
D. MERS-CoV
*Coronaviruses are +ssRNA*

[2023, 2024] Which of the following is not true about antigenic drift observed in influenza viruses?
A. Can involve either hemagglutinin or neuraminidase antigens
B. Mutations caused by viral RNA polymerase
C. Reassortment between human and animal or avian reservoirs
D. Can predominate under selective host population pressures
?
C. Reassortment between human and animal or avian reservoirs
*This occurs during antigenic shift where there is drastic change of sequence*

[2023, 2024] Hep B patient admitted for fulminant hepatitis usually happens in coinfection with?::Hepatitis D

[2023, 2024] 26/F consulting for genital warts. Which is not true about the family of this disease's viral etiology?
A. Low copy number of viral DNA is usually found on the surface, while late expression genes are usually expressed on basal epithelial layers
B. Types that cause cervical cancer express E6 and E7 proteins that inhibit the functions of tumor suppressor proteins
C. Types 6 and 11 cause genital warts
D. Type 16 and 18 can cause carcinoma
?
A. Low copy number of viral DNA is usually found on the surface, while late expression genes are usually expressed on basal epithelial layers
*HPV is usually the viral DNA that is found in the basal epithelium and the more complex genes are found at the more superficial layers*

[2023, 2024] 4/F consulting for lesions on hand, foot, and mouth. You know this is coxsackievirus. Which of the ff. is not associated with coxsackie?
A. Myocarditis
B. Pleurodynia
C. Herpangina
D. Infectious Mononucleosis
?
D. Infectious Mononucleosis
*Mononucleosis is associated with HHV-4 (Epstein-Barr Virus) infection while C is from coxsackie A and A and B are from coxsackie B*

[2024] A 30-year-old nurse underwent screening for hepatitis as part of a requirement of the hospital where she applied. Her physical examination was normal. The result of the hepatitis serology was positive for Hepatitis B surface antigen. The presence of Hepatitis B surface antigen indicates?::Carrier state (Asymptomatic patient with HBsAg persisting for ≥6 months)

[2024] Which of the ff. has dsRNA genome?
A. HIV
B. Coronavirus
C. Rotavirus
D. Parainfluenza
?
C. Rotavirus
*Only Rotavirus of Reoviridae has dsRNA among the choices. While the other choices are ssRNA*

# Personal Questions
Naked ssDNA virus considered as the smallest DNA animal virus::Parvovirus B19

Enveloped dsDNA virus that has the outstanding property of establishing lifelong persistent infection and undergoes periodic reactivation::Human Herpesvirus

HHV-1:::Herpesvirus with Gingivostomatitis as the representative disease presenting with perioral ulcers
HHV-2:::Herpesvirus associated with Genital Herpes manifesting with painful grouped genital vesicles
HHV-3 (Varicella Zoster):::Herpes virus associated with chickenpox and herpes zoster presenting with vesicles in a dermatomal distribution
HHV-4 (Epstein-Barr Virus):::Virus associated with infectious mononucleosis presenting with enlarged lymph nodes and splenomegaly
HHV-5 (CMV):::Herpesvirus associated with congenital defects, neonatal hearing loss, and mental retardation
HHV-6 and HHV-7:::Virus associated with **roseola infantum** where there is fever followed by **morbilliform rashes**
HHV-8:::Oncogenic virus associated with Kaposi's sarcoma presenting with reddish to purple grape-like lesions on skin

Main treatment options for HHV
?
- Acyclovir
- Valacyclovir
- Vidarabine

Naked dsDNA virus that stimulates cell DNA synthesis and restricts host range and tissue tropism::Human Papillomavirus

Clinical lesion of HPV type 1::Plantar warts
HPV types associated with common skin warts::2, 4, 27, 57
HPV types associated with **Epidermodysplasia verucciformis**::5, 8, 9, 12, 17, 20, 36, 47
HPV types associated with anogenital condyloma, laryngeal papilloma, dysplasia, and intraepithelial neoplasia::6, 11, 40, 42-44, 54, 61, 70, 72, 81
Clinical lesion of HPV type 7::Hand wards in butchers
HPV types highly correlated with genital and oral carcinomas especially cervical CA::16 and 18
HPV types associated with genital warts::6 and 11

How do HPV proteins inhibit tumor suppressor genes?
?
- E6 protein binds to p53 targeting it for ubiquitin-mediated degradation
- E7 interacts with Rb gene allowing for the cell cycle to progress continuously

HPV is highly tropic for ==epithelial cells and mucus membranes==

Types of HPV Vaccines
?
- Bivalent (16 and 18)
- Quadrivalent (Bivalent + 6 and 8)
- Nonavalent (Quadrivalent + 31, 33, 45, 52, 58)

Parvovirus B19 has tropism for ==erythroid progenitor cells== resulting in ==Erythema infectiosum==

What cells express P antigen of Parvovirus B19?
?
- RBCs
- Erythroid progenitors
- Megakaryocytes
- Endothelial cells
- Placenta
- Fetal liver and heart

Sites of Replication for Parvovirus B19
?
- Bone marrow
- Some blood cells
- Fetal liver

For Parvovirus B19 to be able to reproduce, the host cells should be ==in S phase==

Viral protein associated with inducing apoptosis thus breaking down erythropoiesis in Parvovirus B19::NS1 viral protein

What happens in the first phase (1st week) of Parvovirus B19?
?
- Viremia and reticulocytopenia
- Fever, malaise, myalgia, chills, itching (non-specific symptoms)

What happens in the second phase (2nd week) of Parvovirus B19?
?
- Appearance of **erythematous facial rash** (slapped cheek) and **lace-like rashes** on limbs and trunk
- Joint symptoms in adults
- Immune complex-mediated hypersensitivity reaction

Risk factors for **Transient Aplastic Crisis** in Parvovirus B19
?
- Sickle cell disease
- Thalassemia
- Acquired hemolytic anemia

Complication of Parvovirus B19 in **immunocompromised patients**::Pure red cell aplasia (chronic bone marrow suppression resulting in severe anemia)

Management of Parvovirus B19
?
- Symptomatic treatment
- Transfusion therapy in severe anemia
- Commercial IVIg with neutralizing antibodies for persistent infections

Common cause of post-transfusion hepatitis::Hepatitis C

Enterically transmitted hepatitis::Hepatitis E

Definition of Clinical Jaundice in Hepatitis
?
- RUQ pain and discomfort
- Splenomegaly and cervical LAD
- Mild weight loss

Recovery is prolonged in Hepatitis ==B and C== at about ==3-4 months== for 75% of uncomplicated cases

Elements of Liver Inflammation in Hepatitis
?
- Panlobular infiltration with **mononuclear cells**
- Hepatic cell **necrosis**
- Hyperplasia of **Kupffer cells**
- Variable degrees of **cholestasis**

Serologic diagnosis of acute Hepatitis A::Positive Anti-HAV IgM

Virus with circular DNA genome that is partly single and partly double stranded::Hepatitis B
Envelope antigens of Hepatitis B::HBsAg and HBeAg
Nucleocapsid antigen of Hepatitis B::HBcAg
Assay results indicating successful vaccine response to HBV immunization::Positive Anti-HBs only

First line drugs for Chronic Active Hepatitis B
?
- Pegylated IFN alpha-2a
- Entecavir
- Tenofovir

Mechanism of action of Entecavir::Guanosine analogue inhibitor of Hep B polymerase
MOA of Tenofovir::Nucleotide analog inhibitor of Hep B reverse transcriptase and polymerase
Second line drug for Chronic Active Hepatitis B::Telbivudine
MOA of Telbivudine::Cytosine analog inhibitor of Hep B DNA polymerase
Third line drugs for Chronic Active Hepatitis B::Lamivudine and Adefovir
MOA of Lamivudine and Adefovir::Nucleoside analog viral polymerase inhibitor

Most effective measure of preventing Hepatitis B::Vaccination with recombinant DNA vaccine made of HBsAg from yeast or mammalian cell lines
Most common non-A and non-B hepatitis::Hepatitis C

Enzyme immunoassay target for Hepatitis C diagnosis::Core, envelope, NS3, and NS4 proteins
First line treatment for Hep C::Pegylated IFN + Ribavirin
Second line drugs for Hep C::Sofusbuvir and Simepravir
Hep C drugs that act as protease inhibitors but are not commonly used due to their toxic effects::Teleprevir and Boceprevir 

Linear non-segmented (-)ssRNA virus that is a common cause of **respiratory illness** for all ages::Parainfluenza
Peak infection season for Parainfluenza::Cold season (September to December)
Envelope protein of parainfluenza important for viral assembly::Matrix Protein
Parainfluenza type associated with Laryngotracheobronchitis::1 and 2
Diseases associated with Parainfluenza type 3::Bronchiolitis and Pneumonia
Disease associated with Parainfluenza type 4::Mild cold-like syndrome
Most common complication of Parainfluenza::Otitis Media

Management of Parainfluenza infections
?
- Supportive management with steroids and racemic epinephrine
- Ribavirin (for immunocompromised)

Clinical manifestations of Laryngeotracheobronchitis
?
- Seal bark coughing
- Inspiratory stridor
- Fever

Antigenically highly variable influenza and responsible for most epidemics::Influenza A
Antigenically stable influenza that only produces mild illness in immunocompetent individuals::Influenza C
Refers to the mixture of gene segment between different viruses of the same type creating sudden change in viral surface antigens:::Genetic reassortment
Refers to drastic changes in viral sequence form genetic reassortment between viruses from different species:::Antigenic shift
Minor antigenic changes via accumulation of point mutations in genes that can alter antigenic sites:::Antigenic drift
A variant must have ==≥2== mutations before a new epidemiologically significant strain emerges
Protein responsible for lowering viscosity of mucus in respiratory tract:::Neuraminidase
Most common cause of pneumonia in influenza patients::Staphylococcus aureus

Contributing factors to development of Pneumonia with Influenza infection
?
- Loss of ciliary clearance
- Dysfunctional phagocytosis
- Alveolar exudates provide rich bacterial growth medium

Treatment for Influenza
?
- Amantadine hydrochloride (M2 channel inhibitor)
- Oseltamivir, Zanamivir, and Peramivir (Neuraminidase inhibitor)

Inactivated vaccine formulation for influenza::Cocktail of 1-2 influenza A virus and 1 influenza B virus strain isolated in previous winter outbreak

Diseases caused by Coxsackievirus A
?
- Hand-foot-mouth disease
- Herpangina
- Acute hemorrhagic conjunctivitis
- Aseptic meningitis

Diseases caused by Coxsackievirus B
?
- Myocarditis
- Pleurodynia
- Pericarditis
- Aseptic meningitis
- Severe generalized disease in infants

Clinical Manifestations of Hand-foot-and-mouth disease
?
- Oral and pharyngeal ulcer
- Vesicular rash in palms and soles spreading to arms and legs that **heal without crusting**
- Nail shedding (in severe infections)

Clinical Manifestations of Herpangina
?
- Abrupt fever
- Sore throat
- Discrete vesicles on posterior half of palate, pharynx, tonsils, or tongue

Clinical Manifestations of Pleurodynia
?
- Chest pain lasting 2 days to 2 weeks
- Malaise, headache, anorexia

SARS-CoV-2 is closely related to SARS and coronaviruses from ==bats and pangolins==

Pharmacologic Management of COVID
?
- Remdesivir (antiviral)
- Tocilizumab and Dexamethasone (immunomodulator)
- Convalescent plasma and IVIg

