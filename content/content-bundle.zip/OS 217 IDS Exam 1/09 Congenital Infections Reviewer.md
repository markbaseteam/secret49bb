---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[09 Congenital Infections]]

[2023, 2024] An adolescent primigravid is consulting at the Teen Mom clinic for her first prenatal checkup. You recommend screening for syphilis as part of the baseline laboratories. If the adolescent has **positive treponemal and non-treponemal test results**:
A. False positive
B. True positive
C. Infant needs evaluation but no treatment if mother received Penicillin >4 weeks before delivery
D. Infant titer less than fourfold compared to mother means treatment is no longer required in infant
?
B. True positive
*False positive if positive nontreponemal and negative treponemal*

[2023, 2024] A newborn presents with **jaundice**, for which congenital infection is being considered. Which of the following statements about diagnostic testing for congenital infections is TRUE?
A. The entire TORCH battery of serologic tests should be requested because it has high diagnostic yield
B. Individual diagnostic tests are inefficient
C. Toxoplasmosis is best diagnosed using cultures
D. Syphilis and rubella are currently diagnosed using serologic methods
?
D. Syphilis and rubella are currently diagnosed using serologic methods

[2023, 2024] A pregnant woman now in her 4th month of pregnancy is exposed to her **niece with a fever and rash**. Which of the following is appropriate for the prevention of congenital rubella syndrome?
A. Administer antivirals for pregnant exposed mother
B. Inactivated rubella vaccine for pregnant women
C. Rubella vaccine administered during pregnancy
D. If pregnancy inadvertently occurs within 28 days of rubella vaccination, interruption of pregnancy is probably warranted
?
D. If pregnancy inadvertently occurs within 28 days of rubella vaccination, interruption of pregnancy is probably not warranted
*No risk of offspring developing CRS. Management should just be evaluation and follow-up and there is no need for antivirals. Rubella vaccine should not be given in pregnancy and there is no inactivated vaccine*

[2023, 2024] An adolescent primigravid is consulting at the Teen Mom clinic for her first prenatal checkup. You recommend screening for syphilis as part of the baseline laboratories. Which of the following is correct regarding the interpretation of her test results?
A. Treponemal tests cross-react with cardiolipin-lecithincholesterol antigens of damaged host cells
B. Treponemal tests become positive soon after initial infection and usually remain positive for life, even with adequate therapy
C. Non-treponemal tests have no value in screening/monitoring of treatment response
D. Pregnancy can give a false positive treponemal test result
?
B. Treponemal tests become positive soon after initial infection and usually remain positive for life, even with adequate therapy
*Treponemal tests cannot distinguish active and inactive infection. Choice A, C, and D should be nontreponemal test instead.*

[2023, 2024] Which of the ff. is true about congenital toxoplasmosis?
A. Congenital toxoplasmosis occurs when mothers have been infected long before their pregnancy
B. Congenital infection always presents as severe neonatal disease
C. The characteristic triad of congenital toxoplasmosis includes chorioretinitis, hydrocephalus, and cerebral calcifications.
D. Among congenitally infected infants considered normal during the perinatal period, ear involvement develops later in life if not treated during infancy.
?
C. The characteristic triad of congenital toxoplasmosis includes chorioretinitis, hydrocephalus, and cerebral calcifications.
*Congenital toxoplasmosis occurs when mothers are infected a short time before or during pregnancy. Its presentation varies from mild to severe neonatal disease. Left untreated, it can lead to ocular involvement*

[2023] A pregnant woman now in her 4th month of pregnancy is exposed to her niece with a fever and rash. If the rash is diagnosed as rubella, which of the following findings may be expected in the infant?
A. Neonatal purpura presents as the most common finding in congenital rubella syndrome
B. Cardiac abnormality is more likely if exposure occurs later during pregnancy
C. Patent ductus arteriosus is the most frequently reported cardiac defect
D. Deafness results from malformation of the external ear
?
C. Patent ductus arteriosus is the most frequently reported cardiac defect
*Rubella is highly associated with cardiac abnormalities*

[2023] True about CMV Infections
A. Infection is acquired by ingestion of CMV-containing breastmilk
B. The majority of infected newborns will have severe multiorgan disease
C. Hearing loss is the most common long term sequela
D. Chorioretinitis is a very common finding
?
C. Hearing loss is the most common long term sequela

# Personal Questions
Challenges with diagnosing Congenital Infections
?
- Clinical **features overlap** and may initially be indistinguishable
- **Unapparent** disease
- **Maternal** infection is often asymptomatic
- Need for special **lab** studies
- Appropriate **management** needs accurate diagnosis

Infections known to produce congenital defects
?
- Toxoplasma gondii
- Others (Parvo B19, VZV, West Nile Virus, HIV, Zika)
- Rubella
- CMV
- HHV
- Syphilis

Conditions that should raise suspicion for intrauterine infection
?
- IUGR
- Hematologic symptoms on any of the 3 cell lines
- Ocular symptoms
- CNS symptoms
- Other organ involvement (pneumonia, myocarditis, nephritis, hepatitis, jaundice)
- Non-immune hydrops (generalized ascites)

Late sequelae of intrauterine infections
?
- Deafness
- Dental or skeletal problems (rare for Toxoplasmosis)
- Mental retardation
- Seizures

How do you differentiate infection from placental transmission for IgG serology?::Persistent levels of IgG over months means that it is a true infection while those that decrease means that it came from the mother of the child. At the same time, if the mother's IgG levels are higher than the infant, this makes infection less likely.

How is toxoplasmosis acquired?
?
- Consumption of undercooked or raw meat containing cysts
- Consumption of food or handling material contaminated with oocysts from acutely infected cats or transported by flies or roaches

Toxoplasmosis can be transmitted to the fetus via ==transplacental infection (true) and during delivery (acquired)==

Toxoplasmosis infection has more severe consequences for fetuses in the ==first== trimester

Almost all infants who got infected with ==toxoplasmosis== develop ==ocular== problems by adolescence if left untreated in infancy

Characteristic Triad of Congenital Toxoplasmosis Infection
?
- Chorioretinitis
- Hydrocephalus
- Cerebral Calcifications

Diagnostic laboratory finding for toxoplasmosis::Persistent or rising IgM titers of toxoplasmosis antibodies

When do untreated toxoplasmosis-infected infants begin to produce IgG::3rd month of life

First line management for Toxoplasmosis infection::Pyrimethamine-sulfadiazine with leucovorin

MOA of Pyrimethamine::Inhibitor of dihydrofolate reductase involved in folic acid synthesis (should not be given in the first trimester of pregnancy)

Use of Leucovorin in toxoplasmosis management::Prevents bone marrow suppression

Indication for Prednisone in Toxoplasmosis infection::Active chorioretinitis involving the macula and threatening vision or CSF protein < 1000 mg/dl at birth

Most important risk factor for severe congenital defects with Rubella infections::Stage of gestation at time of infection

Defects occurring after the ==16th== week of gestation with Rubella infection are uncommon even with fetal infection

Most distinctive feature of **Congenital Rubella Syndrome** among other congenital infections::Chronicity (virus persists well beyond delivery)

==Sensorineural hearing loss== is the most common finding for ==Congenital Rubella Syndrome==

==Rubella== should be a primary differential for congenital infection if there are ==cardiovascular== defects

==Blueberry Muffin Baby== is the most easily recognizable sign of **Rubella** infection and is due to the ==erythropoiesis in the dermis (extramedullary hematopoiesis)==

Most **common** ocular abnormality with Congenital Rubella Syndrome::Salt and pepper retinopathy

Most **serious** ocular abnormality with Congenital Rubella Syndrome::Unilateral or bilateral cataracts

Most common diagnostic test for Congenital Rubella Syndrome::Rubella IgM ELISA of the infant or mother

False-==negative== IgM results to Rubella can happen with ==competing IgG antibodies==

Virus that can cause mononucleosis-like syndrome with fatigue, cervical LAD, mild transaminitis, and decreased PLT::Cytomegalovirus

==Hearing loss== is the most common long-term sequelae for ==congenital CMV==

Treatment for infants with severe perinatal CMV infection following breastmilk ingestion::Ganciclovir

Early diagnostic study for Congenital CMV infection::CMV IgM reactivity

Infants who get ==intrauterine== HSV infection have more severe presentations

Factors defining Clinical Presentation of Congenital HSV
?
- Timing of Infection
- Portal of Entry
- Extent of Spread

Patterns of Disease for HSV infections acquired during delivery or postpartum
?
- Disease localized to **skin, eyes, mouth**  (present at 5th-11th day)
- Encephalitis ± skin, eye, mouth disease (present at 8th-17th day)
- Disseminated infection involving multiple organs (brain, lungs, liver, heart, adrenals, skin) (present at 5th to 11th day)

Gold standard for diagnosing congenital HSV infection::Virus Culture
Specimen with highest yield for congenital HSV infections::Suspected herpetic vesicle (vigorously rub the base then use sterile swab to collect fluids and cells)

Management for Congenital HSV Infections::**Acyclovir**, Valacyclovir, and Famciclovir

All stages of **congenital syphilis** are characterized by ==Vasculitis progressing to necrosis and fibrosis== 

Characteristic hematological findings in congenital syphilis
?
- Coombs(-) Hemolytic Anemia
- Thrombocytopenia (often from platelet trapping in splenomegaly)

Characteristic features of **mucous membrane involvement** in congenital syphilis
?
- Mucous patches
- Persistent Rhinitis
- Condylomatous lesions

==Wimberger's lines== are X-ray findings in congenital syphilis representing the ==metaphyseal demineralization of medial aspect of proximal tibia==

X-ray findings in Congenital Syphilis
?
- Wimberger's lines
- Multiple sites of osteochondritis at the wrists, elbows, ankles, and knees
- Periostitis of long bones and rarely, the skull

Painful osteochondritis with irritability and refusal to move the involved extremity:::Pseudoparalysis of Parrot

Gold standard for diagnosis of congenital syphilis::Syphilis antigen detection

Diagnosis of primary syphilis::Direct demonstration of Treponema pallidum with dark-field microscopy or direct fluorescent antibody microscopy





