---
tags: OS217/IDS, flashcards
type: Exam
---
lecture:: [[12 Tuberculosis in Adults]]

[2023, 2024] A 38 year old male comes to the clinic with **chief complaint of night fevers, cough for 4 weeks and 6 kg weight loss**. He is a public school teacher in Bulacan. He was worried about the possibility of lung cancer as he had two other coworkers who were recently diagnosed to have cancers. He claims to have been **treated for TB in 2012 but vaguely remembers how many months he was on the medicines**. On PE he had normal vital signs. **His lungs had decreased breath sounds at both lung bases**. Heart, abdomen, and extremities were normal. The most appropriate initial diagnostic test for this patient is:
A. NP SARS CoV-2 RT PCR, Sputum GeneXpert MTB test and Chest Xray
B. NP SARS CoV-2 RT PCR, Sputum GC CS, AFB, TB culture and sensitivity and Chest Xray
C. NP SARS CoV-2 RT PCR and CT Scan Chest
D. NP SARS CoV-2 RT PCR and if negative proceed to bronchoscopy with bronchoalveolar lavage for bacterial viral cultures and cytology
?
A. NP SARS CoV-2 RT PCR, Sputum GeneXpert MTB test and Chest Xray
*Patient had undergone treatment before thus, should scan for Drug Resistant TB since the patient is presumptive TB*

[2023, 2024] Which of the following are true regarding extrapulmonary TB?
A. The most frequently seen EPTB globally and in the Philippines is Potts disease or TB of the bone, followed by TB adenitis, TB meningitis, and TB of the liver.
B. Miliary TB refers to the hematogenous spread of the tubercle bacilli frequently suspected by classic Chest X-Ray findings and requires the use of glucocorticoid therapy to achieve cure
C. Without treatment, pericardial TB may lead to chronic constrictive pericarditis and would usually be fatal
D. The gold standard of the diagnosis of TB meningitis is by CSF AFB and TB PCR studies
?
C. Without treatment, pericardial TB may lead to chronic constrictive pericarditis and would usually be fatal
*Lymphatic, pleural, and bone EPTB are the most common. Miliary TB present as millet-like seeding of bacilli. Gold standard for meningeal TB is CSF TB PCR.*

[2023, 2024] Among the following cases, who has the highest risk to develop active TB in the next six months and thus be given isoniazid for TB prophylaxis?
A. 80-year old Lola C with poorly controlled DM
B. 65-year old Lolo with 63 pack year smoking, COPD, and bronchiectasis
C. 23-year old SAGIP/HIV patient with CD4 count of 10 with a normal Chest X-Ray and negative sputum GeneXpert test
D. 30-year old COVID-19 patient
?
C. 23-year old SAGIP/HIV patient with CD4 count of 10 with a normal Chest X-Ray and negative sputum GeneXpert test
*Although the other choices have comorbidities, the low CD4 count predisposes the patient towards intracellular pathogens like TB. Only PLHIV and children with household contacts are indicated for the use of INH for prophylaxis*

[2024] Among the following TB patients, the most infectious case and likely to transmit TB to other individuals is:
A. Mr. X admitted initially for COVID-19 and during workup also found to have TB culture-positive, AFB smear-negative pulmonary TB
B. Mrs. Y with disseminated TB in the liver, spleen, ovaries, adrenals, and kidneys
C. Mr. Z with HIV and pulmonary TB
D. Professor ABC with cavitary TB
?
D. Professor ABC with cavitary TB
*Choices A, B, and C are less likely to have had contacts with others while D is a professor and most likely interacted with many people*

[2023] Globally, the most frequently encountered EPTB site::Lymph Nodes

[2023] The clinical course of TB is best described as follows:
A. Early in the course of disease, symptoms and signs are often nonspecific and insidious, consisting mainly of fever, night sweats, weight loss, anorexia, general malaise, and weakness.
B. Cough is present in 100% of cases, initially nonproductive and limited to the morning and subsequently accompanied by the production of purulent sputum.
C. Hemoptysis develops in all forms of TB with cases with massive hemoptysis occurring as a consequence of the erosion of a blood vessel in the wall of a cavity.
D. Physical findings are of great use in pulmonary TB as all patients have wasting and gross abnormalities during chest examination such rales especially after coughing, rhonchi due to partial bronchial obstruction and classic absent breath sounds in areas with large cavities.
?
A. Early in the course of disease, symptoms and signs are often nonspecific and insidious, consisting mainly of fever, night sweats, weight loss, anorexia, general malaise, and weakness.
*Cough is only present 90% of the time. Hemoptysis happens in 20-30% of cases. Physical findings are of limited use in PTB.*

[2023] Which of the ff. is true about TB?
A. The four first line drugs are all well-absorbed when taken orally, most bactericidal, all with low rates of induction of drug resistance
B. The first-line drugs include: INH, Rifampicin, Pyrazinamide, Ethambutol, Streptomycin, and Ciprofloxacin
C. As daily doses, INH should be at 5 mg/kg, Rifampicin at 10 mg/kg, PZA at 15 mg/kg, and Ethambutol at 25 mg/kg
D. For patients whose TB is resistant to all first-line agents, cure is still possible using combination of ≥6 second line including one injectable agent
?
A. The four first line drugs are all well-absorbed when taken orally, most bactericidal, all with low rates of induction of drug resistance
*Streptomycin and Ciprofloxacin are not first line drugs. PZA always has larger doses than Ethambutol. XDR-TB has few treatment options*

# Personal Questions
Risk Factors for TB
?
- Smoking (M > F)
- Older than 65 y/o
- Male
- History of TB
- Diabetes mellitus
- Poverty
- Urban dwelling

Initially identified TB case that may or may not be the source case::Index case
Person with infectious TB responsible for transmitting TB to another person::Source Case

Presumptive TB case definition
?
- Cough ≥2 weeks ± weight loss, fever, hemoptysis, chest/back pains, night sweats, dyspnea, or DOB
- Unexplained cough of any duration (high risk groups or exposed)
- CXR findings suggestive of PTB ± symptoms

Presumptive EPTB
?
- Gibbus deformity
- Non-painful cervical LAD ± fistula
- Nuchal rigidity and/or drowsiness suggestive of TB meningitis that is not responding to antibiotics w/ subacute onset or raised ICP
- Pleural effusion
- Pericardial effusion
- Distended abdomen with ascites
- Non-painful enlarged joint
- Tuberculin hypersensitivity

High Risk Clinical Groups for TB
?
- HIV/AIDS
- DM
- ESRD
- Autoimmune disease
- Silicosis
- Post-gastrectomy or solid organ transplant
- Prolonged systemic steroids

High Risks Populations for TB
?
- Inmate
- Elderly
- Indigenous People
- Urban/Rural
- Current smoker

Management for household contacts of suspected TB::CXR all household members
Management for household contacts of DR-TB::CXR on all members and refer as presumptive TB to DOTS facility

Screening for TB in PLHIV is done upon ==HIV diagnosis== and ==annually== during follow-up visits

Primary screening for TB::Chest X-ray
Best specimen available for TB diagnosis::Cough sputum (early AM)
Best available tool for assessing TB infectiousness::AFB smear
Gold standard for TB diagnosis::Culture and identification of isolate

==PCR== testing for TB is done for ==sterile== samples

==Standard PA and lateral== CXR films are used to check for ==infiltrates, nodular densities, cavities, ± hilar adenopathy== in TB patients

TB with resistance to at least **isoniazid and rifampicin**:::Multi-drug-resitant TB (MDR-TB)
TB with resistance to **second line anti-TB medication**:::Extensive drug-resistant TB (XDR-TB)

Risk factors for activation of Latent TB
?
- Less than 4 y/o
- HIV patient
- Disease that impairs lung defense (T2DM, silicosis, immunosuppression, patients prepared for SOT or HSCT)
- Taking Immunosuppressants
- CKD or in dialysis

Management for MDR-TB::8 months of ≥4 second-line anti-TB drugs + PZA

