---
tags: OS217/IDS, flashcards, 
type: Exam
---
lecture:: [[04 Control of Communicable Diseases]]

[2023, 2024] Which of the following is NOT an exclusive human infection?
A. Gonorrhea
B. Measles
C. Typhoid fever
D. Rabies
?
D. Rabies
*Rabies is zoonotic mainly involving infected dogs but can also come from cats and other domestic animals*

[2023, 2024] Anopheles mosquito is what type of vector?::Biological insect vector (Plasmodium needs Anopheles for its development allowing for survival and transmission)

[2023, 2024] Which of the following is true of direct mode of transmission?
A. Require close association between infected and resistant host
B. From person to person by close association like sexual contact
C. Vector borne
D. Both A and B only
?
B. From person to person by close association like sexual contact
*A is wrong as it needs a susceptible host and C means that it is indirect transmission*

[2024] What is the etiologic agent of the notifiable disease whooping cough?::Bordetella pertussis

[2023, 2024] Established mode of transmission of COVID::Direct transmission through droplet nuclei

[2024] The ease by which an infectious agent is transported through the environment and spread to other hosts is determined by the ff. except?
A. Ability to survive away from host
B. Mode of transmission
C. Ability to infect non-human hosts
D. Ability to cause severe disease
?
D. Ability to cause severe disease
*A, B, and C along with ability to multiply in the environment are the determinants of infectiousness. Severe disease is not associated with infectiousness*

[2024] What type of outbreak is seen below?
![[Outbreak Image.png]]
?
Disseminated outbreak with propagation

[2023] In the 4C's of control of infectious diseases what should be done to carriers?
?
Detected
![[4Cs of Control of Infectious Disease.png]]

# Personal Questions
Components of Epidemiologic Triangle
?
- Agent
- Host
- Environment

The ==Law on Reporting of Notifiable Diseases (RA 3573)== mandates the ==immediate reporting of any notifiable disease to the nearest health officer==

Refers to the summary of all notifiable diseases for the year::Field Health Service Information System (FHSIS)

The host should be ==susceptible== for particular disease to occur

Usually the target of interventions in communicable disease::Environment

Diseases that occur occasionally in population at irregular intervals:::Sporadic Disease
Diseases continually present in population at steady levels:::Endemic Disease
Slight increases in level of disease over endemic level:::Outbreak
Diseases acquired by many hosts in given area at short amount of time with sudden increase in morbidity and mortality:::Epidemic Disease
Refers to a worldwide epidemic:::Pandemic

Epidemic with single source characterized by sudden increase in number of cases that is easier to control and curtail immediately:::Common-source Epidemic
Epidemic where there are multiple possible sources and hosts with prolonged and slow rise in cases:::Host-to-Host epidemics

Necessary changes for Epidemic to occur
?
- Change in population's vulnerability
- Change in virulence of infectious agent
- Change in environment to promote exposure

Site used to maintain ability of pathogen to infect and replicate::Reservoir
Object, place, or person from which pathogens originate and can be passed unto the host
Organisms that carry pathogens around but are not necessary for the pathogen's development and replication:::Mechanical Vectors
Organisms that serve as reservoir, transmit pathogens, and are required for ≥1 part of development of the pathogen:::Biological Vectors
Transmission involving close association of infectious agent and *susceptible host*:::Direct contact transmission


