---
quickshare-date: 2023-01-30 16:58:43
quickshare-url: "https://noteshare.space/note/cldikwnlg349901pjecrabua3#PhD37sWxKRZRo8gRQHGfZdS/QTvClRIsqI86UaD0ciY"
title: "Radiology Reviewer"
banner_icon: 📝
tags: flashcards, RADIO250
type: Exam
date: 2023-01-30
---
# 🖇️ Important Links
- [RADIO 250 Viewboxes](https://docs.google.com/presentation/d/1Kpv4XETLqT7AfxIOnBhv9ElPhYGcMKAVtNQOQ_RSzTA/edit#slide=id.g1ecbddbdd22_0_138)
- [Exams](hook://file/NAqy4PNjG?p=RG9jdW1lbnRzL1JBRElPIDI1MA==&n=Exams)
- [Transes](hook://file/NArGMMzdT?p=RG9jdW1lbnRzL1JBRElPIDI1MA==&n=Transes)

# [[01 Introduction to Radiology]]

# [[03 Radiation Protection]]
[2024] Which of the following statements best describes the deterministic type of effects of radiation?
A. All or nothing effects
B. The severity of dose-effect increases with dose above the threshold and the effect is clearly due to damage to many cells
C. There is no threshold, but there is also no dose below which the probability of an effect is zero
D. Examples: Cancer or heritable effects

>[!info]- Answer
> **B. The severity of dose-effect increases with dose above the threshold and the effect is clearly due to damage to many cells**
> *A, C, and D are all definitions of the Stochastic Effect where it is an all-or-none effect, non-dose-dependent, and related to cancer*

[2024] Which of the following statements best describes stochastic type of effects of radiation
A. Presence of a dose threshold to the production of a tissue reaction
B. Examples: effects on fertility, lethality due to total body exposure, failure of an organ such as the kidney due to radiation exposure
C. Threshold curve is sigmoid shape
D. The severity of the effect is not dose-dependent although the probability of the effect occurring increases with dose

>[!info]- Answer
> **D. The severity of the effect is not dose-dependent although the probability of the effect occurring increases with dose**
> *A, B, and C are all descriptions of Deterministic Effects*

[2024] Is a principle of Radiation Protection based on US National Council for Radiation Protection
A. ALAPM (as low as possibly meaningful)
B. ALAPA (as low as possibly achievable)
C. ALARM (as low as reasonably meaningful)
D. ALARA (as low as reasonably achievable)

>[!info]- Answer
> **D. ALARA (as low as reasonably achievable**)
> *The need to ensure that social detriment from such justifiable activities or practices is maintained ALARA*

[2024] Which of the following statements best describes the term "de minimis dose"
A. Annual effective dose of 0.01 mSv
B. Impossible to achieve
C. Negligible collective dose
D. Equivalent to absolute zero dose exposure

>[!info]- Answer
> **A. Annual effective dose of 0.01 mSv**
> *The NRCP describes it as the negligible **individual** dose and is the dose below which further efforts to minimize radiation exposure is unwarranted. It is considered to be an annual effective dose of 0.01 mSV*

[2024] Which of the following statements best describes the term "equivalent dose"
A. Quantified in units of "Gray"
B. Average absorbed dose x radiation weighting factor(s)
C. Used to describe populations
D. Dose integrated over 50 years

>[!info]- Answer
>**B. Average absorbed dose x radiation weighting factor(s)**
>*ED is expressed in **Sievert** thus A is incorrect. C is incorrect as population values include collectiveffective dose and collective committed effective dose. Doses integrated over 50 years should have **committed** in the name*


[2024] Which among the following organs is the least radiosensitive?
A. Breast tissue
B. Thyroid gland
C. Gonads
D. Brain

>[!info]- Answer 
>**D. Brain** ?
>According to the Tissue Weighting Factor Values, the brain, the bone surface, the skin, and salivary glands contribute the least to the total detriment from uniform radiation of the whole body. 

[2024] Which organ system is the least radiosensitive?
A. Oral mucosa
B. Gut epithelium
C. Lymphatic tissue
D. Muscle tissue

>[!info]- Answer
>**D. Muscle tissue**
>Skin, bone, and muscles are the least radiosensitive parts of the body

[2024] What is the most lethal type of cellular DNA damage brought about by radiation?
A. Double strand break
B. Deamination
C. Single strand break
D. Ring formation

>[!info]- Answer
>**A. Double strand break**


# [[04 Normal Radiologic Anatomy of the Chest and Lungs]]
[2024] The minor fissure lies roughly horizontal at about the level of the 4th rib anteriorly and separates:
A. The superior segment of the right lower lobe from the middle lobe
B. The anterior segment of the right upper lobe from the middle lobe
C. The apicoposterior segment of the right upper lobe from the middle lobe
D. The apicoposterior segment from the anterior segment of the right upper lobe

>[!info]- Answer
>**B. The anterior segment of the right upper lobe and the middle lobe**
> ![[SC-Arc-01_23_2023-15_07.png|500]]

[2024] The anterior mediastinum contains all of the structures except:
A. Thyroid gland
B. Thymus
C. Trachea
D. Internal mammary arteries and veins

>[!info]- Answer
>


[2024] On the lateral projection the anterior border of the cardiac silhouette is formed by the:
A. Left atrium
B. Right ventricle
C. Right atrium
D. Left ventricle

>[!info]- Answer
>**B. Right Ventricle**
>The right ventricle forms the anterior border. The left atrium forms part of the left and posterior borders. The right atrium forms part of the right border. The left ventricle forms part of the left and posterior borders.

[2024] The branches of this bronchus assumes the shape of a whale on CT scan:
A. Right middle lobe bronchus
B. Right upper lobe bronchus
C. Left upper lobe bronchus
D. Right lower lobe bronchus

>[!info]- Answer
>**B. Right upper lobe bronchus**
>The right upper lobe bronchus branches to form the shape of a whale on CT
>![[SC-Arc-01_23_2023-16_00 1.png]]

[2024] This bronchopulmonary segment of the right lung is almost at the same level as the middle lobe on CT scan:
A. Posterior basal segment of the lower lobe
B. Anterior segment of the upper lobe
C. Anteromedial basal segment of the lower lobe
D. Superior segment of the lower lobe

>[!info]- Answer
>**D. Superior Segment of the Lower Lobe**
>![[SC-Arc-01_23_2023-16_01 1.png]]

# [[05 Pathological Conditions in Chest Radiology]]
[2024] A thin walled lucency is seen in the periphery of the right upper lung field. Which of the following is least likely impression?
A. Bleb
B. Pulmonary cavity
C. Bulla
D. Pneumothorax

>[!info]- Answer
>**B. Pulmonary Cavity**
>A cavity is a focus of increased density whose central portion has been replaced by air. It is usually surrounded by a wall of variable thickness measuring >2 mm thus it cannot be a thin-walled lucency.

[2024] Chest x-ray reveals a heterogenous fairly defined pulmonary mass in the left upper lung field demonstrating a crescent shaped lucency in it’s superior portion. Findings are consistent with what?
A. Canon ball metastasis
B. Pleural-based mass
C. Primary pulmonary malignancy
D. Aspergillosis

>[!info]- Answer
>**D. Aspergillosis**
>Aspergillosis features pulmonary cavities with a fungus ball and crescent-shaped lucency representing an air-pocket. It is described as a heterogenous opacity in the left mid- to -upper lung fields associated with a crescent sign
>![[SC-Arc-01_23_2023-17_28.png|500]]

[2024] Chest x-ray of a 60 year-old female patient with cough reveals suspicious opacities in the right lung apex. What ancillary study should you request for?
A. Cone view of the lung apices
B. Apicolordotic view
C. Serial radiographs
D. Right lateral view

>[!info]- Answer
>**B. Apicolordotic View**
>Opacities in the apex are best investigated using an apicolordotic view where the ribs are veered away from each other to provide clear view of apical lung parenchyma. It is also useful for patients who have pacemakers installed

[2024] Which of the following is a direct sign of atelectasis?
A. Superior displacement of the minor fissure
B. Wedge-shaped pulmonary opacification
C. Tracheal deviation
D. Elevation of the hemidiaphragm

>[!info]- Answer
>**A. Superior displacement of the minor fissure**
>The direct signs for atelectasis include the following:
>- Displacement of interlobar fissures
>- Crowding of pulmonary vessels
>- Crowded air bronchograms (only seen in subsegmental atelectasis)

# [[07 Basic Cardiac Radiology]]
[2024] Which of the following is normally not part of the three contours along the left cardiomediastinal silhouette?
A. Left ventricle
B. Left atrial appendage
C. Left main pulmonary artery
D. Aortic knob

>[!info]- Answer
>**D. Aortic Knob**
>The left border of the heart on frontal projection is formed by the main and left pulmonary artery, the left atrium, the left atrial appendage, the left ventricle, and the **aortic arch**

[2024] Which of the following cardiac pathology is not usually expected to present with hypervascular lungs?
A. Patent ductus arteriosus
B. Atrial septal defect
C. Tetralogy of Fallot
D. Ventral septal defect

>[!info]- Answer
>**C. Tetralogy of Fallot**
>Tetralogy of Fallot is mainly linked with decreased vascularity
>![[SC-Obsidian-01_30_2023-13_24.png]]

[2024] Which of the following chest x-ray findings is not usually seen in the most common acyanotic congenital heart anomaly?
A. Enlargement of the aortic knob
B. Prominent left ventricle
C. Large main pulmonary artery segment
D. Enlargement of the left atrium

>[!info]- Answer
>**A. Enlargement of the Aortic Knob**
>The most common acyanotic CHD is VSD. VSD features a left-to-right shunt thus, it is expected that the left atrium and ventricle would enlarge to deliver enough blood to the body as it is losing some blood going into the pulmonary circulation. A large main pulmonary artery is expected as more blood than normal is entering the right side of the heart to go into the lungs

[2024] Which of the following chest radiograph findings is not compatible with atrial septal defect?
A. Right atrial enlargement
B. Right ventricle enlargement
C. Left atrial enlargement
D. Increased pulmonary vascularity

>[!info]- Answer
>**C. Left atrial enlargement**
>The left atrium is normal sized in ASD unlike in VSD or PDA. A, B, and D are expected radiologic findings for ASD

[2024] Which of the following chest radiograph findings is seen in patent ductus arteriosus?
A. Right-sided aortic knob
B. Hypovascular lungs
C. Right atrial enlargement
D. Left-sided enlargement

>[!info]- Answer
>**D. Left-sided enlargement**
>Uncomplicated PDA is expected to show enlargement of the left atrium and ventricles. With PDA, there is a connection between the aorta and the pulmonary artery. Because blood for the systemic circulation is leaking into the pulmonary circulation, the left side of the heart works to pump more blood

[2024] On chest radiograph, you noticed a boot-shaped appearance of the heart. Which of the following pathology is not part of your diagnosis?
A. Perimembranous ventricular septal defect
B. Right ventricular hypertrophy
C. All of the choices are part of the pathology
D. Overriding aorta
E. Pulmonary stenosis

>[!info]- Answer
>**A. Perimembranous Ventricular Septal Defect**
>A boot-shaped heart is a characteristic description for ToF. The VSD in ToF can be perimembranous, muscular outlet, doubly committed subarterial, or doubly committed subarterial with perimembranous extension

[2024] Figure of 3 sign on chest radiograph is usually noted in patients with?
A. Total anomalous pulmonary venous return (TAPVR)
B. Hypoplastic left heart syndrome
C. Coarctation of the aorta
D. Tetralogy of Fallot

>[!info]- Answer
>**C. Coarctation of the Aorta**
>![[Coarctation of the Aorta Figure 3.png|400]]

# [[19 Gastrointestinal Radiology]]
[2024] The following are EMERGENCIES where abdomen x-rays are very useful, EXCEPT:
A. Mechanical small bowel obstruction
B. Intussucception
C. Intestinal parasitism
D. Pneumoperitoneum
E. Volvulus

>[!info]- Answer
>**C. Intestinal parasitism**
>Parasitism is not considered a medical emergency, and in fact, there is a need to kill parasites prior to imaging with contrast as the contrast may cause agitation of the parasites. 

[2024] Plain abdomen x-ray commonly requested in imperforate anus is:
A. Plain abdomen x-ray in supine position
B. Rice-Wangenstein x-ray
C. Left decubitus view of the abdomen
D. Lateral view of the rectum

>[!info]- Answer
>**B. Rice-Wangenstein X-ray**
>Also known as an **invertogram** where a coin or metal piece is placed over the baby's expected anus then turned upside down for ≥3 minutes then the distance of the gas bubble in the rectum and metal piece is noted. A distance >2 cm indicates high type imperforate anus while <2 cm indicates low type. 

[2024] Part of the Plain abdomen series involves plain abdomen x-ray in prone position. If the patient cannot assume a prone position, what can be used as a substitute for it?
A. Left decubitus view of the abdomen
B. Lateral view of the rectum
C. Plain abdomen x-ray in supine position
D. Upright view of the chest

>[!info]- Answer 
>**C. Plain abdomen x-ray in supine position**
>The standard projections for an abdominal series include the AP supine view, the PA erect view, and the KUB view

[2024] Which of the following are key radiographic features of mechanical obstruction?
A. Fighting loops
B. Absent gas in the rectum
C. Dilated small bowel
D. Absent air-fluid level in the small intestine in the upright

>[!info]- Answer
>**A. Fighting loops**
>The dilated segments seen with obstruction are called fighting loops. Obstruction presents as an abrupt disappearance of air in dilated bowel loop segments

[2024] The following are radiographic findings of ruptured viscus, EXCEPT
A. Air between the diaphragm and the liver
B. Rigler’s sign
C. None of the choices
D. Falciform ligament sign
E. Pneumatosis intestinalis

>[!info]- Answer
>**E. Pneumatosis intestinalis**
>A rupture in the viscus would mean that air leaks out of the bowels and into the abdominal cavity. A, B, and D are signs of pneumoperitoneum seen with perforation of abdominal organs. Pneumatosis intestinalis meanwhile involves the presence of gas in the extraluminal space of the intestines caused by bowel necrosis, pulmonary disease, or abnormal mucosal permeability

[2024] Rat tail appearance in the ileocecal area seen on barium enema is indicative of:
A. Ileocecal Koch’s infection
B. Intestinal parasitism
C. Small intestinal polyposis
D. Gardners syndrome
E. Diverticulosis

>[!info]- Answer
>**A. Ileocecal Koch's Infection**
>Rat tail appearance is a characteristic finding for ileocecal tuberculosis. Contrast study shows thickening and/or incompetence of the ileocecal valve causing narrowing in the terminal ileum called Fleischner's sign


Which of the following radiographic findings can be seen in chronic granulomatous colitis?
A. Coarse granulations in the mucosa of the colon
B. All of the above
C. Stippling of the mucosa of the colon
D. Terminal ileum is commonly affected
E. Failure of the colonic wall to collapse in the post-evacuation phase of the barium enema study

>[!info]- Answer

[2024] A 50-year-old male patient presented in the outpatient department due to chronic cough, involuntary weight loss, and progressive chest pain. The chest radiograph done showed diffuse “cannon-ball” lesions within both lungs, normal heart and rib lytic changes. The abdomen sonogram done showed multiple circumscribed, hypoechoic solid lesions of varying sizes scattered within the enlarged liver. The other abdominal solid organs are unremarkable sonographically. The most probable diagnosis of the liver lesions is:
A. Liver schistosomiasis
B. Hepatic abscesses
C. Liver metastases
D. Liver tuberculosis

>[!info]- Answer
>**C. Liver metastases**
>Cannon ball term is a typical description for pulmonary metastases. Thus, the most probable diagnosis of the liver lesion is metastatic

[2024] A 43-year-old, obese, female patient consulted in the out-patient department due to progressive right upper quadrant abdominal pain. No other significant signs and symptoms elicited. The most cost-effective imaging modality of choice to be requested for this patient to confirm diagnosis will be:
A. Scout film of the abdomen
B. Magnetic resonance imaging
C. Computed tomography scan
D. Sonography

>[!info]- Answer
>**D. Sonography**
>Sonography would be the most cost effective modality for RUQ pain.

[2024] On routine pre-employment abdomen sonography, the official report released by the clinic showed a 2.0 cm mobile, echogenic focus with posterior acoustic shadowing located within the gallbladder lumen. The most likely diagnosis is:
A. Gallbladder polyp
B. Gallbladder lithiasis
C. Gallbladder ascariasis
D. Gallbladder sludge ball

>[!info]- Answer
>**B. Gallbladder lithiasis**
>A mobile echogenic focus with posterior acoustic shadowing is a typical description for a gallstone. 

[2024] Which of the following originates from the Laimer’s triangle?
A. Laryngocele
B. Achalasia
C. Zenker’s diverticulum
D. Riley-Day Syndrome

>[!info]- Answer
>**C. Zenker's Diverticulum**
>This diverticulum is an outpouching of the posterior hypopharyngeal wall near the pharyngeoesophageal junction originating from the Laimer's triangle or Killian's Dehiscence


# [[17 Solid Organ Imaging]]

# [[15 Introduction to Head and Neck Radiology]]
[2024] In Stenver's view, the following structures are expected to be seen except:
A. Mastoid antrum
B. Cochlea
C. Lateral sinus plate
D. Entire petrous pyramid

>[!info]- Answer
>**C. Lateral sinus plate**
>Stenver's view involves having the long axis of the petrous bone lie parallel to the film with the ff. structures visualized:
>- **Entire petrous pyramid**
>- Arcuate eminence
>- Internal auditory meatus
>- Labyrinth w/o vestibule
>- **Cochlea**
>- **Mastoid antrum**

[2024] This view is taken where the x-ray beam is projected 30 degrees cephalocaudal and prevents superimposition of two sides of mastoid
A. Submentovertical view
B. Schuller's view
C. Towne's view
D. Law's view

>[!info]- Answer
>**B. Schuller's View**
>The submentovertical view involves placement of the vertex of the skull near the film with the beam hitting the submental area. Towne's view involves an AP view of the skull with a 30º tilt from above and in front to show both petrous pyramids. Law's view is similar to Schuller's view but the angle is 15º instead

[2024] The submandibular lymph node station corresponds to what neck nodal station?
A. Level Ib
B. Level IIa
C. Level IIb
D. Level Ia

>[!info]- Answer
>**A. Level IB**
>![[02 Head and Neck Clinic-1668480891719.jpeg]]

[2024] Which of the following spaces is enclosed by the three layers of the deep cervical fascia?
A. Carotid space
B. Parapharyngeal space
C. Pharyngeal mucosal space
D. Parotid space

>[!info]- Answer
>**A. Carotid Space**
>![[Carotid Space Fascia.png]]


# Neuroradiology and Spine Imaging
[2024] A 70-year old hypertensive male came in complaining of the worst headache of his life. Physical examination showed neurologic deficits. CT Scan revealed a hyperdense area within the ventricles, interpreted as intraventricular bleed. Most common point of rupture is:
A. Anterior communicating artery
B. Bridging vein
C. Posterior communicating artery
D. Middle meningeal artery

>[!info]- Answer
>**A. Anterior communicating artery**
>Most common site for intracranial aneurysm

[2024] An 8-year old female was found to have dysmetria and ataxia. CT Scan revealed a midline cystic posterior fossa mass with some focal areas of calcification. The most common tumor in this area is:
A. Medulloblastoma
B. Astrocytoma
C. Ganglioneuroma
D. Glioma

>[!info]- Answer
>**A. Medulloblastoma** (?)
>Most common pediatric brain tumor and is typically found in the midline posterior fossa

[2024] What is the most common cause of intracerebral hemorrhage in the adult population?
A. AV Malformation
B. Ischemia
C. Hypertension
D. Bleeding disorders

>[!info]- Answer
>**C. Hypertension**

[2024] Which sequence of MRI best detects spinal edema from vertebral fractures?
A. T1-weighted contrast enhanced image
B. T1-weighted fat saturated image
C. T2-weighted image
D. T1-weighted image

>[!info]- Answer
>**C. T2-weighted images**
>Able to identify extent of edema and hemorrhage in the spine from vertebral fractures

[2024] It is the most common solid extra-cranial malignant tumor of childhood, with peak age at 22 months.
A. Ganglioneuroma
B. Wilms tumor
C. Neuroblastoma
D. Mesoblastic nephroma

>[!info]- Answer
>**C. Neuroblastoma**
# [[11 Pediatric Radiology]]
[2024] Most frequent cause of inadequate Radiographer image quality in pediatrics
A. Poor inspiratory effort
B. High MAs
C. Low KV
D. Incorrect positioning

>[!info]- Answer
>**D. Incorrect positioning**
>Positioning is the most frequent cause of inadequate radiographic image quality in pediatrics and should not be an excuse for substandard image quality

[2024] What should initially be considered when reading pediatric chest x-ray?
A. All of the choices stated should be considered.
B. Obliquity
C. Penetration
D. Inspiration

>[!info]- Answer
>

[2024] What can be done to help keep a child still during radiographic procedures?
A. Invite guardian in the x ray room
B. All of the stated choices can be done.
C. Have a calm atmosphere
D. Explain procedure to patient and guardian

>[!info]- Answer
>**B. All of the stated choices can be done**
>The 5-point model for immobilizing children are as follows:
>1. Prepare child and guardian for procedure and **explain their role**
>2. **Invite guardian to be present**
>3. use specific room for painful procueres
>4. Position child in comforting manner
>5. **Maintain calm and positive atmosphere**

[2024] What can be done to reduce radiation exposure to pediatric patients?
A. Put lead shield on areas outside of interest
B. Increase field size
C. Avoid collimation
D. Secure patient's hands and feet with linen to avoid motion

>[!info]- Answer
>**D. Secure patient's hands and feet with linen to avoid motion**
>A is incorrect as the lead shield should be in immediate proximity of the important diagnostic field. B is incorrect as it can increase unnecessary radiation dose to the patient. Collimation should be performed accurately to reduce dose


# [[12 Pediatric Radiology (Pathologic)]]
[2024] It is a viral infection that affects particularly the subglottic trachea and is the most common infectious disease of the upper airway in pediatric patients
A. Croup
B. Bacterial tracheitis
C. Retropharyngeal abscess
D. Epiglottitis

>[!info]- Answer
>**A. Croup** ?


# [[08 Introduction to Musculoskeletal Radiology]]

# [[10 Introduction to Ultrasound]]
[2024] Ultrasound works by the ability of materials within the transducer/probe to convert mechanical energy to electric potential. This ability is called?
A. Ultrasonography
B. Piezoelectricity
C. Doppler-shift
D. Radiology

>[!info]- Answer
>**B. Piezoelectricity**

[2024] What is the preferred transducer for deep structures? (Clue: has lower wavelength, thus better penetration of sound waves)
A. Curvilinear transducer
B. Endocavitary transducer
C. Linear transducer
D. Phased array transducer

>[!info]- Answer
>**A. Curvilinear transducer** 
>Used for evaluation of the abdomen, pelvis, and chest

[2024] What ultrasound mode is considered the mainstay of imaging? (Clue: the strength of the returning echoes correspond to the intensity of image on the screen)
A. Amplitude mode
B. Phasicity mode
C. Motion mode
D. Brightness mode

>[!info]- Answer
>**D. Brightness mode**
>Amplitude mode can only given the position and strength of the reflecting echo recorded and is for orbital ultrasound. Motion mode provides time/temporal resolution and is used for fetal heart activity. Phasicity mode was not discussed


[2024] What ultrasound mode is used to give a QUANTITATIVE evaluation of flow within a vessel?
A. Spectral Doppler
B. Elastography
C. Color Doppler
D. Power Doppler

>[!info]- Answer
>**A. Spectral Doppler**
>Color Doppler is limited to qualitative analysis while spectral doppler can be used to assess peak systolic velocity, end-diastolic velocity, resistive index, and pulsatility index

# [[18 Renal Imaging]]

# [[16 Mammography 101]]
[2024] TRUE of diagnostic mammography
A. It is done in women with family history of breast cancer.
B. It is an annual screening at age 40 for the general population.
C. It is done in women who do not have a personal history of breast cancer
D. It is done in women who have had a recent abnormal breast ultrasound

>[!info]- Answer
>**D. It is done in women who have had a recent abnormal breast ultrasound**
>A, B, and C are all definitions for *screening* mammography

[2024] On mammography, the following are classified as benign calcifications, EXCEPT:
A. Rim calcification
B. Dermal calcification
C. Popcorn-like
D. Fine pleomorphic

>[!info]- Answer
>**D. Fine pleomorphic**
>Calcifications suspicious for malignancy include amorphous, **fine pleomorphic**, coarse heterogeneous, fine linear, and fine linear branching calcifications

[2024] A category of BIRADS 0 means that,
A. It is a benign finding
B. It is highly suggestive of malignancy
C. It needs additional imaging
D. It is a negative finding

>[!info]- Answer
>**C. It needs additional imaging**
>![[SC-Obsidian-01_30_2023-14_51.png]]

[2024] A category of BIRADS 5 means that,
A. It is a benign finding
B. It needs additional imaging
C. It is highly suggestive of malignancy
D. It is a negative finding

>[!info]- Answer
>**C. It is highly suggestive of malignancy**
>See answer above

# [[20 Obstetric Ultrasound Basics]]
[2024] First trimester ultrasound is performed via which approach?
A. Transvaginal
B. Transrectal
C. Transperineal
D. Transabdominal

>[!info]- Answer
>**A. Transvaginal**

[2024] What is the first RELIABLE gray-scale evidence of an intrauterine pregnancy?
A. Double decidual sign
B. Intradecidual sign
C. Presence of embryo with visible cardiac activity
D. Yolk sac

>[!info]- Answer
>**B. Intradecidual sign**
>Refers to the visualization of a small gestational sac within thickened decidua seen as early as 4.5 weeks AOG. It should be eccentrically located and abutting the endometrial canal

[2024] What is the MOST ACCURATE sonographic measurement to date the pregnancy?
A. Femur Length (FL)
B. Head Circumference (HC)
C. Crown-Rump Length (CRL)
D. Mean Sac Diameter (MSD)

>[!info]- Answer
>**C. Crown-Rump Length**
>Most accurate method for pregnancy dating and can be used once fetus is 6-13 weeks AOG. Once embryonic pole is seen, it can be done. It is the largest dimension of the embryo excluding the yolk sac in the extremities

[2024] What mode is used to evaluate the fetal heart rate (FHR)?
A. Color Doppler mode
B. M-mode
C. Power Doppler mode
D. B-mode

>[!info]- Answer
>**B. M-mode**
>Doppler analysis is not done to reduce amount of energy transmitted to the developing embryo


# [[13 Introduction to CT Scan]]
[2024] One of the advantages of CT scan over MRI is?
A. It has no known side effect
B. Fewer adverse drug reactions to contrast agent
C. Provides higher detail in the soft tissues
D. Good for imaging bone structures

>[!info]- Answer
>**D. Good for imaging bone structures**
>A, B, and C are incorrect

[2024] Which among the following is a common indication for CT scan imaging?
A. Seizures
B. Blunt abdominal injury
C. Gallbladder stones
D. Hyperacute ischemic infarction of the brain

>[!info]- Answer
>**B. Blunt Abdominal Injury**

[2024] CT scan is the imaging modality of choice for urinary colic because?
A. It is readily available
B. It is cheaper than MRI
C. Most of the urinary stones are calcified and can be readily seen in CT
D. It is faster than MRI

>[!info]- Answer
>**C. Most of the urinary stones are calcified and can be readily seen in CT** 
>CT stonogram has high specificity for detection of renal stones as most are hyperdense from calcium content

[2024] In CT scan, this appears as a hyperdense biconvex extra-axial lesion in the cranium:
A. Chronic subdural hematoma
B. Acute epidural hematoma
C. Hypertensive bleed
D. Acute ischemic infarction

>[!info]- Answer
>**B. Acute epidural hematoma**
>Epidural hematoma is biconvex while subdural hematoma is crescent-shaped

[2024] The following are indications for CT scan of the paranasal sinuses EXCEPT:
A. Oropharyngeal malignancy
B. Pre-Functional Endoscopic Sinus Surgery (FESS) assessment
C. Ostiomeatal unit evaluation
D. Sinusitis

>[!info]- Answer
>**D. Sinusitis**

# [[09 Introduction to MRI]]

# [[06 Role of MRI in Musculoskeletal Disease]]
[2024] The following are roles of MRI in evaluation of primary bone neoplasm, except?
A. Detecting skip lesions
B. Defining soft tissue involvement
C. Determining the osseous matrix of the mass
D. Identifying involvement of joint spaces

>[!info]- Answer
>**C. Determining the osseous matrix of the mass**
>For bone and soft tissue tumors, the following are the uses of MRI:
>- Define extent of osseous involvement including **skip lesions**
>- Define **soft tissue** involvement
>- Identify **intra-articular extension**
>- Identify neurovascular bundle encasement or infiltration
>- Local and regional staging by identifying enlarged regional lymph nodes

[2024] Kobe Bryant twisted his knee during a basketball game, as his primary doctor you requested a knee MRI to best detect the following possible findings, except?
A. Cartilage involvement
B. Anterior cruciate ligament tear
C. Patellar fracture
D. Meniscal tear

>[!info]- Answer
>**C. Patellar Fracture**
>Fractures are best seen using a CT scan as it has superior visualization of cortical bone. A, B, and D are all soft tissues and thus, MRI is the better modality for these 

Which of the following spine diseases is not best diagnosed with MRI?
A. Metastasis from medulloblastoma
B. Ossification of Posterior Longitudinal Ligament
C. Disc herniation
D. Tuberculous spondylodiscitis

>[!info]- Answer
>**B. Ossification of posterior longitudinal ligament**
>The following are the identified uses of spinal MRI discussed:
>- Evaluate degenerative disc disease including **disc herniation**
>- Evaluate vertebral **metastasis**
>- Evaluate primary spinal tumors
>- Evaluate infections like **tuberculous spondylodiscitis** and pyogenic spondylodiscitis
>- Evaluate spinal trauma
# [[22 Vascular Interventional Radiology]]
[2024] A series of wire and catheter exchange maneuvers, this technique is very important in ensuring safe access to blood vessels, bile ducts, hollow organs, abscess cavities, etc., enabling us to insert catheters with the least trauma, and making our procedures as non-invasive as possible.
A. Seldinger technique
B. Bentall’s procedure
C. Heineke-Mikulicz
D. Kausch technique

>[!info]- Answer
>**A. Seldinger technique**

[2024] Interventional Radiology has a major role in the following, except:
A. IR has major role in all the choices stated
B. Non-vascular procedures, such as cholecystostomy, biliary drainage, nephrostomy, etc.
C. Palliative care of Oncology patients.
D. Vascular procedures, such as angiography, embolization, angioplasty, etc

>[!info]- Answer
>**A. IR has a major role in all the choices stated**

[2024] Which of the following choices makes this statement incorrect: Conventional angiogram is helpful in evaluating vascular abnormalities and hypervascular masses, as compared with CT angiography and MR angiography, in that:
A. It allows us to study the hemodynamics of the lesion and surrounding areas.
B. It provides us an access for endovascular management
C. It provides us with superior anatomic details of extraluminal structures.
D. All of the choices stated are correct

>[!info]- Answer
>**C. It provides us with superior anatomic details of extraluminal structures**
>This statement is more applicable for CT and MR angiography

[2024] The following vessels are usually used as access points in Interventional Radiology procedures, except:
A. Radial artery
B. All of the vessels stated are used as access
C. Femoral vein
D. Femoral artery

>[!info]- Answer
>**B. All of the vessels stated are used as access points**
>Other access points include the internal jugular veins, subclavian veins, basilic veins, and brachial veins

[2024] Pre-operative embolization of hypervascular tumors gives the surgeon these advantages, except:
A. It creates an artificial surgical plane, making resection of the mass less difficult and less complicated.
B. Devascularization of the tumor decreases the risk of life-threatening intra- and post-operative hemorrhage.
C. All of the stated choices are advantage of pre-operative embolization
D. It gives the surgeon a convenient and stable access for intra-operative blood transfusion.

>[!info]- Answer
>
# [[21 Non-Vascular Interventional Radiology]]

# [[05 Overview of Radiation Oncology]]
[2024] What is the most radioresistant phase of the cell cycle at interphase?
A. M
B. S
C. G1
D. G2

>[!info]- Answer
>**B. S** 
>Cells in the late S phase are the most radioresistant cells. Cells in the M and G2 phase are the most radiosensitive

# [[14 Introduction to Radiation Oncology]]
[2024] The most common application of brachytherapy in the Philippines is
A. Transluminal
B. Mold
C. Intracavitary
D. Interstitial

>[!info]- Answer

[2024] Is not a common emergency indication for radiotherapy in the Philippines
A. Brain metastasis
B. SVC syndrome
C. Bleeding
D. Bone metastasis

>[!info]- Answer
>**A. Brain metastasis**
>The following are the emergency indications for radiotherapy:
>- Spinal cord compression
>- Vascular compression including **SVC syndrome**
>- Bronchial obstruction
>- **Bleeding** from GI and GU tumors
>- Esophageal obstruction
>- Pain from **bone cancer**

[2024] Which of these statements regarding stereotactic radiosurgery is false?
A. It relies on a 3D coordinate system for target localization
B. Radiation therapy using this technique is usually delivered daily over several weeks
C. The SRS dose is biologically equivalent to five to six weeks of daily conventional radiation therapy
D. It can be delivered using gamma rays or photons

>[!info]- Answer
>**B. Radiation therapy using this technique is usually delivered daily over several weeks**
>SRS usually involves a single treatment


# [[02 Machines and Modalities in Radiation Oncology]]

# [[23 Nuclear Medicine]]
The clinical properties of Iodine-131 are due to what?
A. Gamma-radiation emitted by the isotope
B. Half-life of the isotope
C. Beta-particles emitted by the isotope
D. Size of the isotope

>[!info]- Answer
>**C. Beta-particles emitted by the isotope**?

[2024] I-131 is taken up by thyroid tissue in the body because iodine is a constituent of thyroid?
A. Enzyme
B. Hormone
C. Secretion
D. Tissue

>[!info]- Answer
>**B. Hormone**

# Genitourinary Radiology
[2024] The sites where a stone will most commonly lodge are the following, EXCEPT:
A. Ureteropelvic junction
B. At the level of the L3 transverse process
C. As it crosses the pelvic brim
D. Ureterovesical junction

>[!info]- Answer
>**B. At the level of the L3 transverse process**
>The natural narrowings of the ureter are where most stones are found. These constriction sites are the ureteropelvic junction, the pelvic brim, and the ureterovesical junction.

[2024] What is the most common congenital renal anomaly?
A. Crossed fused ectopic kidneys
B. Horseshoe kidney
C. Duplex kidney
D. Polycystic kidney disease

>[!info]- Answer
>**D. Polycystic kidney disease**

[2024] What imaging modality is requested if suspecting a small ovarian pathology?
A. Transvaginal/transrectal ultrasound
B. MRI
C. Whole abdominal ultrasound
D. CT

>[!info]- Answer
>**A. Transvaginal/transrectal ultrasound**
>Ultrasound is the first line imaging for ovaries

[2024] What is the screening modality for imaging the genitourinary organs?
A. X-ray
B. MRI
C. Ultrasound
D. CT

>[!info]- Answer
>**C. Ultrasound**

# Best Imaging Modality Quiz
[2024] Elderly Female with sudden onset dyspnea
>[!info]- Answer
>X-ray

[2024] Middle-aged female with palpable left thyroid mass
>[!info]- Answer
>Ultrasound

[2024] Prince Harry was eating his usual meal of fish n’chips when he felt (gasp!) a fish bone embed in the back of his throat. He stuck out his tongue in front of a mirror, trying to look for the bone. He could not see anything.
>[!info]- Answer
>X-ray

[2024] Lola Inday keeps complaining of pain shooting down her left leg. She can still walk slowly. Standing from a sitting position is painful too.
>[!info]- Answer
>MRI

[2024] A 56-year old female, diagnosed with Invasive Ductal CA, Right, experienced sudden lower extremity numbness and weakness. She was immediately brought to the emergency room.
>[!info]- Answer
>MRI


[2024] A 6-month old infant, born full term with a cleft lip and palate, short limbs, and bowel disturbances. This is a first consult with the physician.
>[!info]- Answer
>CT scan (?)

[2024] After a game of tennis this morning, you feel pain in your forearm. There is no lifting power in that arm. You suspect a torn muscle.
>[!info]- Answer
>MRI

[2024] Four week history of FUO. Chest Xray, abdominal CT scan, urinalysis, hepatitis and dengue panels are negative. Patient is pale. You are starting to think of a bone marrow problem. What is the next best imaging modality?
>[!info]- Answer
>MRI (modality of choice for bone marrow)


[2024] Male in his 20s or 30s, brought to the ER from Taft Avenue, apparently a victim of a hit and run by a bus, gross deformity of arms and legs, incoherent speech.
>[!info]- Answer
>CT scan 

[2024] LU5 student developed a cough during his Radiology rotation. Two weeks later, the cough is still there. Non-productive. Denies having any other symptoms.
>[!info]- Answer
>X-ray

