---
type: Exam
date: 2022-10-07
tags: THER202, flashcards
points: 
---
# Ayuda Questions
[2024] What is the most important domain in criterion in appraising the quality of CPGs according to the AGREE instrument?::Rigour of development

[2024] You are reading a CPG on pneumonia from the US American College of Chest Physicians in order to enlighten your decision to prescribe an antibiotic for an in-patient. Which of these characteristics of the guidelines is the reason you will not likely prescribe the same antibiotics as given in the guidelines?
A. Applicability
B. Stakeholder involvement
C. Conflicts of interest of the guideline developers
D. Editorial independence
?
A. Applicability

[2024] Which these statements is true regarding the strength of recommendation and levels of evidence in CPGs?
A. There is common terminology for expressing these strengths of recommendation and levels of evidence across practice guidelines
B. In making a decision about whether to prescribe a certain drug, the only consideration should be the strength of the evidence from literature
C. A treatment recommendation based on observational studies has a high quality of evidence
D. After reading a guideline that says that its recommendation is strongly  against a drug, then the physician should not prescribe it
?
D. After reading a guideline that says that its recommendation is strongly  against a drug, then the physician should not prescribe it

---
# Personal Questions
What is the rationale for CPGs?::Improve patient care delivered by individual and groups of physicians

Components of the Guideline Development Model (6)
?
1. Clinical **researches** on particular health/medical problem
2. Journals and conferences to **disseminate** information
3. Guideline **development**
4. Guideline **dissemination**
5. Guidelines reach **practitioner**
6. Practitioner **applies** CPG in patient care

CPG Traditional Development Steps (9)
?
1. Organization
2. Formulating of research question with search and retrieval of literature
3. Appraisal of validity and applicability of literature
4. Evidence grading
5. Evidence synthesis
6. Consensus building
7. Public forum and dissemination
8. Plan the implementation
9. Monitor implementation and impact of CPG on clinical practice

Group in CPG development that develops the budget, decides timelines, and decides who is in the technical groups and expert panels:::Administrative group for CPGs

Group in CPG including experts on the topic or clinical epidemiology and methodology for proper search and appraisal of literature:::Technical group for CPGs

Who are included in the expert panels for CPG development?::Stakeholders with interest on the CPG either because they will use it or they will be impacted by it

At which step of guideline development do most CPGs fail?::Dissemination, implementation, and monitoring

The ==ADAPTE== model of CPG development refers to the ==use of existing CPGs for the development of new ones== and has been used in development of local guidelines on ==Osteoporosis, DM, and OSA==

The ==GRADE== model of CPG development refers to ==systematic putting together of studies for guideline development== and was used in the local guidelines for ==Tuberculosis==

Study characteristics that increase its GRADE rating (3)
?
- Large magnitude of effect
- Dose response
- Confounders likely minimize the effect

Study characteristics that decrease its GRADE rating (5)
?
- Study limitations
- Imprecision
- Inconsistent results
- Indirect evidence
- Publication bias likely

Components of the Anatomy of Guidelines (6)
?
- Question or Issue
- Recommendation
- Summary of Evidence
- Evidence Grade
- Strength of Recommendation
- Comparison with other guidelines

Key Points that must be found in the Summary of Evidence for CPGs (4)
?
- Characteristics of **available local and foreign studies**
- **Validity** of studies and **consistency** across them
- Actual **results** and estimates of effectiveness or relevant statistics
- **Applicability** of results to local patient profile

Determinants of Evidence Grade (4)
?
- Study design
- Study quality (Validity)
- Consistency
- Applicability (Directness)

Proper way of using CPGs by individual physicians::Inform practice but must not replace physician judgement

Components of INCLEN Criteria (3)
?
- Validity
- Applicability
- Equity

Domains of AGREE II Tool for Appraisal (6)
?
- Scope and purpose (3)
- Stakeholder involvement (4)
- Rigor of development (7)
- Clarity and presentation (4)
- Applicability (3)
- Editorial independence (2)

Ways how CPGs fail (3)
?
- Do not answer relevant practice questions
- Failure at dissemination
- Failure at use by clinicians

