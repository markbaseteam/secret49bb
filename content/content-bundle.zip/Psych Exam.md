---
type: Exam
dueDate: 04-28-2022
---
> [!important]+ Table of Contents
> - [[#Mood Disorders|Mood Disorders]] (4+4=**8**)
> - [[#Signs and Symptoms of Psychiatric Disorders|Signs and Symptoms of Psychiatric Disorders]] (4)
> - [[#Psychiatric Interview|Psychiatric Interview]] (3)
> - [[#Schizophrenia|Schizophrenia]] (4)
> - [[#Substance Use Disorders|Substance Use Disorders]](4)
> - [[#Anxiety Disorders and OCD|Anxiety Disorders and OCD]] (4+4=**8**)
> - [[#Personality Disorders|Personality Disorders]](4)
> - [[#Delirium]](3)
> - [[#Dementia]](3)
> - [[#Biological Interventions|Biological Interventions]](4)
> - [[#Psychosocial Interventions]](4)
> - [[#Psychiatric Emergencies]](3)
> - [[#Somatic Symptoms and Disorders]](3)
> - [[#Gender Dysphoria and Paraphilic Disorders]] (2)
> - [[#Post-traumatic Stress Disorder PTSD]](4)
> - [[#Pediatric Psychiatric Disorders]]]](4)

# Mood Disorders
#B21 40 y/o man taking antidepressants for 2 weeks. He is now **euphoric**, has **increased energy**, **racing thoughts**, and **reduced need for sleep**. Symptoms began upon use of new medication. Stopped taking medication as the patient no longer feels depressed, but the symptoms continued. Diagnosis? 

>[!cloze]
**Bipolar I Disorder**
> - There is presence of **mania** with ≥ 1 week of symptoms with the manic episode symptoms

---
#B21 #B22 #B23 Patient with multiple sclerosis presents with **persistent depressed mood, frequent waking from sleep, poor appetite, trouble concentrating, and lack of interest in sex**. Often thinks of **suicide**. No physical symptoms but is frequently absent from work. Symptoms present for **several months**. Diagnosis?

> [!cloze]
**Depressive Disorder from Another Medical Condition**
> - There is no hypomanic episode noted hence, it is a major depressive disorder
> - The patient also has MS which posits that it is secondary from that condition

---
#B21 #B22 #B23  Factor that confers the worst prognosis for **Bipolar II Disorder**

>[!cloze] 
>Rapid cyclic pattern

---
#B21 ![[Mood Disorders 1.png]] 
> [!cloze]
> **D. Risk of suicide attempts is higher for women but completion rate is lower**

---
#B21 40 y/o M **unusually irritable** for 2 weeks. Increased energy and activity, sleeplessness, finds difficulty standing still. **More talkative** than usual and **easily distracted** making completing work assignments difficult. PE and labs are negative for medical causes and he is taking no medications. Diagnosis?

> [!cloze]
> **Manic Episode** 
> - Hypomanic episode symptoms (talkative, distractible) lasting for ≥ 1 week 
> - Impaired functioning

#B21 Which of the following diagnostic markers for major depressive disorder is true? 
(**A**) No lab test demonstrates sufficient sensitivity and specificity for diagnosis of MDD 
(**B**) Several diagnostic lab tests exist but no commercial enterprise offers them to the public 
(**C**) Diagnostic lab tests have been withheld for fear that those who test positive commit suicide 
(**D**) Only fMRI provides absolute diagnostic reliability 

> [!cloze]
> **A) No lab test demonstrates sufficient sensitivity and specificity**
> - Depression is mainly a clinical diagnosis based on DSM-5 or ICD-11
> - There is no laboratory test for depression

---
#B21 Which of the following statements accurately describe change in DSM-5 from DSM-4 criteria for **Bipolar Disorders**?
**A.** Diagnostic criteria now include both changes in mood and changes in activity or energy
**B.** Diagnostic criteria for Bipolar I Mixed now requires patient who meets full criteria for both mania and depressive episode
**C.** Manic or hypomanic episodes cannot be associated with recent administration of drug know to cause similar symptoms
**D.** Clinical symptoms associated with hypomanic episodes have been substantially changed

> [!cloze]
> **A. Diagnostic criteria now include both changes in mood and changes in activity or energy**

---
#B21 Which of the following statements about how grief differs from major depressive episode is FALSE?
**A.** In grief, predominant affect is feeling of emptiness and loss while MDE involves a persistent depressed mood and inability to anticipate happiness or pleasure
**B.** Pain in grief may be accompanied with positive emotions uncharacteristic of pervasive unhappiness in MDE
**C.** Thought content in grief features thoughts of deceased rather than pessimism in MDE
**D.** In grief, feelings of worthlessness and self-loathing is common while in MDE, self-esteem is preserved

> [!cloze]
> **D. In grief, feelings of worthlessness and self-loathing is common while in MDE, self-esteem is preserved**
> - The opposite is true. Recall that part of the DSM criteria for MDE is the ==recurrent thoughts of death or suicide==

---
#B21 30 y/o patient feels down and **doesn't enjoy life**, unable to sleep, poor appetite, little interest in activities. Symptoms began 2 months ago and is now having **difficulty attending to work**. Several episodes of **increased energy** in the past 4 years lasting for days during which she felt productive, social, and outgoing. People noted she spoke more rapidly during these episodes but **did not find her annoying**. No medical problems and substance use. Diagnosis?

> [!cloze]
> **Bipolar II** disorder currently in a **depressed episode**
> - Patient is experiencing depressive and hypomanic symptoms
> - It is not bipolar I as the hypomania lasted for < 1 week and the symptoms during the episode do not have marked impairment but is observable by others

---
#B21 26 y/o distressed and irritable 4 days prior to onset of menses. Feels anxious, cannot concentrate, little interest and enjoyment in activities, experiences bloating and swelling of breasts. Symptoms began 6 months ago after taking OCP. No history of mood symptoms. Diagnosis?

> [!cloze]
> **Medication-induced depressive disorder**
> - It is not considered as premenstrual dysphoric disorder as indicated by onset triggered by the OCP use

---
#B22 #B23 Which of the following presentations meet criteria for **major depressive episode**?
**A.** Anhedonia, hypersomnia, lethargy, feelings of hopelessness, weight gain
**B.** Depressed mood, insomnia, and weight loss
**C.** Psychomotor agitation, insomnia, weight loss, diminished ability to concentrate, fatigue
**D.** Weight loss, insomnia, feeling of excessive guilt, indecisiveness, suicidal ideations

>[!cloze]
> **A. Anhedonia, hypersomnia, lethargy, feelings of hopelessness, weight gain**
> - There should be at least 5 symptoms (B is ruled out)
> - There should be 1 core symptom (either depressed mood or anhedonia) hence, A is the correct answer

---
#B22 #B23 Which of the following is not strongly implicated (least involved) in neurobiology of depression?
**A.** Dopamine
**B.** Norepinephrine
**C.** Serotonin
**D.** Histamine

> [!cloze]
> **D. Histamine** see [[Depression#Neurobiology]]

---
#B22 #B23 Which of the following is true about mood disorders?
**A.** Most common group of psychiatric disorders
**B.** Males and females have same chance of developing depression
**C.** Antidepressants can cause switch to mania in bipolar patients
**D.** Caused by hypoactive functioning of specific brain circuits

> [!cloze]
> **C. Antidepressants can cause switch to mania in bipolar patients**
> - Anxiety is the most common psychiatric disorder
> - Depression is twice as common in females
> - Depression results from upregulation of receptor expression which increases effects of NTs (hyperactive)
> - **Manic switch** risk is reduced when they are treated with antidepressants and ==mood stabilizers==

---
#B22 #B23 Which of the following is considered an **acute goal** in psychiatric management of manic episode?
**A.** Enhance treatment adherence
**B.** Prevent relapse
**C.** Manage functional impairment
**D.** Ensure safety of patient and other people around them

>[!cloze]
>**D. Ensure safety of patient and other people around them**
>- Goals include stabilization of episode within goal of achieving remission and rapid control of symptoms to ensure safety of patient and those around them

---
#B23 Patient complains of **drowsiness** during day and **interrupted sleep** for 4 weeks. In past 2 months, experienced body ache, poor appetite, abdominal discomfort, and **diminished interest in usual activities**. Faces impending termination from job from frequent absence and **poor work performance**. 3 months ago, GF broke up with him unceremoniously and wrestled with overwhelming gloominess and saw life as meaningless and **devoid of hope**. Oftentimes, thought of using gun to end life. 

Diagnosis?
> [!cloze]
> **Major Depressive Disorder**
> - Has 1 core symptom (anhedonia) and ≥ 5 total symptoms

Most likely contributing factor?
> [!cloze]
> **Feeling of betrayal from girlfriend**
> - Note that the onset began upon the breakup

---
#B23 Differential diagnosis for **Major Depressive Episode**
**A.** Major Depressive Disorder
**B.** Bipolar I
**C.** Bipolar II
**D.** All of the above

>[!cloze]
>**D. All of the above** as depressive episodes are present for all of the identified mood disorders

---
#B24 Patient presents with **difficulty concentrating, poor motivation, and psychomotor retardation**. Feels sad after having to take leave of absence for a year from **thyroidectomy**. Avoids conversations and socialization as she does not know them much and feels left behind. Admits to being sleepy most of the day and waking up earlier than usual. Lies in bed ruminating whether to continue or quit medical school. Usually arrives late in school and skips morning classes as she does not want to get out of bed. 

Prior to surgery, she was very active and had moments where she felt like she can do several things without getting tired. During these moments, she felt like she can go right away in the morning even if she had stayed up late the night before. Was very sociable for a lot of people and would talk non-stop

Primary Condition to Consider?
> [!cloze]
> Mood disorder secondary to primary medical condition

Of the following which is the most important to explore?
**A.** Change in appetite or weight
**B.** Past history of depressive episode prior to surgery
**C.** Presence of suicidal ideations
**D.** Reasons for decision to quit medical school

> [!cloze]
> **C. Presence of suicidal ideations** are an automatic indication for referral to a psychiatrist

What is the next step in managing the case?
**A.** Recommend hospitalization
**B.** Request repeat thyroid function tests
**C.** Start antidepressants
**D.** Start mood stabilizers

> [!cloze]
> **B. Request repeat thyroid function tests** as it is important to first rule out secondary causes that have its own treatment protocols

---
#B24 Patient is a married multimedia arts graduate who used to work for an ad company. During the pandemic, company was forced to get go employees and he was included. Since termination, wife noticed that he **distanced himself** from family and friends. Noted to be **lethargic** spending most of the day in bed watching YT but **looking sullen all the time**. Has difficulty sleeping and decreased appetite. Upon urging of wife, consulted psychiatrist who prescribed antidepressants. After a few days, there was marked improvement in mood and started to accept freelance projects while applying for more stable jobs. Became very engrossed in projects he was working on. Noted to spend a whole night working and still looked energetic in the morning. Started to interact with others and noted to be more sociable than before. Started jogging every morning and every afternoon. Wife was happy about improvement but cautioned him to be careful due to COVID surge. 

Diagnosis?
> [!cloze] 
> **Bipolar II Disorder** as there is a depressive episode and a noted "manic switch" from the antidepressants 
> - No mania as it is not noted to impair functioning and seems to not last for > 1 week

After ECQ, patient became **increasingly restless** and wanted to continue daily routine of going out to neighbors and jogging. Barangay was subjected to lockdown but he **kept on insisting to go out**. When approached by officials to go back to his house, he became **belligerent** and insisted that COVID was not real. Claimed he was immune to any disease and should be leading the IATF in coordinating COVID response. Prompting apprehension and detainment. Family requested he be brought to hospital due to past psychiatric history

Diagnosis?
> [!cloze]
> **Bipolar I Disorder** as there is now the presence of mania

Management?
**A.** Start mood stabilizer
**B.** Stop antidepressant
**C.** Start atypical antipsychotics
**D.** AOTA
> [!cloze]
> **D. AOTA**

---
#B24 The following are the likely cause for secondary mood disorders except?
**A.** Antibiotics
**B.** Anti-retrovirals
**C.** OCPs
**D.** Steroids

> [!cloze]
> **A. Antibiotics** see [[Mood Disorders#Causative Agents]]

---
# Signs and Symptoms of Psychiatric Disorders
#B22 #B23 Housewife tells doctor she has not been going out of her room as she **believes that the military is videotaping her outside**. She is sure because she **hears voices** conversing in odd languages she can only understand. She says they are interested because she hold confidential information from FBI and Russian government. Which of the following is true?
**A.** Manifests with 2 delusions
**B.** Manifests with 2 hallucinations
**C.** Manifests with 2 delusions and 1 hallucination
**D.** Manifests with 1 delusion and 2 hallucinations
**E.** Manifests with 3 delusions and 1 hallucination

> [!cloze]
> **C. Manifests with 2 delusions and 1 hallucination**
> - Presents with [[Psychosis#Delusions]] of ==believing she is videotaped== and ==feeling that they are interested in her for confidential information==
> - Auditory hallucination of hearing voices 

---
#B22 #B23 Patient confides to doctor that he does not want to interact with anyone because **all people are aliens**. Sure that every night he **hears voices** of conversing in odd languages he can only understand. 
**A.** Manifests with 2 delusions
**B.** Manifests with 2 hallucinations
**C.** Manifests with 1 delusion and 1 hallucination
**D.** Manifests with 1 delusion and 2 hallucinations
**E.** Manifests with 2 delusions and 2 hallucination

>[!cloze]
>**C. Manifests with 1 delusion and 1 hallucination**
>- Bizarre delusion thinking everyone is an alien
>- Auditory hallucinations

---
#B22 **T or F.** Sublimation is a defense mechanism attempting to attenuate expression of drives in alternative fields without adverse effects.

> [!cloze]
> T

---
#B22 Male patient was envious of close relationship between sister and mother developing distrust in most women. What is this defense mechanism called?

>[!cloze]
>**Projection** involves attributing unacknowledged feelings to others and includes severe prejudice, rejection of intimacy, hypervigilance, and injustice collecting

---
#B22 #B23 Indirect speech that is delayed in reaching point but eventually reaches the desired goal

> [!cloze] 
> **Circumstantiality** is a pattern of indirect speech causing delay in reaching goal idea

---
#B22 #B23 Patient tells you that she is the savior of the world. What is this symptom called?

>[!cloze]
>**Delusion** specifically, grandiose type

---
#B22 #B23 Psychiatric disorder with intact reality testing and high levels of anxiety

>[!cloze]
**Neurosis** see [[Mental Health#Differentiating Points of Mental Illnesses]]

---
#B22 #B23 Pervasive and sustained emotion coloring perception of the world

> [!cloze] 
> **Mood** see [[Mental Health#^kdn9gr]]

---
#B23 Patient points in fear to long white window curtain billowing in the wind saying it is a **white lady** waving at her by the window. What is this symptom called?

>[!cloze]
>**Illusion** as the patient mistook stimulus for something else
>- The presence of a stimulus means that it is not a hallucination

---
#B23 Psychosis is a?
**A.** Thought process disturbance
**B.** Thought content disturbance
**C.** Perceptual disturbance
**D.** Severe form of anxiety
**E.** Syndrome of unreality

>[!cloze]
>**E. Syndrome of unreality** (patients have difficulty differentiating what is real with what is not)

---
#B22 #B23 What is a **hypnagogic hallucination**?

>[!cloze]
>False sensory perception occurring while **falling asleep** and is generally considered **non-pathological**

---
#B23  Persistent, irrational, exaggerated, and invariably pathological dread of particular stimulus or situation

> [!cloze]
> **Phobia** are unreasonable fears of particular stimulus or situation that is unlikely to cause harm 

---
#B23 6 y/o F brought by mother to psychiatrist yesterday. Which of the following obtained in history is the most important?
**A.** Sleeping at 3 AM since 3 years ago
**B.** Angry and not talking to friends since a month ago
**C.** Talking to self before mirror since 3 years old
**D.** Belief in reincarnation
**E.** Says there is nothing wrong with her

> [!cloze]
> **A. Sleeping at 3 AM since 3 years ago**
> - 6 y/o normally sleeps early and for it to be prolonged, it should be looked into first

---
#B23 Person repeatedly washes hands to stop world from ending. This is an example of? 

> [!cloze]
> **Compulsion** is a repeated behavior or action done to ward off anxiety stemming from an obsession

---
#B24 Factors affecting mental health
**A.** Biological, psychological, and sociocultural
**B.** Social, economic, and occupational
**C.** AOTA
**D.** NOTA

> [!cloze]
> **A. Biological, psychological, and sociocultural**
> - While B may also be true, the discussion particularly highlights the contents of A 

---
#B24 Looseness of association, thought blocking, and delusions are called?

> [!cloze]
> **Thought disturbances**

---
#B24 Circumstantiality, tangentiality, and echolalia are called?

> [!cloze] 
> **Language disturbances**

---
#B24 Hallucinations, illusions, and derealization are called?

> [!cloze]
> **Perceptual disturbances**

---
# Psychiatric Interview
#B21 Currently used DSM Edition

>[!cloze]
>**DSM-5**

---
#B21 #B23 Primary objective of physician when interviewing patient in **ER**

> [!cloze]
> **Diagnosis**

---
#B21 #B23 Patient brought to ER due to **suicidal attempt**, desire to stay quiet and just listen, and refuses to talk about job history. Diagnosis?
**A.** Discomfort about topic
**B.** Mutism of psychosis
**C.** Autism of psychosis
**D.** Possible preoccupation of perceptual disturbance
**E.** Issues about career choice

> [!cloze]
> **D. Possible preoccupation of perceptual disturbance** as E is too assuming and there are no signs of psychosis (B and C rule out)

---
#B21 #B23 Best way to end interview?

> [!cloze]
> **Ask patient if they have any questions** 

---
#B22 Appropriate behavior of therapist to patient with **paranoid personality disorder**?
**A.** Demand for warmth and intimacy to dispel paranoia
**B.** Avoid ambiguous comments
**C.** Give antipsychotics immediately without explanation
**D.** Agree to paranoia initially

> [!cloze]
> **B. Avoid ambiguous comments** 
> - Important in gaining patient's trust and prevent further distress
> - Too much warmth can make them suspicious
> - Giving drugs without explanation feeds paranoia
> - Agreeing to paranoid thoughts causes more distress

---
#B22 Which of the following questions will you ask before sending patient home if patient is suffering from **depression**?
**A.** Would fastfood help your day-to-day survival?
**B.** Do you think sleeping pills would help?
**C.** Do you need a leave of absence recommendation for your employer
**D.** Do you have suicidal thoughts

> [!cloze]
> **D. Do you have suicidal thoughts**
> - Presence of suicidal thoughts warrants for more in-depth monitoring and intervention especially in depressed patients

---
#B24 Confidentiality may be broken when?
**A.** There are psychiatric symptoms
**B.** There is possible harm to self and others
**C.** There is no circumstance where it may be broken
**D.** There is degenerating ability to care for self

> [!cloze]
> **B. There is possible harm to self and others**

---
#B24 True of psychiatric interview
**A.** Focuses more on external events leading towards symptoms
**B.** Not the gold standard for psychiatric diagnosis
**C.** Both diagnostic and therapeutic and sets the tone for psychotherapy
**D.** Same as mental status examination

> [!cloze]
> **C. Both diagnostic and therapeutic and sets the tone for psychotherapy**

---
#B24 Ideal interview setting includes?
**A.** Strict time limit
**B.** Only patient and doctor are present in the interview
**C.** Public location is acceptable so long as patient and physician wear headphones
**D.** Freedom from distractions

> [!cloze] 
> **D. Freedom from distractions** see [[Psychiatric Evaluation#^231mce]]

---
# Schizophrenia
#B21 #B23 #B24 False fixed belief based on incorrect inference about external reality firmly held despite conflicting proof
**A.** Hallucination
**B.** Illusion
**C.** Delusion
**D.** Disorganized behavior

> [!cloze]
> **C. Delusion** see [[Psychosis#Delusions]]

---
#B21 #B22 #B23 #B24 Impairment that grossly interferes with capacity to meet ordinary demands of life and impaired reality testing

> [!cloze]
> [[Psychosis]]

---
#B21 #B22 #B23 **T or F.** Hallucinations are experienced in any of the five senses
>[!cloze] 
>**T**

---
#B21 #B22 #B23 Psychotic symptoms caused by other medical conditions are called?
>[!cloze]
>Secondary psychotic conditions

---
#B21 #B22 #B23 Condition involving sudden onset psychotic state lasting one day but less than 1 month
>[!cloze]
>**Brief Psychotic Disorder**
>- Schizophreniform (1-6 months), Schizophrenia (> 6 months)
>- Schizoaffective disorder is > 2 weeks of delusions and hallucinations without mood symptoms

---
#B21 #B22 #B23 #B24 Decreased dopamine in this tract is associated with the negative symptoms of schizophrenia
>[!cloze]
>**Mesocortical tract** see [[Psychosis#Dopaminergic Pathways]]

---
#B22 Which of the following is  **Criteria A** for schizophrenia?
**A.** Flight of ideas
**B.** Thought blocking
**C.** Mutism
**D.** Tangentiality

>[!cloze]
>**C. Mutism**

---
#B22 Which of the following is a risk factor for suicide in schizophrenia?
**A.** Female
**B.** Elderly
**C.** Educated
**D.** Perceptual disturbance

>[!cloze]
>**D. Perceptual disturbance**
>- Also includes prior attempts, depressive symptoms, active hallucinations and delusions, and presence of insight

---
#B22 Good prognostic factor in people with schizophrenia?
**A.** Auditory hallucination
**B.** Social withdrawal
**C.** Subtle onset
**D.** Associated movement disorder
**E.** No remission after 3 years 

>[!cloze]
>**A. Auditory Hallucinations** 
>- Others include diagnosable mania or depression, visual hallucination, perceptual disorder, confusion, and haptic hallucination

---
#B22 40 y/o M consulted for sustained injury from construction work. Fairly good worker with family and friends. Reports that one of his former classmates is currently spying on him and plans to take away his wife. Diagnosis?
>[!cloze]
>**Delusional Disorder** 
>- Looks normal but has non-bizarre delusions lasting for ≥ 1 month

---
#B22 35 y/o F spent 10 years in mental facility. Spends most days rocking, muttering softly to self, or just staring blankly ahead. Needs help dressing and showering often giggling for no apparent reason. Diagnosis?
>[!cloze]
>**Schizophrenia**
>- ≥ 6 months of delusions, hallucinations, disorganized speech, or catatonia

---
#B22 In study published in 2005, which of the ff. is true about gray matter of patients with schizophrenia?
**A.** No change in volume with atypical antipsychotic drugs
**B.** Increased volume w/ atypical antipsychotics
**C.** Decreased volume w/ atypical antipsychotics
**D.** Reverses loss w/ typical antipsychotics

>[!cloze]
>**B. Increased volume w/ atypical antipsychotics**

---
#B22 Among the ff. which has highest prevalence of schizophrenia?
**A.** Dizygotic twins of schizo patient
**B.** Children of 2 schizo parents
**C.** Non-twin siblings of schizo patients
**D.** Spouse of schizo patient

>[!cloze]
> **B. Children of 2 schizo parents**
> - ![[Schizo 1.png]]

---
#B22 Heralded introduction of concept that schizophrenia is a brain disorder
>[!cloze] 
>Introduction of fMRI

---
#B23 Vivid dreamlike state before waking up or sleeping
>[!cloze]
>Hypnagogic Hallucination

---
#B24 Four A's of Schizophrenia
>[!cloze] 
>Associations, Affect, Autism, and Ambivalence

---
# Substance Use Disorders
#B21 #B22 #B23 #B24 Phenomenon of **sensitization** is defined as?
> [!cloze]
> **Persistent hypersecretion** to effect of drug in person with previous exposure
> - Increased effect even with constant drug dose

---
#B21 #B23 #B24  Dopamine surge in what region of the brain is implicated in reward related to stimulant use
**A.** Sensory cortex
**B.** Substantia  nigra
**C.** Ventromedial thalamic nucleus
**D.** Nucleus Accumbens
>[!cloze]
>**Nucleus Accumbens**
>- The reward circuitry is controlled by the NAcc and the **ventral tegmental area**

---
#B21 #B22 #B23 Intense desire to re-experience effects of psychoactive substance
>[!cloze]
>**Craving**

---
#B21 Nicotine releases the following NT except?
**A.** Dopamine
**B.** Norepinephrine
**C.** Acetylcholine
**D.** Histamine
**E.** Vasopressin

>[!cloze]
>**D. Histamine**

---
#B21 For DSM-5, the following are groupings of symptoms in substance use disorder except?
**A.** Impaired control
**B.** Social Impairment
**C.** Risky use
**D.** Pharmacologic criteria e.g., tolerance and withdrawal
**E.** None of the above

>[!cloze]
>**E. None of the above**

---
#B21 In DSM-5, the ff. substances cause withdrawal except
**A.** Stimulants
**B.** Cannabis
**C.** Hallucinogens
**D.** Tobacco
**E.** Alcohol

>[!cloze]
>**C. Hallucinogens**

---
#B21 #B23 #B24 Signs and symptoms of drug-induced mental disorder disappear after how much time of abstinence?
>[!cloze]
>1 month

---
#B21 Returning to environment associated with previous substance use after abstinence \____ withdrawal symptoms and \____ drug taking behavior especially when under stress.
>[!cloze]
>Induce; Initiate

---
#B21 In amphetamine use, there is \____ in dopamine in the **mesolimbic** tract and \____ in D2 receptors resulting in dysphoria, anhedonia, irritability, cravings, and drug-seeking
>[!cloze] 
>Decreased; Decreased
>- Amphetamines reduce dopaminergic functioning in mesolimbic system and downregulate D2 receptors

---
#B21 #B23 #B24  34 M slurred speech, unsteady gait, and impaired concentration and coordination. No pupillary dilation and normal conjunctiva. Ingestion of what substance explains the presentation?
>[!cloze]
>**Alcohol** has no effect on pupils and conjunctiva unlike stimulants like amphetamine, cocaine, and cannabis

---
#B21 Recognition of substance use disorder is done through the following except?
**A.** Complete PE and history
**B.** Questionnaire
**C.** Biologic marker
**D.** Toxidrome
**E.** NOTA

>[!cloze]
>**E. NOTA**

---
#B21 Receptors of this NT is responsible for extrapyramidal symptoms
>[!cloze]
>[[Dopamine]]

---
#B22 #B23 Anorexia-associated nicotine use is mediated by what neurotransmitter?
>[!cloze]
>Serotonin
>- Serotonin plays a role in appetite suppression and mood modulation which can explain association with anorexia

---
#B22 #B23 Individual non-pharmacologic treatment most effective for substance use disorder
>[!cloze]
>Motivational interviewing (see [[Substance Abuse#Motivational Interviewing]])

---
#B22 #B23 NT mediating the cognitive enhancement in nicotine use
>[!cloze]
>**Acetylcholine** (mediates arousal and cognitive enhancement)
>- Dopamine mediates pleasure and appetite suppression
>- NE mediates arousal and appetite suppression
>- Vasopressin is involved in memory improvement
>- Serotonin is involved in mood modulation and appetite suppression
>- Beta-endorphins reduce anxiety and tension

---
#B23 Denial
**A.** is not normal
**B.** is adaptive
**C.** is unhealthy
**D.** facilitates early treatment

>[!cloze] 
>**B or C** with C as the feedback answer

---
# Anxiety Disorders and OCD
#B22 #B23 45 y/o homemaker is described as a **worrier** started to become irritating to children because she **always demands checking on husband when he is not home by 8PM**. Imagines husband figured in an accident or had been victimized. Diagnosis?
>[!cloze] 
>[[Generalized Anxiety Disorder]]
>- Excess anxiety and worry about a number of events

#B22 #B23  If patient also has a breast malignancy, how would she behave with physician?
**A.** Deny illness
**B.** Ask lots of opinions
**C.** Manifest with social withdrawal
**D.** Psychosis
>[!cloze]
>**B. Ask lots of opinions** given she has GAD, she would feel restless

#B22 #B23 Which of the ff. medications do you recommend for the patient?
**A.** Olanzapine
**B.** Alprazolam
**C.** Risperidone
**D.** Valproic Acid
>[!cloze]
>**B. Alprazolam** is an anxiolytic and a short-acting [[Benzodiazepine]]
>- First line treatment for patients with [[Anxiety Disorder]] should be [[Antidepressants]]

#B22 #B23 Aside from pharmacologic intervention, which of the ff. can be recommended for patient?
**A.** Family therapy
**B.** Psychosocial processing
**C.** Electroconvulsive therapy
**D.** Deep brain stimulation
>[!cloze]
>**A. Family therapy** is recommended as the main cause for anxiety is the husband coming home late and bothering the children

---
#B22 Which of the ff. is true about anxiety?
**A.** Diffuse, unpleasant, vague sense of apprehension often accompanied by autonomic symptoms
**B.** Response to known, external, definite, or non-conflictual threat
**C.** Has somatic, pyschological, behavioral, and traumatic components
**D.** Becomes pathological if it becomes chronic but does not impair functioning 
**E.** NOTA

>[!cloze]
>**A. Diffuse, unpleasant, vague sense of apprehension often accompanied by autonomic symptoms** (see [[Anxiety]])

---
#B22 37 y/o F married with 2 children. Symptoms began 7 months ago when she suddenly began having **episodes of extreme anxiety** initially starting with palpitation progressing to dyspnea, numbness, feelings of choking, and chest heaviness. No identifiable triggers. Symptoms prompt ER visit and all lab tests show normal result. Happened for ≥ 3 times for past months. 

Diagnosis?
>[!cloze]
>[[Panic Disorder]]

#B24 NT implicated in symptomatology?
> [!cloze]
> [[Serotonin]], [[Norepinephrine]], and [[GABA]] (see [[Anxiety Disorder#Neurotransmitters]])

Pharmacologic interventions for the patient?
>[!cloze]
>[[Antidepressants]] and [[Benzodiazepine]] (see [[Anxiety Disorder#Pharmacologic]])

---
#B24 The following are components of anxiety disorders except?
**A.** Behavioral response
**B.** Somatic symptoms
**C.** Psychological component
**D.** Psychodynamic component

>[!cloze]
>**D. Psychodynamic component**

---
#B24 The ff. are **criteria C** for Generalized Anxiety Disorder except?
**A.** Easy fatigability
**B.** Difficulty concentrating and mind going blank
**C.** Sleep disturbance
**D.** Suicidal ideation

>[!cloze]
>**D. Suicidal Ideations** (see [[Generalized Anxiety Disorder#Diagnostic Criteria]])

---
#B24 Part of brain that integrates sensory and cognitive information and determines whether there will be a fear response
>[!cloze]
>[[Amygdala]]

---
#B24 The ff. are OC and related disorders in DSM-5 except?
**A.** Body dysmorphic disorder
**B.** Acute stress disorder
**C.** Hoarding disorder
**D.** Trichotillomania

>[!cloze]
>**B. Acute Stress Disroder** (see [[Obsessive Compulsive Disorder#Related Disorders]])

---
#B24  Which of the ff. are true?
**A.** Obsessions are persistent thoughts, urges, or images
**B.** Obsessions cause marked anxiety which can be neutralized by compulsion
**C.** Obsessions are experienced as intrusive and unwanted
**D.** AOTA
>[!cloze]
>**D. AOTA** see [[Obsessive Compulsive Disorder#Diagnostic Criteria]]

---
#B24 Brain structure involved in developing obsessions and compulsions, control of impulses, executive functions, attention, and concentration
>[!cloze]
>Prefrontal cortex (see [[Anxiety Disorder#Behavioral Neuroanatomy]])

---
#B24 Brain structure involved in feeling of pleasure, euphoria, reward, and motivation
>[!cloze]
>Nucleus Accumbens (see [[Anxiety Disorder#Behavioral Neuroanatomy]])


---
# Personality Disorders
#B21 #B23 24 y/o M living alone and working at night as security guard ignores social invites of coworkers and has no outside interests. Diagnosis?
>[!cloze]
>[[Schizoid Personality Disorder]]

---
#B21  #B23 32 y/o M preoccupied to study and brewing tea. Attributes powers with consumption and claims plants whisper to him. No history of disordered behavior and medications. Most likely personality disorder?
>[!cloze]
>[[Schizotypal Personality Disorder]] (key here is the magical thinking)

---
#B21 Patient was angry because graduate studies thesis committee did not approve of his project. Responded with "You're just jealous because you know I will be the best epidemiologist in history". Personality disorder?
>[!cloze]
>[[Narcissistic Personality Disorder]]
>- Grandiose sense of importance

---
#B21 #B23 Patient's life has always been chaotic. History of fighting and breaking up with friends. Attempted suicide to get boyfriend to reconsider relationship. Last year, she contracted gonorrhea and delayed help. Personality disorder?
>[!cloze]
>[[Borderline Personality Disorder]]
>- Fear of abandonment 
>- Unstable and intense interpersonal relationship
>- Recurrent suicidal behavior and threats of self-mutilation

---
#B21 Characteristic seen in Paranoid PD?
**A.** Develop schizophrenia
**B.** Often preoccupied with helping weak and powerless
**C.** Usually present as quiet and humble
**D.** Often litigious
>[!cloze]
>**D.** Often litigious (see [[Paranoid Personality Disorder#Associated Features]])

---
#B21 What differentiates Schizoid PD from Avoidant PD?
>[!cloze]
>There is **no desire for intimacy** in [[Schizoid Personality Disorder]]

---
#B21 #B23 Schizotypal PD characteristic
**A.** Hypervigilance
**B.** Magical thinking
**C.** Feelings of entitlement
**D.** Marked shifts in mood
>[!cloze]
>**B.** Magical thinking (see [[Schizotypal Personality Disorder#DSM-5]])
>- A is [[Paranoid Personality Disorder]]
>- C is [[Narcissistic Personality Disorder]]

---
#B21 Appropriate behavior for therapist in those with Paranoid PD
**A.** Demand warmth and intimacy to dispel paranoia
**B.** Avoid ambiguous comments
**C.** Give antipsychotics immediately without explanation
**D.** Agree to paranoia initially
>[!cloze]
>**B.** Avoid ambiguous comments

---
#B21 Personality disorder where goal of treatment is to lessen rigidity and increase enjoyment in life
>[!cloze]
>[[Obsessive Compulsive Personality Disorder]]


---
#B21 Cluster B personality disorders are associated with what disorder pointing to a genetic connection?
>[!cloze]
>[[Mood Disorders]]
>- Psychotic disorders are associated with Cluster A
>- [[Anxiety Disorder]] is associated with Cluster C

---
#B21 Defense mechanism seen in Borderline PD
>[!cloze]
>[[Splitting]]

---
#B24 30 y/o F separated from husband with repeated history of ER visits from **cutting herself**. Recurrent job loss, interrupted education, history of physical and sexual abuse and early parental loss. Chronic feelings of emptiness. Most common co-occurring disorder?
>[!cloze]
>[[Mood Disorders]]
>- Cluster B personality disorder specifically [[Borderline Personality Disorder]] is associated with mood disorders

---
#B24 Individuals that have **difficulty expressing anger** even with direct provocation giving impression that they **lack emotion**. Lives are **directionless** and appear to drift in goals. React passively, lack social skills, and lack desire for sex. Few friends and often do not marry. Diagnosis?
>[!cloze]
>[[Schizoid Personality Disorder]]
>

---
#B24 Individuals that become **increasingly shy** and do not socialize during adolescence and early adulthood when social relationships with new people are important. Have **pervasive feelings of inadequacy and hypersensitivity to negative evaluation**. Unwilling to get involved unless certain of being liked. Diagnosis?
>[!cloze]
>[[Avoidant Personality Disorder]]

---
#B24 PD sharing traits of **suspiciousness**, interpersonal aloofness, paranoid ideation similar to paranoid PD but with **magical thinking**, unusual perceptual experiences, and odd thinking and speech. Diagnosis?
>[!cloze]
>[[Schizotypal Personality Disorder]]

---
#B24 PD where there is pattern of **undermining themselves** at time when goal is about to be realized like regressing severely after discussing how well therapy is going. Develop **psychotic-like** symptoms with pattern of **instability of interpersonal relationships, self-image, and marked impulsivity**. Diagnosis?
>[!cloze]
>[[Borderline Personality Disorder]]

---
#B24 Medical student having **difficulty deciding which tasks should be prioritized** that she never gets to start on anything. Expresses affection in **highly controlled** manner and uncomfortable in presence of others who are emotionally expressive. Carefully holds back until she is sure what she says is perfect. Diagnosis?
>[!cloze]
>[[Obsessive Compulsive Personality Disorder]]

---
#B24 PD often diagnosed with **dependent PD** because individuals become **very attached to and dependent on few friends they have**. Commonly suffer from depressive, bipolar, and anxiety disorders especially social anxiety disorder. Diagnosis?
>[!cloze]
>[[Avoidant Personality Disorder]]

---
#B24 Individuals with **histrionic PD** are manipulative to gain nurturance whereas this PD are **manipulative to gain profit, power, or some other gratification.** Deceit and manipulation are central features. Diagnosis?
>[!cloze]
>[[Antisocial Personality Disorder]]

---
# [[Delirium]]
#B21 Most consistent behavioral change in delirium
>[!cloze] 
>Inattention
>- [[Delirium]] is characterized by impairment in consciousness and **attention**

---
#B21 Factor that contributes to the underrecognition of delirium
**A.** Fluctuating, waxing, and waning course
**B.** Acute in onset
**C.** Relatively uncommon
**D.** Agitation is usually believed to be psychosis
>[!cloze]
>**A.** Fluctuating, waxing, and waning course

---
#B21 #B23 Neurotransmitter change believed to be responsible for delirium
>[!cloze]
>**Hyper**dopaminergia and **Hypo**cholinergia (see [[Delirium#Mechanisms]])

---
#B21 First line pharmacologic treatment for delirium
>[!cloze]
>[[Antipsychotics]]
>- [[Benzodiazepine]] is only used when no other drug can be used as it can exacerbate the present cholinergic deficit

---
#B21 Guiding principle in non-pharmacologic intervention of delirium
**A.** Address psychosocial conflicts of patient
**B.** Increase sensory stimulation of patient to prevent them from feeling isolated
**C.** Keep patient oriented using familiar things to them
**D.** Provide support to prevent onset of depression
>[!cloze]
>Keep patient oriented using familiar things to them (see [[Delirium#Supportive and Environmental Strategies]])

---
#B23 #B24 40 y/o M diagnosed 5 months ago with CHF. 4 months ago, he became **less active at work and isolates himself on family affairs**. Has **trouble sleeping and eating**. In interview, he had **intermittent** episodes of disorientation, impaired attention, irritability, visual and auditory **hallucinations**, and blank stares. Because of condition, he had marital discord that aggravated existing drinking problem

All can explain the condition EXCEPT?
**A.** Major Neurocognitive Disorder
**B.** Psychotic Depression
**C.** Delirium
**D.** Alcohol-induced Depressive Disorder
>[!cloze]
>**A. Major Neurocognitive Disorder**
>- [[Neurocognitive Disorders]] mainly involve ADLs and cognitive decline that does not occur in course of delirium

Which of the following is the least likely initial intervention?
**A.** Address underlying medical condition e.g., uncontrolled hyperglycemia
**B.** Begin haloperidol 1 mg on bedtime
**C.** Establish relaxation activities for patient
**D.** Educate family about possible causes of behavioral change
>[!cloze]
>**B.** Begin haloperidol 1 mg on bedtime
>- There is no need to give antipsychotics if addressing the underlying cause or establishing relaxation is not yet done (see [[Delirium#Management]])

Which criteria in the **Confusion Assessment Method Scale** did the patient fulfill?
**A.** Acute onset, fluctuating, inattention, auditory hallucination
**B.** Inattention and altered consciousness
**C.** Inattention, altered consciousness, acute onset, and fluctuating
>[!cloze]
>**C.** Inattention, altered consciousness, acute onset, and fluctuating
>- See [[Delirium#Confusion Assessment Method]]

---
#B23 #B24  How to pro-inflammatory cytokines contribute to cholinergic deficiency in delirium?
>[!cloze]
>Increase the permeability of the blood brain barrier
>- In addition with selective reduction in Choline Acetyltransferase activity in neurons (see [[Delirium#Cholinergic Deficit]])

---
# [[Dementia]]
#B21 #B22 #B23 #B24 Frontotemporal Dementia?
**A.** May manifest with early behavioral and personality changes
**B.** May manifest with speech difficulties and aphasia
**C.** May manifest with prominent disinhibition and inappropriate behavior
**D.** AOTA
>[!cloze]
>D. AOTA (see [[Frontotemporal Dementia]])

---
#B21 #B22 #B23 Triad of Normal Pressure Hydrocephalus
>[!cloze]
>- Gait problems
>- Progressive dementia
>- Incontinence

---
#B21 #B22 #B23 #B24 Core features of Lewy Body Dementia
>[!cloze]
>![[Lewy Body Dementia#Core Features]]

---
#B21 #B22 #B23 Features of Sporadic Creutzfeldt-Jakob Disease
**A.** Startle myoclonus, mutism, EEG findings of periodic sharp waves
**B.** Younger onset, behavioral disturbance, epilepsy
**C.** Pulvinar sign on MRI and Mutism
**D.** Pulvinar sign on MRI and EEG findings of generalized slowing
>[!cloze]
>**A. Startle myoclonus, mutism, EEG findings of periodic sharp waves**
>- See [[Prion Disease#Sporadic Creutzfeldt-Jakob]]

---
#B22 #B23 Parkinson's Dementia manifests?
**A.** Along with onset of tremors, rigidity, and bradykinesia
**B.** Years after onset of Parkinson's disease
**C.** As marked and rapid short term memory loss
**D.**  As memory loss after prolonged exposure to environmental stressors
>[!cloze]
>**A.** Along with onset of tremors, rigidity, and bradykinesia
>- See [[Parkinson's Disease#Non-motor]]

---
#B24 Pathological Features of Alzheimer's Disease
**A.** Granulovacuolar degeneration and amyloid angiopathy
**B.** Neurofibrillary tangles
**C.** Neurofibrillary plaques
**D.** AOTA

>[!cloze]
>**D. AOTA** (see [[Alzheimer's Disease#Pathological Features]])

---
# Biological Interventions
#B21 #B23 Action of Risperidone to D2 receptor?
>[!cloze]
>Antagonist (see [[Dopamine Receptor Antagonists]])

---
#B21 #B23 Antipsychotic that is indicated in treatment of bipolar **mania and depression**
>[!cloze] 
>[[Quetiapine]] (see [[Bipolar Disorder]] and [[Mood Stabilizers]])

---
#B21 #B23 #B24 AED with best evidence for use in bipolar **depression**
>[!cloze]
>[[Lamotrigine]] (see [[Mood Stabilizers]])

---
#B21 #B22 Antidepressant that works by blocking reuptake of norepinephrine and serotonin
>[!cloze]
>[[Duloxetine]] (see [[SNRI]])

---
#B21 Antidepressant that does not affect norepinephrine levels
>[!cloze]
>[[SSRI]]

---
#B21 #B22 Mood stabilizer with very narrow therapeutic range
>[!cloze]
>[[Lithium]] (see [[Mood Stabilizers]])

---
#B21 #B23 Advantage of serotonin dopamine antagonist over dopamine antagonist
**A.** Greater efficacy for positive symptoms of Schizophrenia
**B.** Less propensity to cause EPS
**C.** Less expensive
**D.** Less risk for metabolic syndrome
**E.** Less likely to cause agranulocytosis
>[!cloze]
>**B.** Less propensity to cause EPS (see [[Serotonin Dopamine Receptor Antagonists]])

---
#B21 #B23 Antidepressant indicated for anxiety disorder
**A.** Diazepam
**B.** Escitalopram
**C.** Phenobarbital
**D.** Pregabalin
>[!cloze] 
>[[Escitalopram]] (see [[Antidepressants]])
>- While A and D are anxiolytics, antidepressants remain the preferred drug for anxiety disorder as anxiolytics only have immediate and short-term effects
>- C is not indicated for anxiety disorder

---
#B22 Which of the following has no evidence for efficacy in bipolar depression?
**A.** Anticonvulsants
**B.** Antidepressants
**C.** Antipsychotics
**D.** Lithium
>[!cloze]
>**B.** Antidepressants (see [[Mood Stabilizers#Additional Points]])

---
#B22 Benzodiazepine facilitate binding of this neurotransmitter to its receptor
>[!cloze]
>[[GABA]] (see [[Benzodiazepine#Effects]])

---
#B22 Antagonism of which NT causes extrapyramidal symptoms
>[!cloze]
>[[Dopamine]] (see [[Dopamine#Nigrostriatal]])

---
#B22 Manifestation of decreased GABA in tuberoinfundibular area
**A.** Muscle rigidity
**B.** Gynecomastia
**C.** Excessive menses
**D.** Hypoprolactinemia
>[!cloze]
>[[Gynecomastia]] (see [[Dopamine#Tuberoinfundibular]])

---
#B22 40 y/o M suspicious that wife is having relationship outside of marriage. Patient cannot sleep thinking about it and thinks other people are out to get him without basis. What is the drug of choice?
**A.** Olanzapine
**B.** Alprazolam
**C.** Lithium
**D.** Paroxetine
>[!cloze]
>**A.** [[Olanzapine]] (as it appears to be [[Schizophrenia]])

---
#B22 25/F with history of repeated slashing of wrist, boredom, impulsivity, and associated manic episodes. Which of the ff. is the best medication for the patient
**A.** Quetiapine
**B.** Mitrazapine
**C.** Haloperidol
**D.** Lamotrigine
>[!cloze]
>**D.** [[Lamotrigine]] (see [[Mood Stabilizers#Classes]])
>- Patient is suffering from [[Bipolar Disorder]]

---
#B22 Effect of introduction of antipsychotics to schizophrenia patients in the 50s
**A.** Negative symptoms were controlled
**B.** Positive symptoms were controlled
**C.** Recovery of psychosocial functions
**D.** Significant improvement of cognitive function
>[!cloze]
>**B.** Positive symptoms were controlled
>- See [[Dopamine Receptor Antagonists]]

---
#B22 Propanolol is useful for symptoms of heightened arousal in anxiety due to its effects on?
>[!cloze]
>[[Norepinephrine]] (see [[Anxiolytics#Classes]])

---
#B22 Inflow of this ion into the cell is facilitated by Benzodiazepine
>[!cloze]
>Chloride (see [[Benzodiazepine]])

---
#B22 Antidepressant that disinhibits release of norepinephrine and serotonin
>[!cloze]
>[[Mirtazapine]] (see [[Serotonin Norepinhephrine Disinhibitor]])

---
#B22 Mood stabilizer with evidence for efficacy for **both manic and depressive** phase of bipolar disorder
>[!cloze]
>[[Lithium]] (see [[Mood Stabilizers]])

---
#B22 Non-benzodiazepine Hypnotic
>[!cloze]
>[[Zolpidem]] (see [[Benzodiazepine#Effects]])

---
#B24 Action of Brexpiprazole to D2 receptors?
>[!cloze]
>Partial agonist (see [[Serotonin Dopamine Receptor Antagonists]])

---
#B24 Antipsychotic used as adjunct for major depressive disorder
>[!cloze]
>[[Aripiprazole]] (see [[Mood Stabilizers#Classes]])
>- Alternatives include [[Quetiapine]] and combination of [[Olanzapine]] and [[Fluoxetine]]

---
#B24 Antidepressant used for anxiety disorder
**A.** Vortioxetine
**B.** Mitrazapine
**C.** Phenobarbital
**D.** Pregabalin
**E.** Sertraline
>[!cloze] 
>A, B, and E are all considered as [[Antidepressants]] are first line agents for [[Anxiety Disorder]]

---
#B24 Advantage of Serotonin-Dopamine Antagonist to Dopamine Antagonist
**A.** Greater efficacy on negative symptoms of schizophrenia
**B.** Less propensity to cause sedation
**C.** Less expensive
**D.** Less risk for metabolic syndrome
**E.** Less likely to cause agranulocytosis
>[!cloze]
>**A.** Greater efficacy on negative symptoms of schizophrenia
>- See [[Serotonin Dopamine Receptor Antagonists]]

---
#B24 Antidepressant least likely to cause weight gain and sexual dysfunction
>[!cloze]
>[[Vortioxetine]]

---
# [[Psychosocial Interventions]]
#B21 #B23 The **biological model** of the biopsychosocial perspective is focused on the ff. except
**A.** Psychiatric disorders are not a brain disease
**B.** Vulnerabilities to stressors
**C.** Development and use of medication
**D.** Genetic transmission of illness
**E.** Metabolic studies of disease

>[!cloze]
>**B. Vulnerabilities to stressors** is part of the psychodynamic model

---
#B21 #B23 In the biopsychosocial model, the **psychodynamic** model pertains to the ff. except?
**A.** Developmental impasse
**B.** Early childhood separation
**C.** Distortion in early relationship
**D.** Relationship of individual on functioning on social occasions
**E.** Confused parent-offspring relationship

>[!cloze] 
>**D. Relationship of individual on functioning on social occasions**
>- Psychodynamic model focuses on ==unconscious processes== manifesting in behavior

---
#B21 #B23 #B24 Which of the ff. is a possible psychodynamic understanding of depression?
**A.** Repressed anger
**B.** Reexperiencing traumatic event where patient feels helpless
**C.** Loss of self-esteem due to specific needs for validation and role modeling as a child were not met by parents
**D.** Signal for conflicts between id and superego
>[!cloze]
>**C.** Loss of self-esteem due to specific needs for validation and role modeling not met by parents

---
#B21 #B23 #B24 Components of the cognitive triad
>[!cloze]
>- Belief of one's self
>- Belief in the future
>- Belief in the world

---
#B23 Among the biopsychosocial factors of mental illness, which of the ff. is true?
**A.** Psychological factors are supreme
**B.** Person's psychosocila needs should be addressed first
**C.** Structural and functional brain defects are not the priority
**D.**  AOTA
**E.** A and B only
>[!cloze]
>**E.** A and B only

---
#B24 Which of the ff. is true about the biopsychosocial model?
**A.** States of health and illness are attributed to psychological factors only
**B.** Illness is caused by interaction of several factors
**C.** It is the traditional model
**D.** AOTA
>[!cloze]
>**B.** Illness is caused by interaction of several factors

---
# [[Psychiatric Emergencies]]
#B21 #B23 Condition(s) associated with serious life-threatening illness more than a primary psychiatric disorder
**A.** Chronic insidious onset
**B.** Focal neurologic signs
**C.** Normal vital signs
**D.** Normal physical or neurological examination
**E.** No history of exposure to toxins or poisons
>[!cloze]
>**B.** Focal neurologic sign
>- See [[Psychiatric Emergencies#Indicators for Life-threatening Conditions]]

---
#B21 #B23 General approach for psychiatric emergencies
**A.** Assume normal vital signs
**B.** Not necessary to read patient chart
**C.** Think about discharge even before seeing patient
**D.** Not necessary to get collateral information
**E.** Check pregnancy in women of child-bearing age
>[!cloze]
>**E.** Check pregnancy in women of child-bearing age (see [[Psychiatric Emergencies#General Approach]])

---
#B21 #B23 Violence is/are characterized by the following:
**A.** Excess verbal and motor behavior
**B.** Intent to deliver noxious stimuli
**C.** Deliberate use of physical force with high possibility of injury
**D.** NOTA
**E.** AOTA
>[!cloze]
>**C.** Deliberate use of physical force with high possibility of injury
>- see [[Psychiatric Emergencies#Definition of Terms]]

---
#B21 #B23 Physical conditions that may increase risk for suicidal behavior
**A.** Chronic pain
**B.** Progressive or chronic illness
**C.** Substance abuse
**D.** Recent childbirth
**E.** AOTA
>[!cloze]
>**E.** AOTA (see [[Psychiatric Emergencies#Suicide Risk]])

---
#B21 #B23 The ff. is/are considered in assessment of suicidal patient
**A.** Patient's family coping abilities
**B.** Patient's living condition
**C.** Availability of support
**D.** History of impulsive behavior
**E.** AOTA
>[!cloze]
>**E.** AOTA (see [[Psychiatric Emergencies#Depressed or Suicidal]])

---
#B24 25 y/o M brought to ER by good Samaritan. Patient **refused to answer questions and kept to himself** while lying on hospital bed. Person who brought in patient narrated that patient was **trying to jump from bridge**. On PE, vital signs are normal and forearms showed **several cuts**. 

Suicidal risk severity?
>[!cloze] 
>High suicide risk behavior
>- **Presence of a plan and attempt with lethality** (see [[Psychiatric Emergencies#High Risk Factors]])


If patient suddenly becomes **agitated and aggressive**, what should you do initially?
**A.** Restrain immediately without talking
**B.** Place inside padded isolation room
**C.** Try to talk and de-escalate
**D.** Call police and have patient arrrested
**E.** Inject 5 mg Haloperidol IM immediately
>[!cloze]
>**C.** Try to talk and de-escalate (see [[Psychiatric Emergencies#De-escalation]])

---
# Somatic Symptoms and Disorders
#B21 73 y/o F complaining of **blurring of vision**. After several consults and tests, ophthalmologist repeatedly told her it was a normal part of aging. **Excessively worried** she is going blind. Diagnosis?
>[!cloze] 
>[[Somatic Symptom Disorder]]

---
#B21 Best way to differentiate factitious disorder and malingering
**A.** Production of false symptoms only in FD
**B.** Voluntary control of symptoms only in FD
**C.** No physical disease in malingering only
**D.** External incentive in malingering only
>[!cloze]
>**D.** External incentive in malingering only (see [[Factitious Disorder#Differentiating from Malingering]])

---
#B21 Patient is always anxious that she will have **another asthma attack**. Even though she usually triggers heightened anxiety that leads to the asthma. Diagnosis?
>[!cloze]
>[[Psychological Factors affecting Other Medical Conditions]]

---
#B21 Which of the ff. is false about factitious disorder?
**A.** Intention of false or grossly exaggerated symptoms
**B.** Need to assume sick role and receive care
**C.** Gain is often very apparent and conscious
**D.** Patients often receive multiple hospitalizations
>[!cloze]
>**C.** Grain often very apparent and conscious
>- [[Factitious Disorder]] patients come from an unconscious want for care

---
#B22 36 y/o with chief complaint of **multiple body pains in past month** which transfer to different body locations from time to time. Physical and neurologic exams are normal. Labs are within normal range. What do you do next?
**A.** Subject patient to other specific test
**B.** Ask patient if there was recent event that happened in her life
**C.** Prescribe pain relievers and sent patient home
**D.** Refer to pain specialist
>[!cloze]
>**B.** Ask patient if there was recent event that happened in her life

---
#B22 In DSM-V, excess thoughts, feelings, or behaviors related to **somatic symptoms** with disproportionate thoughts about seriousness of symptoms. Diagnosis?
>[!cloze]
>[[Somatic Symptom Disorder]]

---
#B22 Masochists show this illness behavior. 
**A.** Sensitive to fluctuations in availability of gratification from others
**B.** Power is exerted not by what patient does but what they refuse, forge, omit to do
**C.** Grew up to become compulsive carers
**D.** Feel that suffering and pain from illness and treatment provide relief from feelings of guilt
>[!cloze]
>**D.** Feel that suffering and pain from illness and treatment provide relief from feelings of guilt

---
#B22 What is the sick role?
**A.** Being stoic or dramatic
**B.** Role that society ascribes to people when they are ill
**C.** How symptoms are perceived, evaluated, and acted upon
**D.** Behavior of individual who is sick
>[!cloze]
>**B.** Role that society ascribes to people when they are ill

---
#B22 Powerful inactivity in coping with sick role signifies with what type of personality?
>[!cloze]
>Passive-Aggressive

---
#B23 How long should there have been symptoms for somatic symptom disorder?
>[!cloze]
>**6 months** (see [[Somatic Symptom Disorder]])

---
#B23 Munchausen's syndrome is an example of?
>[!cloze]
>[[Factitious Disorder]]

---
#B23 Patient is primarily concerned with idea that he is **ill with few or no physical signs and symptoms present**
>[!cloze]
>[[Illness Anxiety Disorder]]

---
#B24 24 y/o call center agent who sought consult for chief complaint of **laging nag-aalala**. Since first lockdown in March 2020, she became very anxious that she has or will get infected. Initially was able to leave house to run errands but found being excessively worried that she would get infected. Eventually **refused to leave house** or go out into the years. She would order needs online and have no interactions with outsiders. Dilligently takes whatever she read would help prevent infection medically proven or not. Get **very irritated with household members who leave house for non-essential reasons** in fear that they would bring in virus. Even when she **didn't feel any physical symptoms**, she worried that she was an asymptomatic carrier. She immediately books swab tests with slightest cough or sore throat. She would worry that the timing and sample collection was wrong. Eventually referred to psychiatry in Jan 2021 to get medical certificate because she continued to refuse going to work physically.

Diagnosis?
>[!cloze]
>[[Illness Anxiety Disorder]] (no real symptoms are present)

Which of the ff. will best help the patient?
**A.** Advice her to ask medical doctor directly if she has any questions and concerns about COVID, its diagnosis, symptoms, and management
**B.** Tell her to seek info from online communities and forums
**C.** Reassure her that number of cases and deaths reported are blown out of proportion and that COVID is not as deadly
**D.** Ask her to monitor her vital signs and O2 every 4 hours to make sure she does not miss out on COVID symptoms
>[!cloze]
>**A.** Advice her to ask medical doctor directly if she has any questions and concerns about COVID, its diagnosis, symptoms, and management


---
#B24 Disorder characterized by preoccupation with having or acquiring serious illness whether patient presents with symptoms or not
>[!cloze]
>[[Illness Anxiety Disorder]]

---
# [[Gender Dysphoria]] and [[Paraphilic Disorders]]
#B21 #B22 #B23 #B24 11 y/o M reported to manifest with **irritable mood and beginning verbal aggression at home and school**. Developmental history shows **strong preference for dolls, cooking toys, and usually hangs out with female classmates or family**. Always prefer to **urinate sitting down** saying it's less tiring that way. Several times was caught **trying on sister's swimsuit** and on confrontation, he just angrily walks away. Been caught watching porn in internet. Academic performance declined significantly. Which of the ff. best describes what this patient is going through?
**A.** Phase of life
**B.** Adjustment disorder with disturbance of mood and conduct
**C.** Gender Identity Disorder
**D.** Gender Dysphoria
>[!cloze]
>**D.** [[Gender Dysphoria]]

---
#B21 #B22 #B23 #B24 The ff. are true except?
**A.** Children with gender dysphoria have higher rates of impulsion in behavior
**B.** Adolescents with gender dysphoria have high rates of substance abuse and suicidality
**C.** Conversion is one of the goals of psychotherapy
**D.** Individual and family psychotherapy is geared towards acceptance
>[!cloze]
>**C.** Conversion is one of the goals of psychotherapy

---
# [[Post-traumatic Stress Disorder|PTSD]]
#B21 #B22 #B23 #B24 For female victims of rape, which among the ff. is least indicative of PTSD?
**A.** Uncontrollable thoughts that people are blaming her for the incident
**B.** Uncontrollable thoughts that people are out to get her
**C.** Uncontrollable thoughts in the form of flashbacks
**D.** Uncontrollable thoughts pertaining to shame and guilt for being weak and vulnerable
>[!cloze]
>**B.** Uncontrollable thoughts that people are out to get her (see [[Post-traumatic Stress Disorder#Diagnostic Criteria]] Intrusion)

---
#B21 #B22 #B23 #B24 The ff. symptoms of PTSD are commonly seen in both adults and children except?
**A.** Recurrent nightmares
**B.** Sadness or irritability
**C.** Reduced interest in significant activities
**D.** Enuresis
>[!cloze]
>**D.** Enuresis is more commonly seen in children ([[Post-traumatic Stress Disorder#Children ≤ 6 years old]])

---
#B21 #B22 #B23 #B24 Initial management for PTSD includes the ff. except?
**A.** Ensuring safety of victim
**B.** Crisis intervention
**C.** Use of Fluoxetine and Escitalopram
**D.** Use of Risperidone
>[!cloze]
>**D.** Use of [[Risperidone]] 
>- [[Post-traumatic Stress Disorder|PTSD]] recommends the use of [[SSRI]] and [[Mood Stabilizers]] over [[Antipsychotics]]
>- Batch 2022 answer included Risperidone and [[Clozapine]]
>- Batch 2024 asked which is included and choice D was changed to **AOTA** which should be the right answer

----
#B21 #B22 #B23 #B24 Which among the ff. situations is most likely to cause ASD or PTSD?
**A.** Death of old family member from chronic illness
**B.** Witnessing successful suicide attempt of friend or loved one
**C.** Failed major subject in school
**D.** Watching incident of Marawi on TV
>[!cloze]
>**B.** Witnessing successful suicide attempt of friend or loved one
>- PTSD requires event that is almost universally stressful hence, the best answer is B.
>

---
#B22 28 y/o fireman diagnosed with PTSD 1 month ago. Which of the ff. is true?
**A.** Experienced manmade disaster
**B.** Suicidal
**C.** Talks alone
**D.** Sight of fire calms him
>[!cloze]
>**A.** Experienced manmade disaster
>- As a fireman, the most likely cause for the PTSD is a fire. 

What other disturbances can he be experiencing?
**A.** Disturbed sleep, Persecutory Delusions, Thought Racing
**B.** Avoidance, Flashbacks, Flight of Ideas
**C.** Numbing of emotions and suicidal thoughts
**D.** Reliving event, distressing and intrusive flashbacks or nightmares
>[!cloze]
>**D.** Reliving event, distressing and intrusive flashbacks or nightmares

Patient may experience a Major Depressive Episode. Which of the ff. is a criteria for MDE?
**A.** 2 weeks of depressed mood, sleep disturbance, and mind racing
**B.** 6 weeks of lost interest and suicidal ideation
**C.** Depression, sleep changes, eating and movement changes, worrying
**D.** Depressed mood and palpitations
>[!cloze]
**C.** Depression, sleep changes, eating and movement changes, worrying
>- see [[Major Depressive Episode]]

---
#B22 Patient is a victim of incest and broke down while attending PTSD lecture. What is she experiencing?
**A.** Anxiety
**B.** Flashback
**C.** Panic Attack
**D.** Call for help
>[!cloze]
>**C.** Panic Attack

How should you handle the situation if you are near the patient?
**A.** Ignore
**B.** Assist to leave room
**C.** Inject Haloperidol to abort triggered memory
**D.** Hold hands
>[!cloze]
>**B.** Assist to leave room

Recommended management for patient
**A.** Female psychiatrist
**B.** First need to hear their story
**C.** Assure that she is safe while being interviewed
**D.** Just wait for her to talk
>[!cloze]
>**C.** Assure that she is safe while being interviewed

---
# [[Pediatric Psychiatric Disorders]]
#B21 #B22 Recent inclusion in DSM-5 under Conditions for Further Study
>[!cloze]
>- [[Internet Gaming Disorder]]
>- [[Non-Suicidal Self-Injury]]

---
#B21 #B22 #B24 Which of the ff. is true regarding the principle of confidentiality in working with children and adolescents?
**A.** Just like in adults, absolute confidentiality must be exercised and observed at all times
**B.** Extent of confidentiality in child assessment is correlated with age
**C.** Preschool children are informed that if clinician becomes concerned that the child is a danger to himself or others, information is shared to patients
**D.** Adolescents may be assured that confidentiality will require permission be requested of them at all times, and that confidentiality will not be sacrificed without their permission
>[!cloze]
>**B.** Extent of confidentiality in child assessment is correlated with age

---
#B21 #B22 #B23 You are assigned to develop a child and adolescent mental health program. Because of limited resources, you want to focus on adolescents (13-18 years old). Based on the most common psychiatric conditions, which of the ff. should you maximize available resources for?
**A.** Bipolar Disorder
**B.** Social Anxiety Disorder
**C.** Schizophrenia
**D.** Major Depressive Disorder and Suicide
**E.** Substance Abuse
>[!cloze]
>**B.** Social Anxiety Disorder
>- Lecturer specifically mentioned that this was commonly seen in adolescents
>- For Batch 2022, the answer was **Major Depressive Disorder and Suicide**
>- For Batch 2023, the answer was **Substance Abuse**  

---
#B21 12/F only child brought to clinic by parents as **she has not been sleeping well** recently and is **persistently tearful.** Normal developmental history. Good relationship with parents. Parents take her viewpoint very seriously and is allowed to make certain choices and decisions appropriate for her age. Clear rules about homework and reinforcements for good behavior. Does well academically and knows she gets rewards for working hard. Has close friends. Family history shows that **her mother has been hospitalized repeatedly for depression** since Carla was born and she would stay with her grandmother then. 3 months ago, **grandmother suddenly passed away** from stroke. Mother was again hospitalized when she started having symptoms of depression and **she was left alone with the helper**. Father is very worried about her but is unable to cut down due to work. What would you consider areas contextual protective factors for her?
**A.** Internal locus of control
**B.** Father's work schedule and maternal depression
**C.** Authoritative parenting and peer support
**D.** Good academic performance
>[!cloze]
>**C.** Authoritative parenting and peer support

#B23 Which of the ff. is a risk factor?
**A.** Grandmother's death
**B.** Family history of maternal depression
**C.** Father's inability to spend time with her
**D.** AOTA
>[!cloze]
>**D.** AOTA

#B24 Biological risk factor contributing to development of condition
**A.** Grandmother's Stroke
**B.** Mother's Depression
**C.** Father's Anxiety
**D.** Parent's Inability to Spend Time with her
>[!cloze]
>**B.** Mother's Depression

---
#B21 9/M referred to Psychiatry upon recommendation of teacher due to **behavioral problems**. Noted to be **talkative** in class, **blurts out answers** before teacher completes questions. Jumps the queue in cafeteria during lunchtime. Called names and teased regularly. **Responds by hitting them**. Developmental history shows he ran around a lot at 4 or 5 y/o. Nannies gave up on him because they could not keep up. Always on the go. Stand up wand walk around even when classes were ongoing. At present, patient is noted to be **fidgety and squirmy**. Diagnosis?
>[!cloze]
>[[ADHD]]

---
#B21 #B22 10/M referred for behavioral problems. Reportedly **prone to emotional and intense reactions** to social situations such that he **gets into fights and self-harms** when he is upset. Articulate in both English and Tagalog. Understands questions well and able to  provide logical and goal-directed answers. Noted that the behaviors in school are **related to lack of understanding and difficulty following social rules** of language, gestures, and social context. Unable to infer meanings and understand another's intention of communication and has difficulty **picking up verbal and non-verbal cues**. Also difficult to understand environmental and social cues. Diagnosis?
>[!cloze]
>Social Communication Disorder

---
#B21 #B22 14/M left to care for maternal grandparents since parents left work work abroad 6 months ago. 2 months PTA, started to **isolate himself and academic performance gradually declined.** 2 weeks PTA, noted to be **mumbling to himself** and became **angry and hostile** upon being called. Claim to **hear voice of Jesus who allegedly game him special powers**.  Maternal uncle has similar symptoms. On admission, noted to run away from home to carry out his mission. Grandparents found him in neighboring barangay and brought to ER for assessment. Diagnosis?
>[!cloze]
>[[Brief Psychotic Disorder]]

---
#B21 #B22 15/F referred to OPD clinic because of **refusal to go to school**. Difficulty **began during Algebra exam last year**. While taking exam, she suddenly felt that **she could not catch her breath and became dizzy.** Felt as if she were out of her body and world was dreamlike. Had palpitation, cold sweats, numbness, butterflies in stomach, felt she was about to faint and embarrass herself. Felt she was about to die. Excused and left but episode lasted for a few minutes. Started to fear leaving home. Became homebound but episodes continued. Preoccupied with thoughts of having another episode. Diagnosis?
>[!cloze]
>[[Panic Disorder]]

---
#B21 #B24 14/F came in for 6 week history of **refusal to go to school**. Consistent honor student and **perfectionist**. In PE swimming class, she was harshly reprimanded for refusal to jump into pool which generalized to refusal to go to school altogether. **Throws tantrums** when her mom tells her to go to school. **Recurrent bad dreams** of drowning in pools and being reprimanded. Constantly verbalizes feelings of shame. PWI?
>[!cloze]
>[[Post-traumatic Stress Disorder|PTSD]] (there is a traumatic event that triggered the condition and she is reliving and having nightmares about it)
>- In **2024**, the duration was shortened to ==2 weeks== hence the answer **Acute Stress Disorder** instead

---
#B21 #B23 15/F brought for cutting her left arm. Which of the ff. is a high risk for suicide that would make you admit the patient?
**A.** Cutting to find relief from distressing thoughts
**B.** Chronic (past incidents done with friends)
**C.** Suicide Note
**D.** Cutting as temporary solution to deal with negative emotions
>[!cloze]
>**C.** Suicide Note (All other choices are [[Non-Suicidal Self-Injury]])

---
#B22 The ff. is true about adolescents and eating disorders except?
**A.** Exaggerated focus on weight, shape, and dieting may be normal
**B.** As adolescents grow old, they appear less satisfied with weight
**C.** Underlying biological factors like heredity and GABA dysregulation are linked to ED
**D.** Typical onset of ED is late adolescence
>[!cloze]
>**C.** Underlying biological factors like heredity and GABA dysregulation are linked to ED
>- Mainly involves the cingulate cortex, basal ganglia, thalamus

---
#B22 #B23 True of Major Depressive Disorder in Children and Adolescents
**A.** Major depressive episode in adolescent is likely to manifest via somatic complaints and psychomotor agitation
**B.** Children can be reliable informants about emotions, relationships, and difficulties in psychosocial functions
**C.** Direct questioning of depressed children and adolescents about suicidal thoughts is discouraged because it may reinforce idea of suicide
**D.** SSRI play no role in treating depression of young people given poor safety profile and ADRs
>[!cloze]
>**A.** Major depressive episode in adolescent is likely to manifest via somatic complaints and psychomotor agitation
>- For batch 2023, the answer was **Major Depressive Episode in prepubertal child is less likely to manifest with somatic complaints and psychomotor agitation**

---
#B22 How does marital discord predispose children to psychological problems?
**A.** Witnessing quarreling, conflict, and violence results in child developing internal locus of control
**B.** Child feels strong loyalty to both parents and fear that positive gesture made towards parent may be interpreted as disloyalty to others
**C.** Child may believe that they were responsible for marital discord and resolving patient's difficulties
**D.** Marital discord may prevent parents from working cooperatively together to provide children with optimal parenting environment
>[!cloze]
>**A.** Witnessing quarreling, conflict, and violence results in child developing internal locus of control
>- Answer for feedback but B, C, and D seem to be the appropriate answer for the question
>- Likely forgot to put the word except in the question

---
#B22 Which of the ff. is true about psychopharmacology of children?
**A.** Children metabolize and eliminate drugs more slowly than adults
**B.** Etiologic heterogeneity may explain differences in clinical response among children
**C.** Children may require weight-adjusted dose
**D.** Drug half-lives are longer in children
>[!cloze]
>**B.** Etiologic heterogeneity may explain differences in clinical response among children

---
#B22 Strength of evidence for using Methylphenidate, Atomoxetine, and Clonidine for ADHD in children

>[!cloze]
>Type I

---
#B22 Contraindication for Family Therapy
**A.** Open and stressful conflict among family ± symptomatic behavior in ≥ 1 member
**B.** Covert family problems that may give rise to dysfunctional behavior in ≥1 member or when other family members covertly support or perpetuate disorder
**C.** Discussing long dormant, charged, or explosive family issues with whole family after family commits seriously to treatment
**D.** Stressful situations in family when ≥1 member are severely destabilized and require hospitalization
>[!cloze]
>**D.** Stressful situations in family when ≥1 member are severely destabilized and require hospitalization

---
#B22 Which of the ff. describe manifestation of distress in children at time of annulment or separation of parents
**A.** Regression, intense anxiety and fear, sleep disturbance
**B.** Powerlessness, loneliness, anxiety
**C.** Acute depression, intense anger, anxiety
**D.** Blank stare, aggression, withdrawal
>[!cloze]
>**A.** Regression, intense anxiety and fear, sleep disturbance

---
#B22 Which of the ff. is a potent predictor for PTSD chronicity in children
**A.** Immediate institutional placement
**B.** Inconsistent parental support and authoritative parenting
**C.** Absence of psychosocial support and exposure to ongoing psychosocial adversity
**D.** Average intelligence and lack of education
>[!cloze]
>**C.** Absence of psychosocial support and exposure to ongoing psychosocial adversity

---
#B23 16/M **assaulted neighbors** by climbing up roof and throwing rocks and stones at them. **Smoked occasionally, drank alcohol, and stole money and goods** from neighbors. Problem started 1 year ago but intensified in last 6 months. Mother works as laundry woman while father is in prison for stealing. PWI?
>[!cloze]
>[[Conduct Disorder]]

---
#B24 17/F brought in because she verbalized she wished to die. Which of the ff. are high risk factors for suicide that would need admission?
**A.** Prior suicide attempt
**B.** Plan to overdose on 20 tablets of 500mg Paracetamol bought from local Sari-Sari store in the next 3 days
**C.** Written instructions left for yaya to take care of beloved pet doc
**D.** AOTA
>[!cloze]
>**D.** AOTA (see [[Psychiatric Emergencies#High Risk Factors]])

---
#B24 16/F transferred for SHS 6 months ago. Previously did well academically and socially in Junior HS. In her new school, felt **lonely and unhappy**. Found it difficult to initiate conversation and make new friends. At about same time as transfer, **parents started to fight more which she frequently witnessed**. 2 months ago, patient started to feel **sad and depressed**. Difficult sleeping at night, often crying to sleep, poor appetite. difficulty focusing and concentrating, takes longer to finish homework. Feels tired in morning and doesnt have energy to get out of bed. Forced to go to school and incurred several absences. Rather stays in her room. Mother would scold her. **Used scissors or other sharp objects to make her feel better.** Denies want to die, claims cutting distracts from suicidal thoughts. Working diagnosis?
>[!cloze]
>- [[Major Depressive Disorder]]
>- [[Non-Suicidal Self-Injury]]

---
#B24 Based on DSM-5, ff. psychiatric condition are exclusively diagnosed in children except?
**A.** Conduct Disorder
**B.** Separation Anxiety Disorder
**C.** Oppositional Defiant Disorder
**D.** Disruptive Mood Dysregulation Disorder
>[!cloze]
>**B.** Separation Anxiety Disorder

---
#B24 10/F referred for **tearfulness** in school gradually worsening over months. During interview, she said she **worried about many routine daily activities and responsibilities.** Worried about doing poorly at school that she made mistakes which would later be discovered, that friends would not like her, parents would be disappointed. Worries she would be too early or too late for school bus, no room for her on the bus, or forget her school books. Worried about her health and had frequent stomach aches. Wide ranging fear about safety of her family. Concerns about future. Worried she would fail exams and unable to find satisfactory job, fail to find marital partner. Reported feeling continuously restless and unable to relax. Diangosis?
>[!cloze]
[[Generalized Anxiety Disorder]]

---
