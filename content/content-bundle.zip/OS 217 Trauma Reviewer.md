---
banner_icon: 📝, 
tags: OS217/Trauma,flashcards
type: Exam
---
>[!important] Resources
>- [2024 JOWA](file:///Users/bea/Library/Mobile%20Documents/3L68KQB4HG~com~readdle~CommonDocuments/Documents/OS%20217%20Trauma/2024%20Jowa%20-%20OS%20217%20Trauma.pdf)
>- [2023 KUWAN](file:///Users/bea/Library/Mobile%20Documents/3L68KQB4HG~com~readdle~CommonDocuments/Documents/OS%20217%20Trauma/2023%20Kuwan%20-%20OS%20217%20Trauma%20Exam%20(Answered).pdf)
>- [20XX AYUDA](file:///Users/bea/Library/Mobile%20Documents/3L68KQB4HG~com~readdle~CommonDocuments/Documents/OS%20217%20Trauma/20XX%20Compiled%20Ayuda%20-%20OS%20217%20Trauma.pdf)
# [[01 Initial Assessment of a Trauma Patient]]
[2023, 2024] In the assessment of multiply injured, the highest priority is airway because?::Airway kills the fastest
<!--SR:!2022-09-10,4,270-->

[2020, 2023, 2024] During resuscitation, D5-containing fluids are generally not recommended because of?::Osmotic diuresis
<!--SR:!2022-09-10,4,270-->

[2023, 2024] Injuries are most often missed at the?::Back, Axilla, Perineum

[2023, 2024] In performing maneuvers to ensure airway patency, it is the most critical to?::Stabilize the cervical spine
<!--SR:!2022-09-10,4,270-->

[2023] The main goal during secondary survey::Find limb-threatening injury

[2023] What is the estimated GCS of an intubated patient with E=2 and M=3?
?
$$GCS=E+V+[(E\times0.4)+(M\times0.5)]=2+3+[0.8+1.5]=2+3+2.3=7.3\approx7$$

## Personal Questions
What are the basic concepts of trauma?
?
- Recognize the problems
- Treat the greatest threat to life
- Repeated and dynamic assessment and monitoring of the status of the patient

Steps for Approach to Multiply Injured Patients
?
1. Primary survey
2. Resuscitation
3. Secondary survey
4. Definitive management
5. Tertiary survey
6. Reassessment

Components of Primary Survey
?
- Airway and cervical spine control
- Breathing
- Circulation (Hemorrhage control)
- Disability (Neurologic Exam)
- Exposure and environmental control

What is the most common cause of airway obstruction in the unconscious patient?::Tongue

What are **absolute indications** for intubation?
?
- GCS ≤ 8 (Unable to maintain patent airways and prone to aspiration)
- Hemorrhagic Shock (Possible arrest in the future)

Risk factors for compromised airway patency
?
- Instability (hemodynamic)
- Neck hematoma or trauma
- Trauma to the face (maxillofacial)
- Unresponsive (GCS ≤ 8)
- Bleeding from oropharynx
- Apnea
- Thermal inhalational injury
- Emesis, epistaxis, and hemoptysis

Initial procedure of choice for securing a definitive airway::Orotracheal intubation

Surgical airway is performed when ==intubation fails once==

First line management for tension pneumothorax::Needle thoracentesis along the 5th ICS at the anterior axillary line

Management for sucking chest wounds (diameter >2/3 of trachea):::Three-sided dressing

Stable Vital Signs (BP, HR, RR)::120/80, 110, 24

Ideal resuscitation fluid for adults::Crystalloids (Plain Lactated Ringer's or NSS) that is warm

Components of Secondary Survey
?
- Swab for COVID
- Allergies
- Medications
- Past illnesses
- Last meal
- Events preceding the event

Signs of Urethral Injury (Contraindications for Urethral Catheter)
?
- Blood in urethral meatus
- Perineal hematoma
- High lying prostate (not really used as DRE needs consent)

# [[02 Trauma Epidemiology]]
[2023, 2024] Assuming transfer of energy is 100% efficient and the surface area involved is the same, theoretically, which would cause more injury to the human jaw, a 100-gram gloved fist of a featherweight boxer travelling at 8 feet per second, or a 4 gram basketball hitting the body at 40 feet per second?::The injury will be the same (3200 J force for both)
<!--SR:!2022-09-10,4,270-->

[2024] Which of the ff. statements is incorrect?
A. In the 1-44 age group, trauma is the leading cause of mortality in US and PH
B. Among intentional injuries, homicides are more common in US
C. Average trauma death rate in PH is 42-44 per 100,000 
D. In PH, mortality secondary to trauma is highest in 15-24 age group
?
B. Among intentional injuries, homicides are more common in US (Suicides are more common)

[2023, 2024] Which of the ff. statements is incorrect?
A. Most PGH trauma consults are male
B. Most PGH trauma consults are from penetrating injuries
C. Only 20% of admissions in Trauma ward are from falls, vehicular crashes, and work-related injuries
D. Most pediatric trauma admissions are from fractures
?
C. Only 20% of admissions in Trauma ward are from falls, vehicular crashes, and work-related injuries

[2023, 2024] Which of the ff. statements would be incorrect?
A. 1st peak in trimodal pattern of trauma deaths are those who die at the site of injury
B. In US, good pre-hospital care has lowered 1st peak
C. 2nd peak represents number of patients dying from post-op complications
D. In the US, good surgical training in intensive care and surgical nutrition has lowered the 3rd peak
?
C. 2nd peak represents number of patients dying from post-op complications

[2024] Which of the ff. statements would be incorrect?
A. The responsibility of Trauma Prevention lies solely in the government who is mandated to promote health care to its citizens
B. In the Philippines most of those who are injured are either children or adults in the prime of their lives
C. The cost of Trauma Care is magnified by the lost of man-hours in the workforce during the patient’s debilitation
D. In the past years there had been an epidemiologic shift from communicable to lifestyle-related diseases
?
A. The responsibility of Trauma Prevention lies solely in the government who is mandated to promote health care to its citizens

[2024] Which of the ff. statements would be incorrect?
A. Most injuries are preventable
B. Intentional injuries are preventable
C. Accidents are unpreventable and unpredictable
D. Trauma is a disease
?
B. Intentional injuries are preventable
C. Accidents are unpreventable and unpredictable

[2024] Earliest document describing trauma care is the?::Edwin Smith Papyrus

[2024] The first true emergency medical system for trauma care was developed during the?::Early Indian Empire

[2024] The two current modes of trauma pre-hospital stance are?
?
* Stay and Play
* Load and Go

[2024] The ff. statements regarding trauma epidemiology in PH are true:
A. June has the highest monthly incidence of vehicular crashes
B. The ARMM has one of the highest trauma mortality among the regions in the country
C. The jeepney is the most dangerous vehicle in PH
D. NOTA
?
D. NOTA (October sees the highest monthly incidence, CALABARZON and NCR have the highest rates)

[2024] In the tri-modal pattern of Trauma Deaths, controlling the second peak entails?
?
- Upgraded hospital equipment
- Emergency medicine and traumatic surgery expertise

[2023, 2024] Based on the 2017 DOH report, which region has the highest mortality rate secondary to trauma?::Region IV-A (CALABARZON)

[2024] Based on the 2016 DOH report, which region has the 2nd highest mortality rate secondary to trauma?::NCR

[2020, 2023, 2024] In Dr. Trunkey's "Peaks of Trauma Deaths", which peak could be controlled by good surgical intensive care and good nutrition?::3rd Peak

[2024] According to the Global Peace Index 2019, which country is the most unsafe?::Iraq

[2023, 2024] Which animal kills the most humans each year?::Mosquitoes

[2020, 2023, 2024] Looking through wars in modern history, mortality rate from penetrating injuries are?::Increasing

[2024] Which is true for disasters in PH?
A. PH is top 10 since 1990
B. PH is number 1 in 1996
C. PH is number 1 in 2016
D. AOTA
?
A. PH is top 10 since 1990 (number 1 in 1995 only)

[2024] The Haddon's Matrix of Injury Etiology incorporates the ff. factors in brainstorming solutions for injury prevention except?
A. Host or human
B. Vector or vehicle
C. Environment
D. NOTA
?
D. NOTA (*All of the identified are part of Haddon's Matrix of Injury Etiology*)

[2023] Which is true for the PH?
A. Experiences two earthquakes daily
B. Most floods occur during the monsoon season of May to July
C. Fires still cause the most number of disasters
D. Trauma is the leading cause of death in the 1-45 year old age group
?
D. Trauma is the leading cause of death in the 1-45 year old age group

[2023] According to the Global Peace Index of 2017, which country is the safest?::Iceland

## Personal Questions
Papyrus Ebers:::Historical article from 1550 BCE which enumerates medical remedies with most sections devoted to war wounds

The Ancient Greeks had the ==klisiai== and the Ancient Romans had the ==valetudinaria== as special structures dedicated to the treatment of the injured

Iatros:::Greek healers who treated **trauma patients** translating to "arrow remover"

Described the primitive army ambulance service::Ashoka

First person to describe reconstructive surgery::Sushruta (called Salyahara meaning arrow remover)

Pioneer in treatment of gunshot wounds::Ambroise Pare

Napoleon's surgeon who is responsible for the **ambulance volante** (first wheeled ambulance)::Dominique Jean Larrey

General Surgeon that first advocated for **mandatory laparotomy** for penetrating wounds::James Marion Sims

Stay and Play System for EMS:::Physician and team first stabilizes and treats the patient before placing them to definitive treatment

Load and Go System for EMS:::Injured is immediately transferred to a dedicated Trauma Center while pre-hospital management is carried *en route*

Which regions are typically affected by typhoons?::Regions II, V, and VIII

Most vulnerable regions to floods
?
- Eastern Mindanao (X and XI)
- Northern Samar (VIII)
- Central Luzon (III and IV)
- Bicol Region (V)

Majority of floods in the PH occur during ==July to September==

Most vulnerable areas to droughts
?
- Iloilo
- Guimaras
- Ilocos
- Cagayan Valley
- Northern and Southern Mindanao
- Camiguin

What are the active volcanoes in PH
?
- Mayon (Albay)
- Taal (Batangas)
- Hibok-hibok (Camiguin)
- Bulusan (Sorsogon)
- Kanlaon (Negros)
- Pinatubo (Pampanga)

Active earthquake regions
?
- Region VIII (Samar and Leyte)
- Region X (Eastern Mindanao)

Highly active earthquake regions
?
- Northern Luzon
- Lubang Island (between Batangas and Mindoro)
- Mindoro

Term coined after the disaster in Payatas in 2010::Garbalanche

Considered the most dangerous roads of the PH::NLEX and SCTEX

Disaster Risk Equation
?
$$Disaster\ Risk=\frac{Hazard\times Vulnerability}{Coping\ and\ Adaptive\ Capacity}$$

Actions for addressing the First Peaks of trauma deaths
?
- Provide good public health system
- Improve pre-hospital care and advanced trauma life support
- Disaster awareness and preparedness programs
- Advocacies for injury prevention

Actions for addressing the Second Peaks of trauma deaths
?
- Improve emergency medical and surgical expertise
- Improve equipment or instruments for diagnosis and intervention

Actions for addressing the Third Peaks of trauma deaths
?
- Provide good post-operative care
- Employ surgical intensive care
- Improve patient's nutrition and rehab services

4E's of Injury Prevention
?
- Equity
- Engineering
- Enforcement
- Education

# [[03 Definition and Pathophysiology of Traumatic Injuries]]
[2024] Which of the ff. wound features is the most useful for identifying the type of weapon used?
A. Foreign body material
B. Depth
C. Number
D. Wound margins
?
D. Wound margins (Blunt injuries cause jagged, abraded, contused wounds while incisions have clean margins)

[2024] When dealing with case of physical injuries, even minor non-life-threatening ones must be documented to?::Help reconstruct what happened to the patient (Ex. photos of hand cuts between thumb and index indicates defensive injury)

[2024] Abrasions could?
A. Be cutaneous and visceral
B. Identify the assailant
C. Identify the weapon
D. Cause fatal blood loss
?
C. Identify the weapon

[2024] Blunt force injuries of the head consisting of an occipital scalp laceration associated with contusions of the frontal lobes of the brain are most consistent with?::Fall with impact to the back of the head (coup-countrecoup injury)

[2024] In gunshot wounds:
A. Width of bullet's track along a solid organ is the same as the diameter of the bullet
B. Careful measurement of entrance wound can indicate the bullet's caliber
C. Location of gunshot wound/s on victim's body can help determine assailant's handedness
D. Internal tissue injuries caused by bullet are lacerations
?
D. Internal tissue injuries caused by bullet are lacerations

[2024] Gunfire injury in those killed by police in buy-bust ops is noted commonly in the upper extremities. This is significant in determining the issues of?
A. Actual drug use/pushing
B. Handedness
C. Allegedly "nanlaban sila" therefore, killing by police is justified
D. Cause and manner of death
?
C. Allegedly "nanlaban sila" therefore, killing by police is justified
*Humans tend to protect their face and head when threatened thus the hits of the UE*

[2024] Inside the barrel of a shotgun, the surface:
A. Is smooth
B. Has riflings
C. Has lands
D. Has grooves
?
A. Is smooth

[2024] A circular fracture around the foramen magnus indicates a high impact fall with the individual landing on his?
?
Buttocks
*The vertebral column pushes upwards and the base of the skull is impaled by it*

[2023] An objective and careful documentation of injuries can provide useful information regarding?::Evaluation of alleged circumstances of the incident

[2023] Features of a stab wound that must be described include which of the ff?
A. Diameter if it is gaping
B. Exact depth of penetration
C. Whether there are blunt and/or sharp ends
D. AOTA
?
C. Whether there are blunt and/or sharp ends
*Gaping wound edges must be pushed together. Depth cannot be measured as it is dynamic.*

[2023] Common Location of Defense Wounds::Forearms (also includes palms and wrists)

[2023] Self-inflicted intentional incised wounds of the wrist are?::Multiple and superficial ("hesitation marks" that do not necessarily aim to kill and aims for the radial artery)

[2023] The trajectory of the bullet wound indicates?::Bullet direction in reference anatomic position (standing fully erect with arms extended at the sides and palms forward)

[2023] If a scalp wound shows intact hair follicles, crushed margins, and intact tissue strands across the wound, it must be?::A **laceration**

[2023] Best method to document fine details of injuries on the body is through?::Photographs

[2023] Death from hanging by ligature is due to?::Cerebral hypoxia from vascular compression

[2023] Of the following forms of asphyxia, in which case are facial congestion and conjunctival hemorrhages least likely found?
A. Plastic bag over head
B. Hanging by ligature
C. Ligature strangulation
D. Manual strangulation
?
A. Plastic bag over head
*Traumatic asphyxia involves large compressive force on the chest + deep inspiration against closed glottis*


## Personal Questions
Pitfalls with regards to Death with Trauma
?
- Injuries can occur on top of natural disease
- Injuries can cause natural disease complications
- Death is unrelated to the traumatic injuries

The **location** of injuries helps determine the ==victim's response==

The **distribution** of injuries determine the ==deliberateness of the cause==

The **position** of injuries shows the ==position of the assailant==

Factors determining the severity, extent, and appearance of injuries
?
- Time over which force is delivered
- Regions or site involved
- Extent of body surface
- Weapon
- Magnitude of force

Important Features of Injury
?
- Nature
- Location
- Size 
- Shape
- Color
- Number
- Other Features

For abrasions, the ==pattern== can help identify the weapon

**Contusions** present as ==discoloration and bulging==

Umbrella term for contusion, hematoma, and ecchymosis::Hemorrhage

Differentiate contusion, hematoma, and ecchymosis
?
- Contusion is from **direct blunt trauma**
- Hematoma is the **unnatural blood-filling of a space that is not pre-existing**
- Ecchymosis refers to blood that **seeps in the tissue and is not from direct trauma**

Factors affecting the appearance of Contusions
?
- Age
- Sex and muscularity
- Racial color
- Underlying disease and medication
- Tissue vascularity or laxity
- Underlying bone
- Intensity of force
- Depth of involvement
- Interval from time of injury

Usual location for lacerations::Where there is bone underneath e.g., eyebrows and shin

Differentiate stab and incised wounds
?
- Stab wounds: depth > length
- Incised wounds: length > depth

In **incised wounds**, the ==follicles, blood vessels, and nerves== are cleanly cut

Typical pattern of hacking wounds (from heavy thick blades)
?
Deep wounds accompanied by bone fractures and abrasions at the sides

GSW with exit marks are ==penetrating== while those that exit are ==perforating==

Complete Description of GSW
?
- Entry and exit wounds
- Wound track
- Trajectory
- Range of fire
- Recovery of bullet 

GSW descriptions based on distance
?
- Close range has ring of soot
- Intermediate range has stippling around the wound
- Distant range has neither a ring of soot or stippling
- All have abrasion collars

Gases the propel bullet projectiles produce ==stellate lacerations== around the wound

Distinct feature of shotgun wounds
?
- Shotguns have no rifling (smooth bore)
- Shotgun pellets are small and multiple


# [[04 Red Flags of Child Abuse]]
[2023, 2024] What has high predictive value on child being physically abused?
A. Infant with TBI after vehicular accident
B. Infant with TBI with acute Gastroenteritis
C. Infant with TBI with no history of major trauma
D. Infant with TBI and a femoral fracture
E. NOTA
?
C. Infant with TBI with no history of major trauma

[2023, 2024] The ff. is a sentinel injury for child mistreatment
A. Child >3 y/o who sustained burn from any cause
B. History of bruising to forehead
C. Oral injury in pre-cruising infant
D. 3 y/o with clavicular fracture
E. 5 y/o with distant humeral fracture
?
C. Oral injury in pre-cruising infant
*Bruising and any other mild injuries on pre-cruising infant should heighten levels of suspicion*

[2023, 2024] A skeletal survey should be done in which of the ff. cases?
A. 10 y/o with bruises on face
B. 7 y/o with bruises on face
C. 2 y/o with stocking-pattern burn on right hand
D. 12 y/o with spiral fracture on femur
E. 5 y/o with clavicular fracture
?
C. 2 y/o with stocking-pattern burn on right hand
*Glove distribution burn indicates that the hand was dipped in hot fluids* 

[2023, 2024] When taking history of possible child abuse case, the physician must?
A. Warn patient that anything he says might be taken against him
B. Tell parents that they will be reported to DSWD
C. Interview both parents together for support
D. Do not offer potential explanations
E. As much as possible, interview the child with parents present
?
D. Do not offer potential explanations

[2023, 2024] What is the role of the physician in child abuse cases?
A. Recognize suspicious injuries
B. Document findings clearly
C. Report suspected abuse
D. Testify in court
E. AOTA
?
E. AOTA

[2023, 2024] What serves as the trigger for most of the perpetrators of infants with inflicted TBI?::Inconsolable infant crying

[2020, 2023, 2024] What is the most common cause of mortality and morbidity due to child physical abuse?::Head injuries

[2023, 2024] 2 month old infant is seen in ER for seizures. Child was apparently well the night before. Mother claims infant was crying for a long time late in the evening. Early in the morning, mother found baby pale and apneic. None of the family members know what happened. On PE, patient has generalized pallor and drowsiness. What radiologic work-up will you order?
?
CT Scan and Skeletal Survey
*CT is used to confirm presence of head injury and skeletal survey is mandatory as this is suspected child abuse*

[2023, 2024] 2 month old infant is seen in ER for seizures. Child was apparently well the night before. Mother claims infant was crying for a long time late in the evening. Early in the morning, mother found baby pale and apneic. None of the family members know what happened. On PE, patient has generalized pallor and drowsiness. Aside from radiologic work-up, what else should you do?
A. Send child home and ask to follow-up at OPD
B. Nothing else needs to be done except wait for the results
C. Tell parents you suspect you abused their child
D. Tell parents they will be reported to the DSWD
E. Refer to Child Protection Unit
?
E. Refer to Child Protection Unit

[2023, 2024] Who are mandatory reporters of child abuse?
?
- Physician
- Nurse
- Administrator

[2024] Official acceptor of child abuse reports in PH::Department of Social Welfare Office

## Personal Questions 
**Physical abuse** results from an act of commission which produces ==actual physical harm or holds potential for harm== which is reasonably within control of a parent or person in position of ==responsibility, power, or trust== 

RA 7610 orders the **mandatory** reporting by the ==head of medical institutions, the attending physician, or nurse== orally or in writing of suspected child abuse to the ==DSWD/LGU== within ==48 hours== of knowledge

Reasons why physicians fail to recognize child abuse
?
- Lack of knowledge of abuse-related medical findings
- Unusual or non-specific presenting complaint
- Physician accepts story of caretaker or refuses to believe that there is abuse
- Lack of certainty due to no formal training
- Fear of reprisal or going to court 

When should you suspect abusive head injury? 
?
- Child is <3 years old
- Serious head injuries
- No history of major trauma

Clinical Triad of Abusive Head Injury (Shaken Impact Syndrome)
?
- Encephalopathy
- Subdural Hemorrhage
- Retinal Hemorrhage

Most common statements about the abusive head injury during history taking
?
- No history of trauma (found the child that way)
- Baby fell a short distance (a fall < 4 ft does not cause serious damage)

4W's of History Taking related to falls
?
- When did it happen
- What distance was fallen
- What surface was landed on?
- When was the child last seen well?
- When did symptoms develop?

The symptoms of abusive head injuries vary depending on ==length and severity of shaking and the presence or absence of impact==

Clinical Presentation of Abusive Head Injuries
?
- Color changes
- Hypothermia
- Apnea or respiratory distress
- Lethargy or irritability
- Unresponsiveness
- Poor feeding and vomiting
- Seizures

Consequences of Abusive Head Injuries
?
- Early death 
- Learning disability or mental retardation
- Paralysis
- Neurobehavioral disorders
- Blindness
- Cerebral Palsy

Questions to determine if injury is from an accident, abuse, or neglect
?
- Developmentally possible?
- Organic cause?
- Explanation possible?
- Care appropriate?

Explanations that are concerning for intentional trauma
?
- No or vague explanation for significant injury
- Important detail of explanation changes dramatically
- Explanation inconsistent with pattern, age, or severity of injury or injuries
- Explanation inconsistent with child's physical and/or developmental capabilities
- Witnesses provide markedly different explanations for the injuries

Sentinel Injuries:::Injuries suspicious of physical abuse as they are poorly explained minor injuries (e.g., bruising)

**Bruises** are uncommon for infants who are ==less than 6 months old==

**Accidental bruises** are commonly found in the ==front and bony prominences (elbows, knees, shins, chins, forehead)==

TEN-4 Bruising Rule
?
- Torso
- Ear
- Neck
- Bruises in TEN on Child ≤4 years old or any location for child ≤4 months old

Earliest and most common manifestation of physical abuse::Bruises

Factors that contribute to vulnerability of young children to **internal injuries**
?
- Flared ribs
- Protuberant organs
- Thin abdominal walls and small sized **abdomen**
- Weaker **musculature and skeletal structures** compared to adults
- Less **protective fat** surrounding the pancreas and kidneys

Properties of **intentional scald burns**
?
- Clear upper margins
- No splash marks
- Uniform in thickness
- Distributed over the lower extremities, butt, and perineum
- Concurrent injuries incompatible with history

Location of fracture with highest specificity for abuse::Ribs

Fracture resulting from pulling and twisting of an extremity or any action involving rapid acceleration and deceleration::Classic metaphyseal fracture


# [[06 Medicolegal Issues in Toxicology]]
[2024] The field of toxicology that deals primarily with the **medico-legal aspects** of harmful effects of toxicants on man:::Forensic toxicology

[2023, 2024] If patient has altered consciousness without presence of any relatives, the health personnel can institute emergency procedures right away backing on?::Implied consent

[2023, 2024] The hospital can prevent a poisoned patient from leaving the hospital for the following reason(s)
?
- Delayed effect(s) of the toxicant
- High risk of suicide

[2023, 2024] A drug abuser cannot refuse specimen collection in the following conditions
?
- Incident to lawful arrest
- Based on belief that arrestee is intoxicated
- Done in reasonable, medically approved manner

[2024] A 30-year old male was brought to the ED for acute opioid toxicity, non-accidental. After antidotal administration, the patient woke up and he refused further treatment. The medico-legal issue involved in this case is?::Patient Autonomy

[2023, 2024] Privacy and confidentiality can be broken in case of an intoxicated patient for the following reason(s)
?
- Purposes of evaluation and treatment
- Consult with physicians to provide better care
- Activities related to public health

[2023, 2024] In case of minors, the following policy(ies) should be observed
A. Physician should respect the right of the minor if he/she refuses to disclose medical condition
B. Adult relative should be informed of a minor's medical condition
C. Hospital should allow minors to sign discharge against medical advice
D. Minor can invoke the principle of autonomy and privacy
?
B. Adult relative should be informed of a minor's medical condition

[2023, 2024] When interpreting a toxicology laboratory result, what should an expert witness take into consideration?
?
- Specimen dilution and adulteration (e.g., Time of Specimen Collection)
- Screening cutoff levels (Limits of Detection)
- Choice of biologic fluids
- Interpretation of tests

[2023, 2024] Expert opinion on establishment of long-term effects and disabilities from toxicant exposure is an example of this testimony::Prognosis

[2023] General contents of an informed consent
?
- Explanation of treatment or procedure
- Alternative choices to proposed intervention
- Relevant risks, benefits, and uncertainties associated with each alternative
- Likely outcomes of each treatment including no treatment

[2023] Basic requirement(s) for an expert witness
?
- Testimony should be composed of scientific, technical, or other specialized knowledge (establish reliability)
- Testimony should assist the fact finder (judge) in understanding the evidence in resolving a factual dispute in the case
- Witness must be qualified to render the opinion

[2023] Expert witness with regards to standards of care for treatment is required in the following case(s)
?
- Medication errors
- Non-adherence to standards of care

## Personal Questions
**Autonomy** refers to the right of a patient to ==retain control over their body== and that each individual has the right to ==choose a personal course of medical treatment==

When can consent from a close relative or guardian of the patient be considered?::Patient has a history of **abnormal behavior** from apparent deliberate overdose of drug or chemical intake

**Implied consent** applies in patients with ==altered consciousness and does not have a companion==

What is deemed proper specimen collection?
?
- Done in full view of the patient
- Laboratory should be informed that the specimen is likely to become evidence in court

When can one mandate drug screening?::Apprehending or arresting officer notes physical or outward manifestation of the suspect being under influence of drugs (RA 9165)

Cut-off blood alcohol levels for small vehicles::50 mg/dL (0.05%)

Cut-off blood alcohol levels for trucks and motor cycles::0%


# [[07 Musculoskeletal Trauma]]
[2024] At the ER, the initial management of the open wound would be the ff. except?
A. Oral antibiotics
B. Tetanus Prophylaxis
C. Irrigate the wound and dress
D. Splint right leg and apply ice compress
?
A. Oral antibiotics
*Should be IV antibiotics instead*

[2024] Once a patient with open fracture has been cleared of any life-threatening injuries and stabilized, your next management would include:
A. Continue oral antibiotics for 1 week
B. Suture the wound
C. Apply cast over right lower extremity
D. Bring patient to OR for debridement, irrigation, and external fixation of his right tibia
?
D. Bring patient to OR for debridement, irrigation, and external fixation of his right tibia

[2024] For multiply-injured patients such as this, one should watch out for which possible early complications?
?
- Infections
- Compartment Syndrome
- Fat Embolism Syndrome

[2024] A young lad fell from a tree and fractured his left ulna with note of **3cm of laceration at the ulnar aspect of the distal forearm and absent ulnar pulse**. According to the Gustillo Open Fracture Classification, this boy suffered which type of open ulnar fracture?::Type II (Wound is >1 cm and does not need arterial repair because the radial artery is still intact)

[2023, 2024] Most likely complication of untreated radius-ulnar fracture in adults::Post-traumatic arthritis of the wrist joint

[2023, 2024] Basis for the Gustillo Classification for Open Fractures::Soft Tissue Injury

[2024] During a badminton rally, a player lunged to reach the shuttlecock but suddenly felt a snap and sharp pain over the posterior aspect of his right heel. What is the most likely injured structure?
?
Achilles Tendon
*Tendon rupture occurs with sudden forces exerted upon the tendon from strenuous physical activities*

[2023, 2024] Earliest sign of impending compartment syndrome::Pain (pronounced, persistent, and out of proportion that is not relieved by analgesics)

[2024] A drug addict was running away from the police and jumped from a second-floor window down to the street, landing on both his feet. He sustained fractures of both of his calcaneus. Which fracture configuration or pattern would you expect in this type of injury?
?
Multi-fragmented fracture
*Rearfoot fractures of the heel bones typically result from excessive forces and the most common type are multiple fragmented fractures (crushed heel injury)*

[2023, 2024] An old lady slipped and fell on her right arm, sustaining a humeral shaft fracture. She also presented with a **right wrist drop**. Which structure may also have been injured?::Radial Nerve *(damage to the radial nerve results in weakness of wrist extensors hence the wrist drop)*

[2024] In a hurry to submit his report, a med student missed a step and **forcefully inverted his left foot**. There was sudden pain and swelling over the dorsolateral aspect of his left midfoot. Which possible injury did the med student sustain?::5th Metatarsal Base Fracture

[2024] Parts of First Aid Treatment for MSK injuries
?
- Compress
- Rest
- Ice
- Medication
- Elevate
- Support or splint

[2024] An 8-year-old boy sustained a fracture through his right proximal tibial physis (growth plate) however, he did not seek medical consult. Which complication is LEAST likely to happen to this patient’s right tibia?
A. Malunion
B. Non-union
C. Growth retardation
D. Growth acceleration
?
B. Non-union
*Growth plate fractures cause limb-length discrepancy or malunion*

[2024] A sprinter suddenly felt a snap and sudden pain on the back of his left thigh during a 100 -meter race. Which type of injury did he sustain?
A. Quadriceps tendon tear
B. Patellar tendon tear
C. Biceps femoris tear
D. Adductor magnus tear
?
C. Biceps femoris tear
*The biceps femoris is the only one located at the posterior thigh*

[2024] Which fracture types are NEVER seen in an adult?
?
- Plastic deformation
- Greenstick fractures
- Torus fractures

[2023, 2024] Purposes of Splinting
?
- Prevent further injury
- Easier transport
- Pain control
- Decrease risk for fat embolism

[2023, 2024] In geriatric patients with femoral neck fractures, ideal treatment would be?::Hip Replacement Surgery

[2024] Inability to do the “OK” sign with their thumb and fingers, may indicate injury to which structure?::Median Nerve *(Hand of Benediction Sign)* [Anterior Interosseous Nerve is more correct]

[2023, 2024] Eccentric contraction of the quadriceps femoris muscle produces which fracture configuration on the patella?::Transverse fracture *(only fracture brought about by eccentric muscle contraction)*

[2023] A middle-aged laborer was rescued from an earthquake rubble with his **right leg pinned** between a collapsed wall and the ground. He sustained an **open fracture of his mid-tibia and fibula**. Which fracture configuration would you expect in this type of injury?
?
Multi-fragmented fracture
*Compression usually results in comminuted or multi-fragmented fractures*

[2023] An “akyat-bahay” member sustained a deep laceration over his right wrist when he smashed his fist against a window pane. At the ER, he also presented with inability to oppose his right thumb against the other fingers on his right hand. Which structure may have been injured?
?
Median Nerve
*The median nerve is involved in thumb opposition*

[2023] Which statement is FALSE with regards Fracture Healing?
A. The right amount of micromotion produces callus
B. Primary or osteonal bone healing produces callus
C. Vascularity of the fractured bone is of prime importance in healing
D. Internal fixation devices may not necessarily hasten bone healing
?
B. Primary or osteonal bone healing produces callus
*Primary bone healing does not produce calluses*

[2023] What are late complications of untreated fractures?
?
- Infections
- Non-union
- Malunion
- Post-traumatic arthritis

[2023] Using the Gustillo classification of open fractures, a femoral fracture with a 2 x 3 cm wound over the mid-thigh and no exposed bone would be graded as?::Gustillo open type II (Wound is 1-10 cm)

[2023] A weekend warrior playing basketball sustained an inversion injury of his left ankle. There was note of swelling and tenderness over the anterolateral aspect of his left ankle, however, he was still able to bear weight on the affected foot. Which structure may have been injured?::Anterior Talofibular Ligament *(can also involve the calcaneofibular ligament)*


## Personal Questions
Sprains:::Injuries affecting the ligaments or other soft tissues of the joint from exceeding its normal ROM
Strains:::Injuries from excessive loading of muscles and tendons

**Strain** can be from the ==eccentric== contraction of the muscles that leads to tearing

Contusions:::Bruising or injury from direct blows to the muscles, subcutaneous tissues, or bones causing blood to leak from ruptured vessels

Lacerations:::Deep tears in the skin that are linear or curvilinear and usually narrow in width

Abrasions:::Superficial damage (not deeper than epidermis) with irregular or jagged edges on the skin with very little to no bleeding

Avulsions:::Big wounds where the skin is partially or fully torn away and may go as far as muscle and bone and is associated with a lot of bleeding

Process of returning dislocated bones that is done as soon as possible::Reduction

Partial dislocation of joint such that it can be returned due without formal reduction (primary injures the **ligaments**)::Subluxation

What is a fracture?::Soft tissue injury with associated break in the cortex of bone

Signs and Symptoms of Fractures
?
- Pain (first and instantaneous)
- Tenderness
- Swelling 
- Deformity
- Loss of function
- Crepitus

Very important points that must be elicited in history taking for fractures
?
- Mechanism of injury
- Date, time, and place of injury

In an open fracture, the **golden period** for irrigation and debridement is within ==8 hours== of the injury to lessen risk for infection

Open fractures that are automatically classified as IIIC
?
- Farm injuries (high infection risk)
- Mass casualties 
- High velocity GSW (large wounds affecting multiple tracts)

Metaphyseal fracture::fracture at the area between the epiphysis and diaphysis
Diaphyseal fracture::fracture along the bone shaft
Intra-articular fracture::fracture involving the bone surface that might lead to arthritis

Greenstick fracture::One side of the cortex breaks while the other bends

Torus fracture::Fracture in the metaphyses where there is localized expansion or widening of the bone cortex
Cause of torus fracture::Comrpession from axial loading force

Plastic deformation::Irreversible bending of bone when forces exceed the **elastic limit** of the bone
Management for plastic deformation::Cast immobilization if not severe and break and reconnect if severe

Fracture configuration where there are middle fragments in between proximal and distal fragments that **exhibit cortical contact**::Butterfly fracture

Fracture configuration where the middle fragments have no cortical contact with the proximal and distal fragments::Comminuted fractures

Fracture perpendicular to the long axis of the bone::Transverse fracture
Forces that cause transverse fractures
?
- Tension
- Shearing
- Pure Bending

Forces that cause oblique fractures
?
- Shearing
- Uneven bending

Fracture brought about by twisting forces along the long axis of the bone::Spiral Fractures

Initial Orthopedic Management for Extremity Injuries
?
- Splint or traction (immobilization)
- Dress wound (irrigate and cover)
- Anti-tetanus prophylaxis and IV antibiotics esp. for open fractures

 Early Total Care Approach
 ?
 - Early orthopedic fixation
 - Injuries treated all at once including definitive management
 - Done within 48 hours

Complications from Early Total Care Approach
?
- GCS reduction (in head trauma)
- ARDS (in chest trauma)
- Multiple organ failure

Damage Control Surgery Approach
?
- Approach typically done for unstable patients 
- Do early fracture stabilization with temporary bridging external fixation
- Definite fixation around the 4th to 5th day of injury

Indications for definitive fixation in damage control surgery approach
?
- Stable BP without pressors
- Corrected coagulopathy without blood products
- Normal urine output

IV antiobiotics and tetanus prophylaxis must be given within ==3 hours== of the open fracture to control infection

Antibiotics recommended for type I and II open fractures::First generation cephalosporin + additional antibiotics like gentamicin if late
Antibiotics recommended for type III open fracture with contamination::Aminoglycosides for anaerobic and gram negative coverage + other antibiotics 

Irrigation for open fractures is done with ==sterile saline== and must be done within ==the first 6-8 hours== to avoid infections

Fracture fixation for open fractures is done ==2 days after operation==

**Bone grafting** in open fractures is done ==6 weeks== after the wound is closed

Preferred traction when only a light or discontinuous force is needed::Skin traction

Skeletal traction::Traction that provides more force than skin traction involving placing tongs, pins, or screws to directly apply to the bone

Indications for External Fixation
?
- Open wound fractures
- Cannot afford internal fixation

Stages of Callus Bone Healing
?
1. Hematoma formation
2. Callus formation (bridging callus)
3. Remodeling (does not really happen for adults)

6Ps of Compartment Syndrome
?
- Pain
- Paresthesia
- Pallor
- Pulselessness
- Paralysis
- Poikilothermia

Management for Compartment Syndrome::Fasciotomy (longitudinal incision over the fascia to release pressure from the muscle)

Signs and Symptoms of Fat Embolism Syndrome
?
- Sudden onset dyspnea
- Sensorial changes
- Petechiae

Risk Factors for Fat Embolism Syndrome
?
- Long bone fracture
- Multiple fracture
- Pulmonary contusion

Management of Fat Embolism Syndrome::Supportive management with intubation or steroids

Prevention of Fat Embolism Syndrome::Immobilize and stabilize fractures early

# [[08 Triage]]
[2024] 35 y/o Grab driver lost control of his motorcycle and slammed onto a lamp post. He lost consciousness for a few minutes. He was noted to have a large open wound with gravel over his right anterior leg with an obvious deformity. At the scene of the accident, the paramedic should perform the ff. except?
A. Resuscitate patient if warranted
B. Look for bystanders who witnesses the crash to get the details of the accident
C. Immobilize head, neck, spine, and extremities of patient
D. Transport patient to nearest ER
?
B. Look for bystanders who witnesses the crash to get the details of the accident

[2024] Components of Simple Triage and Treatment
?
- Respiration (30 seconds)
- Perfusion (2 seconds)
- Mental Status (follow commands)

[2024] A healthy 25-year-old male with a forehead laceration needs to undergo suturing and CT scan. What is the Emergency Severity Index level of this patient?::ESI 3 because patient is not in need of life-saving intervention and is not in a high risk situation

## Personal Questions

What are the components of assessment in triage?
?
- Vital signs and condition (physiology)
- Likely medical **needs** (life, limb, or aesthetics)
- Prognosis 
- On-site medical care resources
- Prioritize management of casualties
- Coding of casualties

On-field triaging involves determining who will ==be brought to the hospital first==
Emergency department triaging involves determining who will ==go into the operating room first==

Triage color for deceased or those with no respiration after clearing the airway and are usually the last priority:::Black Tag
Triage color for those who need immediate attention (Poor RPM):::Red Tag
Triage color for those who can delay their care but still needs attention:::Yellow Tag
Triage color for those with minor injuries often referred to as "walking wounded":::Green Tag

Secondary Assessment of Victim Endpoint (SAVE)::Triage to provide care for those in field who are most likely to benefit from intervention

Triaging where those less wounded are given preference used to bring out those who are severely wounded or those in war::Reverse Triage

**Re-triage** in the ER is important for those with ==unclear diagnosis or those under influence of substances==

Pitfalls in ER triaging
?
- Failure to recognize conditions
- Failure to acknowledge high-risk chief complaints
- Failure to observe vital signs
- Failure to document triage observations
- Failure to re-triage

ESI Levels
?
1. Needs immediate life-saving
2. High risk (disoriented, severe pain, danger zone vitals)
3. Multiple resources needed to stabilize
4. One resource needed to stabilize
5. No need for resources to stabilize

# [[10 Chest Injuries]]
[2023, 2024] During your tour of duty at the emergency room, you receive a referral for a 36 male who is suffering from hacking injuries. During your inspection you noted two deep hacking injuries on the distal and mid ventral aspect of the right forearm with profuse bleeding. How will you perform initial control of the hemorrhage?::Apply direct pressure on the wound

[2024] The Surgeon on Duty at the Emergency room calls you in to help an Emergency Department Thoracotomy (EDT) on a 22 year old male who just had cardiac arrest. The following are your possible indications in performing an EDT EXCEPT:
A. Witnessed arrest on a patient with penetrating chest injury
B. Witnessed arrest on a patient with cute pericardial tamponade
C. Witnessed arrest on a patient with exsanguinating intrathoracic hemorrhage
D. Witnessed arrest on a patient with tension pneumothorax
?
A. Witnessed arrest on a patient with penetrating chest injury

[2024] At the ER, your team received a 29 F who was involved in a vehicular crash wherein she noted hitting her chest really hard on the handle bar when her motorbike went into an abrupt stop. The patient was hypotensive, tachycardic and tachypneic. She has engorged neck veins and decreased breath sounds on the right chest. What would be your next best course of management on this patient?::Introduce a 14-gauge needle on the 5th ICS AAL

[2023, 2024] Which of the ff. findings when present indicate tension pneumothorax?
A. Decreased breath sounds
B. Grossly obvious bilaterally distended neck veins
C. Hypotension
D. O2 Sat 85% even with oxygen support
?
C. Hypotension
*Air in the chest cavity compresses the heart causing reduced venous return manifesting with hypotension and hypoxia*

[2024] You received a referral at the emergency room for a case of tension pneumothorax, this is an emergency condition brought about by?::Mediastinal shift causing impaired venous return to the right atrium

[2024] The ff. are indications to perform an urgent thoracotomy except?
A. Chest tube draining 200 mL/hr of sanguineous fluid for the past 2 hrs
B. Chest wall defect with ventilatory compromise
C. Massive air leak with incomplete lung expansion
Great vessel injury with hemodynamic instability
?
B. Chest wall defect with ventilatory compromise

[2024] Arriving at your ER post you immediately receive a trauma referral. The patient 35 M vehicular crash patient who was transferred from a nearby secondary hospital wherein the patient was diagnosed with acute tamponade. You did your primary and secondary survey on the patient and noted that the patient was hypotensive and tachycardic. He also had distant heart sounds. He would open his eyes to pain, would grunt to painful stimulus and then push your hand away. CBG were normal. What is the most appropriate next step in managing this patient?
A. Perform stat pericardiocentesis
B. Perform endotracheal intubation
C. Bring the patient stat to the OR for subxiphoid tube pericardiostomy
D. Secure and do FAST to confirm pericardial effusion
?
C. Bring the patient stat to the OR for subxiphoid tube pericardiostomy

[2023, 2024] At the ER, you received a trauma patient transferred from a nearby hospital wherein he was found to have moderate pericardial effusion. Which among the following clinical findings would indicate that your patient is in tamponade physiology?
A. Engorged neck veins
B. Hypotension
C. Water hummer pulse
D. Absent heart sounds
?
B. Hypotension
*Beck's triad is hypotension, JV distention, and muffled heart sounds*

[2024] There are several purposes in doing an Emergency Department Thoracotomy (EDT), one of which is to cross-clamp the descending thoracic aorta to redistribute blood flow and limit sub-diaphragmatic hemorrhage. In order to gain access to the descending aorta, how would you best approach this patient?::Perform a thoracotomy on the left

[2023, 2024] Gold standard for imaging traumatic aortic injuries::CT Angiogram

[2023, 2024] Tension pneumothorax results to hypotension by ultimately compromising::Circulation

[2024] Recommended site for needling in thoracocentesis (ATLS 10th ed.)::5th ICS AAL

[2023] Upper limit of normal or widened mediastinum on CXR::8 cm

[2023] The sternal angle is an important landmark for what structure?
A. Left ventricle
B. Inferior vena cava
C. Aortic Arch
D. Right Ventricle
?
C. Aortic Arch

[2023] Initial management for subcutaneous emphysema in a normotensive but dyspneic trauma patient::Tube Thoracostomy

[2023] Aortic tear in acceleration deceleration injuries usually occur at what anatomic area?::Ligamentum arteriosum

[2023] Movement in flail chest is paradoxical because of?::Negative intrathoracic pressure

## Personal Questions
Structures adjacent to the Sternal Angle of Louie
?
- Aortic arch
- Tracheal bifurcation
- T4-T5
- Main Pulmonary Artery Bifurcation
- Transition of Azygos v. to SVC

Pre-hospital Advanced Life Support Assessment
?
- Shout (call for help)
- Assess scene and mechanism of injury
- Free from danger?
- Evacuate casualty

For surgical emergency services, what is the priority in initial assessment?::Controlling hemorrhage via application of direct pressure at the bleeding site and not pulling out penetrating objects

What is considered significant hemorrhage?
?
- 7% for adults
- 8-9% for children
- 9-10% for infants
- 15-30% for pathologic blood loss

Intubation method of choice for those with facial trauma::Cricothyroidotomy

Management for patients unresponsive upon primary survey of airway::Protect C-spine and perform jaw thrust or chin lift maneuver to secure the airway

Primary management of flail chest with pulmonary contusion::Ventilation and analgesics

Clinical Findings for Tension Pneumothorax
?
- Hypotension
- Contralateral displacement of trachea
- Decreased breath sounds 
- Chest lag

Why should one oxygenate in open pneumothorax?::Supplementation helps wash out inert nitrogen in the tissue

Clinical presentation of hemothorax::Pallor and hypotension

Management of hemothorax
?
- Insert large bore f32 chest tube
- Thoracotomy if blood loss >1 L or >100 mL for 3 hours

Management for pulmonary contusion::Pain relievers and Physiotherapy

Pulmonary Contusion:::Lung injury leaking blood and plasma into the alveoli from trauma
Myocardial contusion::Direct injury affecting the myocardium, coronary vessels, or cardiac valves
Diagnostics for myocardial contusions::ECG, troponin I, and 2D echo
Management for aortic disruption::Endovascular repair
Why is a right diaphragmatic rupture more fatal than left-sided ones?::The right involves the liver

Management for diaphragmatic rupture
?
- Abdominal approach open repair for acute cases
- Thoracic approach for chronic cases to avoid abdominal adhesion

Weakest portion of the diaphragm::Posterolateral aspect
Radiologic sign found in tracheobronchial disruption::Fallen Lung Sign
Best modality for diagnosis of esophageal disruption::Contrast study of the esophagus
Condition where air from the chest cavity travels subcutaneously resulting in a popcorn-like appearance of skin:::Subcutaneous emphysema

Most common cause of death in the first 24 hours of trauma patients in PGH::Exsanguination or Hypotension
Most common cause of death in beyond 24 hours for trauma patients of PGH::Multiple organ failure or sepsis
Most common mechanism of injury that cause traumatic death::Penetrating injuries 

# [[11 Traumatic Brain Injury]]
[2023, 2024] Type of injury that can still be modified to improve outcomes of TBI::Second or secondary injury

[2023, 2024] Most likely type of force loading leading to diffuse axonal injury::Impulsive loading

[2023, 2024] Recommended head of bed elevation for recumbent TBI patients::30-45º

[2023, 2024] Mild form of diffuse axonal injury::Concussion

[2023, 2024] What is the GCS of a patient who presents at the ER who can only mumble questions, opens eyes when prodded, and extends his right arm to pain while briskly localizing on the left?
?
$$GCS=E+V+M=3+2+5$$
- Opens eyes to voice: E = 3
- Mumbling: V = 2 2   2 2 1 2 2 2 2 1 2 1 2 1 2 2 2 
- Localizes: M = 5

[2023, 2024] Diagnostic imaging of choice for TBI::Plain Cranial CT Scan

[2023, 2024] Indirect measure to assess cerebral blood flow::Cerebral Perfusion Pressure

[2023, 2024] High Risk Factors for TBI
?
- Young
- Single
- Men
- Low Income
- Ethnic minority
- Inner city residents
- Substance Abuse
- Previous TBI
