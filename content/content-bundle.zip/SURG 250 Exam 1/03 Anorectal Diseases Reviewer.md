---
banner_icon: 📝
tags: flashcards, SURG250
type: Exam
date: 2022-11-22
---
[Blocks 1, 2, 3, and 4] A complex anal fistula is any of the ff. except?
A. Fistula involving significant portion of EAS
B. Fistula noted after previous incision and drainage for abscess
C. Fistula with three external openings
D. Anteriorly located fistula in females
?
B. Fistula noted after previous incision and drainage for abscess
*B is a simple [[Fistula-in-Ano]] as it usually develops from abscesses. A, C, and D are all complex [[Anal Fistula]]*

[Blocks 1, 4, and 5] Diabetic seen at GS2 OPD found to have **abscess in the posterior midline extending into both ischiorectal fossa**. He is **in pain and had fever** the previous night. What is the most appropriate management for this patient?
?
Admit the patient for drainage in the OR
*Admission and surgical drainage is the mainstay for any abscess*

[Blocks 1 and 4] 37/M presents with **1 week history of anal pain**. Pain came **suddenly** and kept him from going to work for 2 days but lessened since. He has **no bleeding**. On examination, he has a **2 cm dark purple bulge at the left lateral aspect of the anus** that is tender and appears to have **blood clots** underneath the anoderm. The rest of the anus is normal. What is the most appropriate next step for treatment?
? 
Prescribe flavonoid (Diosmin-Hesperidin) tablets for 1 week, oral and topical analgesics, and warm sitz bath
*Considering the blood clots found, it is a thrombosed hemorrhoid. A hemorrhoidectomy is only recommended if it is caught within 3 days of the onset of anal pain or prolapse. As the patient is already presenting with a 1 week history of anal pain and there is noted improvement of symptoms, conservative management is the main consideration*

[Blocks 1 and 4] 26/M presenting with **2-day history of perianal pain** that is **worse with defecation and small bump near anus**. No bleeding. What is the most likely diagnosis?
?
[[Perianal Abscess]]
*The anal pain accompanied with a small bump near the anus makes a perianal abscess as the most likely diagnosis. An anal fissure would have sentinel piles, deep fissure or tear, and hypertrophied anal papilla*

[Blocks 3 and 6] 23/M sexually active has **perianal pruritus** and a **large, cauliflower appearing mass** near the anal verge. Which of the ff. is true regarding the diagnostic approach to this patient?
?
A. Full colonoscopy is warranted
B. STD and HIV testing is not necessary at this point. Surgery is indicated. 
C. Condyloma lata and condyloma acuminatum are on the same disease spectrum
D. Anoscopy should be performed as the disease can be located within the anorectal region
?
D. Anoscopy should be performed as the disease can be located within the anorectal region
*A clue to this question would be sexual activity along with the cauliflower mass most likely indicating [[Anal Warts]]. There are found in patients with [[HIV]] and must be referred to infectious diseases for screening and offer excision or cauterization of the mass.*

[Blocks 5 and 6] 28/M with [[HIV]] consults for [[Anal Warts]]. On examination you see multiple warts, 1-1.5 cm in largest diameter on the perianal area and smaller lesions around the anal canal. You will advise the following except?
A. Screening for STDs is recommended
B. Excision with cauterization should be the best option to clear the virus
C. Topical treatment with Imiquimoid will clear the lesions
D. Vaccination with HPV quadrivalent vaccine will protect against HPV strains
?
C. Topical treatment with Imiquimoid will clear the lesions
*[[Anal Warts]] in HIV patients are managed through referral to infectious diseases for screening (Choice A is correct) and cauterization for smaller lesions (B is correct). As [[Condyloma acuminatum]] is also caused by [[HPV]], vaccination should be advised (C is correct).*

[Blocks 5 and 6] 36/M presenting to GS2 OPD after noticing **blood spots on toilet paper and bowl after 1 week**. Yesterday, he noticed a **gush of blood after defecation** which caused him to worry. He has a **chronic constipation but denies pain, itching, swelling** in the anal region. He also **denies family history of [[Colorectal Cancer]]**. On anoscopy, you notice **grade 2 internal [[Hemorrhoids]]** with evidence of recent bleeding. What would you recommend to this patient?
?
[[Rubber Band Ligation]]
*RBL is done for Grade II hemorrhoids that are bleeding. If not bleeding, conservative management and medical management are options*

[Blocks 1, 2, 3, 4, and 6] 33/M complaining of **recurrent perianal discharge for 1 year**. On examination, there is a **nodular, granulating lesion** at the left perianal area located 5 cm away from the anus. On DRE, there seems to be a **palpable induration at the posterior midline** about 2 cm from the anal verge. What will be the most appropriate advise to him?
![[03 Anorectal Diseases-1669102735190.jpeg]]
?
He needs **surgery** for definitive management
*The recurrent perianal discharge might be interpreted as a [[Perianal Abscess]] which is a precursor for the development of [[Fistula-in-Ano]]. In addition, the palpable induration felt on DRE might be the internal opening for this fistula. There is no conservative management for fistulas and is only handled through surgery to cure it and to prevent progression to complex disease*

[Blocks 1, 2, and 4] 29/M complaining of **recurrent perianal discharge**. On examination, there is **nodular, granulating lesions** at the left anterior anal area located **4 cm away from the anal verge**. There is **no palpable tract.** On DRE, mucosa is **smooth with no other remarkable findings**. What is the next best step in management?
?
[[Endoanal Ultrasound]]
*Ultrasound for [[Fistula-in-Ano]] can help located the internal opening to determine the appropriate management for the patient*

[Blocks 3, 5, and 6] Which of the ff. patients would be best managed with [[Fistulotomy]]?
A. 35/M woman with disseminated TB and **recurrent transsphincteric fistula with multiple tracts**
B. 18/M undergoing treatment for leukemia with newly diagnosed **horseshoe-type fistula**
C. 23/F with left ischiorectal abscess seen on MRI with **suspecting internal opening at 3 cm from the anal verge** 
D. 38/M with **palpable fistula tract on perianal skin, internal opening below dentate line, and external opening 1 cm away from the anal verge on the right**
?
D. 38/M with **palpable fistula tract on perianal skin, internal opening below dentate line, and external opening 1 cm away from the anal verge on the right**
*A, B, and C are all complex [[Fistula-in-Ano]]. [[Fistulotomy]] is indicated for simple [[Fistula-in-Ano]], most distal fistulas, low intersphincteric fistulas, and low transsphincteric fistulas*

[Blocks 5 and 6] Best diagnostic examination for complex anal fistula
?
Pelvic MRI
*Pelvic MRI is preferred over [[Anoscopy]], [[Proctosigmoidoscopy]], and [[Endoanal Ultrasound]] as it provides soft tissue visualization of the [[Fistula-in-Ano]] and is the ideal investigation for fistula-in-ano*

[Blocks 1 and 4] 40/M with **sudden onset of pain and swelling in perianal region** since last night. He **denies experiencing fever, chills, or trauma**. On anal examination, you notice a **small, dark-colored perianal swelling** in the R anterior location. Swelling is **very tender and tense to touch**. No pus or discharge or bleeding noticed. What treatment should be recommended for this patient?
?
Excision of external hermorrhoid in the OR
*Acute thrombosed [[Hemorrhoids]] present with sudden acute pain and small, dark colored perianal swelling on PE. Considering that it is within 72 hours of the onset of pain, [[Hemorrhoidectomy]] is the mainstay intervention to immediately reduce pain score.*

[Blocks 3, 4, and 6] 55/M with history of [[Hemorrhoids]] presents with **bright red bleeding after bowel movements**. He also notices **prolapse** of the hemorrhoids which can be **reduced manually.** The patient takes **regular fiber supplements and underwent banding of hemorrhoids twice last year**. What treatment should you recommend?
?
[[Excisional Hemorrhoidectomy]]
*The patient has a Grade 3 internal hemorrhoid. Conservative option and rubber band ligation has already been performed thus, the next step would be to provide surgical options such as [[Excisional Hemorrhoidectomy]] or THD/HAL-RAR*

[Blocks 4 and 5] 36/F has **prolapsing rectal tissue and blood** seen both in the toilet **following forceful defecation** and on toilet paper. On examination, she has **2 main piles of vascular lesions** that are **reducible with direct pressure** and are **non-tender**. If she is most worried about the **bleeding episodes**, what will be the most appropriate recommendation?
?
[[Rubber Band Ligation]]
*RBL deals with bleeding from [[Hemorrhoids]]*

[Blocks 3 and 4] 25/M consults for **anal pain** that has been present for **2 weeks** and is found to have an [[Anal Fissure]]. He has never experienced similar symptoms. What is the recommended treatment option for the patient?
?
Fiber supplements and sitz baths
*The patient has an acute anal fissure (<6 weeks) and therefore must be managed conservatively through diet modification, avoidance of straining, topical medications, analgesics, warm sitz btahs, and proper positioning on bowel movements*

[Blocks 3 and 6] You are evaluating a 44/M in the GS2 OPD. Anal exam shows **classic Brodie's triad**. He was being **managed conservatively** through fiber supplements and topical ointments but has had minimal relief of symptoms. What is the next best step for management?
A. Sitz bath
B. Laxative
C. Lateral internal sphincterotomy
D. Fissurectomy
?
C. Lateral internal sphincterotomy
*Brodie's triad means that it is a chronic anal fissure. Since the patient has already had conservative management, the other options would be medical therapy with glyceryl nitrate or topical nifedipine or surgery with [[Lateral Internal Sphincterotomy]] or botox injections*

[Blocks 1, 2, and 4] Which patient would be best managed with a lay-open fistulotomy?
A. A 33-year-old woman with Crohn disease and recurrent intersphincteric fistula with multiple tracts
B. A 19-year-old man with a suprasphincteric fistula
C. A 38-year-old woman with a low transsphincteric fistula involving 30% of the external anal sphincter
D. A 24-year-old man with a high transsphincteric fistula
?
C. A 38-year-old woman with a low transsphincteric fistula involving 30% of the external anal sphincter
*A, B, and D are complex fistula-in-ano and [[Fistulotomy]] cannot be used for their management*

[Block 1] A 71 y.o. patient has **chronic constipation with mild abdominal distension and nausea**. He can **still pass gas and has had soft to liquid bowel movement in the last 2 weeks**. He never had a colonoscopy before. At the time of exam, **abdomen is soft, with note of a movable mass on the left lower quadrant, without tenderness**. What is the next best step in management?
A. Request for a whole abdominal CT scan with triple contrast
B. Request for an abdominal ultrasound
C. Send the patient to the ER for urgent surgery
D. Restrict fiber intake and schedule for colonoscopy ASAP
?
D. Restrict fiber intake and schedule for colonoscopy ASAP
*[[Colonoscopy]] should be done to examine the large bowel mass and at the same time, screen for colorectal cancer as the patient is ≥50 years old.*

A 45-year-old mass presents to the GS2 clinic with a **large rectal mass that is found to be adenocarcinoma**. The mass is **partially obstructing** and a previous report showed the mass is **unable to be traversed with the colonoscope**. What is the most appropriate test to stage this patient’s disease?
A. Abdominal CT scan with triple contrast and chest CT scan
B. CEA
C. Stat CBC
D. Endorectal ultrasound
?
A. Abdominal CT scan with triple contrast and chest CT scan
*Abdominal and chest CT is done for CRC for clinical staging. CEA is not really for staging but for monitoring management. Stat CBC and Endorectal ultrasound are not part of the work-up for CRC clinical staging*

[Block 1] A 52-year-old woman has had **anal pain for 4 weeks**. The pain is constant but **worse with bowel movements**, and there is blood on the toilet paper with stools. On DRE, she has a 3 **mm tender groove at the posterior midline anal verge extending proximally that oozes slightly**. The best next step is?
A. Lateral internal sphincterotomy 
B. Colonoscopy
C. Botulinum toxin injection
D. Diet modification, pain relievers, and warm sitz bath
?
D. Diet modification, pain relievers, and warm sitz bath
*The patient presents with an acute [[Anal Fissure]] (<4 weeks) which is usually managed conservatively.*

[Block 1] A 65-year-old man is undergoing an elective colon resection. Which of the following measures will reduce this patient’s risk of developing a surgical site infection?
A. Raise the patient’s blood sugar to promote hyperglycemia
B. Shave the patient’s hair preoperatively
C. Use betadine skin preparation instead of chlorhexidine preparation in the OR
D. Initiate antibiotic prophylaxis
?
D. Initiate antibiotic prophylaxis
*Hyperglycemia will provide food for bacteria thus increasing risk. Removal of hair should be done with clippers to prevent creating nicks in skin where bacterial growth can happen. Chlorhexidine is better for preventing surgical site infection*

[Block 1 and 2] A 19-year-old man presents to the office with complaints of **anal itching and bumps**. He is otherwise healthy and has had heterosexual contacts only. On examination, there are **8 to 10 perianal condylomata on each side of the anus, all separated by areas of normal skin**. After failing topical therapy with Imiquimod, he asks about the next best step. What will you recommend?
A. Screening for sexually-transmitted diseases
B. HPV vaccine
C. Application of 90% trichloroacetic acid on the lesions
D. Excision of each individual lesion
?
D. Excision of each individual lesion
*The patient is unresponsive to conservative management thus, the next step for management should be surgical excision for [[Anal Warts]]*

[Block 1] A 38-year-old female consults you due to **hematochezia of 2 months duration**. There are no other signs and symptoms. Examination of the anus reveals no significant findings. What is the next step in management?
A. Treatment with oral medications, suppositories, and creams
B. Proceed with hemorrhoidectomy
C. Examination with either proctosigmoidoscopy or flexible sigmoidoscopy
D. Warm sitz bath and a high fiber diet
?
C. Examination with either proctosigmoidoscopy or flexible sigmoidoscopy
*[[Hematochezia]] is a red flag for [[Colorectal Cancer]] thus, there should be investigation on the source of the bleeding. *

[Block 1] Which of the following statements about hemorrhoids is NOT TRUE?
A. Infection is uncommon after hemorrhoidectomy
B. The three hemorrhoidal cushions are found in the right anterolateral, right posterolateral, and left lateral
C. External hemorrhoids are located distal to the dentate line and covered by anorectal mucosa
D. Third degree hemorrhoids are irreducible and are at risk of strangulation
?
B. The three hemorrhoidal cushions are found in the right anterolateral, right posterolateral, and left lateral
*The hemorrhoidal cushions are located in the right anterior, right posterior, and left lateral portions*

[Block 2] A 30-year-old male comes to the OPD for **severe anal pain which started 2 days ago**. He now presents with **fever and is unable to sit down**. On initial physical examination, he has stable vital signs, with note of an **erythematous and fluctuant lesion at the right lateral perianal area**, measuring 3 cm in diameter, and located 1 cm away from the anal opening. The most important aspect in the management is to send to the ER and do:
A. Hydration with plain LR solution
B. Administration of IV antibiotics
C. Give adequate pain relief
D. Incision and drainage
?
D. Incision and drainage
*Fever and an erythematous fluctuant lesion makes it likely that the patient is dealing with a [[Perianal Abscess]]. The management for abscesses is always incision and drainage*

[Block 2] A 42-year-old female consults at the OPD for a **prolapsing anal mass**. She says that in her younger years she would notice a **fleshy protrusion at the anus but would “go back inside on their own” after bowel movement**. Since having 3 children, she would sometimes notice the **mass persists even after defecation, but she would try to “push it back inside**”. This week she noticed it is larger than ever, but has no other symptoms. **When she tries to push it back, they only “slide out again”**. On inspection of the anal area, there are 3 prolapsing and engorged major piles. Which of the following is the diagnosis with acceptable treatment option?
A. Grade 4 hemorrhoids - excisional hemorrhoidectomy
B. Grade 3 hemorrhoids - rubber band ligation
C. Grade 3 hemorrhoids - stapled hemorrhoidopexy
D. Grade 4 hemorrhoids - medical management
?
A. Grade 4 hemorrhoids - excisional hemorrhoidectomy
*The internal hemorrhoids are no longer reducible. Grade IV hemorrhoids are best managed with surgery. Medical management is of little benefit at this point*

[Block 2] A 35 year old man presents to your office after noticing **blood spots on toilet paper and bowl**. He has **chronic constipation but denies any pain, itching, or swelling in the anal region**. He also **denies any family history of colorectal cancer**. On anoscopy, you notice **grade 1 internal hemorrhoids**. What would you recommend to this patient?
A. Rectal suppository (policresulen/ cinchocaine= Faktu)
B. Fiber supplements and an increased oral fluid intake
C. Colonoscopy
D. Excisional hemorrhoidectomy
?
B. Fiber supplements and an increased oral fluid intake
*Grade I internal hemorrhoids are managed conservatively. Colonoscopy is not indicated as the patient is young and has no family history for [[Colorectal Cancer]]. [[Excisional Hemorrhoidectomy]] is reserved for Grade III and IV internal hemorrhage. Rectal suppositories are of no use for internal [[Hemorrhoids]]* 

