---
banner_icon: 📝
tags: flashcards, SURG250
type: Exam
date: 2022-11-22
---
[Blocks 1 and 4] 24/F being evaluated for **abdominal pain and elevated biliary enzymes**. CT scan demonstrates **dilated common bile duct**. **[[Choledochal Cyst]]** is suspected. What test is preferred next?
?
[[Magnetic Resonance Cholangiopancreatography]]
*MR cholangiopancreatography avoids exposing patients to ionizing radiation and does not risk [[Cholangitis]] and [[Pancreatitis]] seen with [[Endoscopic Retrograde Cholangiopancreatography]]. This is the test of choice for diagnosing and evaluating biliary cysts.*

[Blocks 1 and 4] 42/M presents to SOD clinic with complaints of **abdominal pain**. He is alert and oriented with **temperature of 39.4ºC**, **mild tachycardia**, and BP 112/82. He came from a local hospital where lab results showed **total bilirubin level is 4 mg/dL** and **WBC count of 15,000/μL**. Ultrasound confirms **dilated common bile duct** to 9 mm but does not identify any common bile duct stones. Based on the information given, which of the ff. represents the next step in management?
A. Endorse to ER for fluid resuscitation, antibiotics, and possible ERCP
B. Endorse to ER for fluid resuscitation, antibiotics, and possible emergency cholecystectomy
C. Prescribe oral antibiotics for 1 week and advice follow-up ultrasound
D. Refer to GS3 clinic for elective consultation
?
A. Endorse to ER for fluid resuscitation, antibiotics, and possible ERCP
*Patient possibly has acute [[Cholangitis]] as he satisfies Charcot's triad of abdominal pain, fever, and jaundice (Bilirubin >35 μmol/L) which is an emergency. [[Endoscopic Retrograde Cholangiopancreatography]] is the first-line management along with [[Antibiotics]] and IVF resuscitation*

5 days after **mesh repair** of an [[Inguinal Hernia]], a patient presents with **scrotal enlargement** on the operative side. He is **afebrile** with **well-healed incision** but with **ecchymoses** from incision site to ipsilateral scrotum. There is **some fluctuant fluid**. Sensation is **intact** and testicle is **minimally tender** to palpation. Which of the ff. is the most appropriate management?
A. Open wound and evacuate hematoma
B. Initiate 7-day course of antibiotics
C. Reassurance
D. Needle aspiration of fluid
?
C. Reassurance
*Swelling post-operatively for hernias is normal and may worsen after a few days. This disappears after 3-4 weeks. Sometimes, this can represent a seroma (benign fluid collection) but this will mostly resolve on its own. There is no indication that the swelling is from bleeding or from infection*

[Blocks 4 and 6] Which of the ff. is correct regarding the diagnosis of a pancreatic pseudocyst?
A. Pancreatic pseudocysts contain fluid with low amylase concentration
B. Abdominal CT scan is the best diagnostic tool
C. Pancreatic pseudocysts are commonly diagnosed within 2 weeks after onset of pancreatitis
D. Fine needle aspiration should be used routinely in the diagnostic work-up
?
B. Abdominal CT scan is the best diagnostic tool
*A is wrong as pancreatic tissue is expected to have high [[Amylase]] concentration as pancreatic pseudocysts are collections of pancreatic enzyme-rich fluid. They usually form 3 weeks after an attack of [[Pancreatitis]] thus, C is wrong. [[CT Scan]] is the ideal and study of choice.*

[Blocks 3 and 6] 36/M presenting to the OPD with **RUQ abdominal pain and fever**. Vital signs include **T 38.7ºC, HR 115, BP 84/56**. PE reveals **lethargy, jaundice, and abdominal tenderness**. You immediately send the patient to the ER. In addition to fluid resuscitation and administration of broad-spectrum antibiotic coverage, the most appropriate next step in the evaluation of this patient is?
A. HIDA Scan
B. CT Scan
C. MRCP
D. RUQ Ultrasound
?
D. RUQ Ultrasound
*Ultrasound can confirm the diagnosis by showing gallstones and/or dilated CBD >8 mm suggesting biliary obstruction. Considering that the patient already has Reynold's Pentad, tests that require longer duration for interpretation increases the risk for mortality and morbidity for the patient*

[Blocks 4 and 6] An active 32/M presents with **right groin pain** that is **worse with straining at his job or with athletic activity**. He subjectively feels a **bulge in his groin**. You cannot clearly tell whether he has a hernia on PE. What imaging study would be appropriate to evaluate the patient further?
?
Ultrasound
*For most hernias, no specific investigation is needed. Plain abdominal X-ray is of little help for diagnosis. Ultrasound is helpful for **irreducible hernias** where there is differential of a mass or fluid collection, or when the hernia content is in doubt. Furthermore, [[Ultrasound]] is non-invasive and low cost. CT is used for incisional hernias and MRI is needed to detect occult hernias from orthopedic injuries seen in athletes*

[Blocks 3 and 6] 45/M undergoes **open right inguinal hernia repair with mesh**  for reducible symptomatic [[Inguinal Hernia]]. He is seen in clinic 10 days postoperatively and is noted to have **erythema, swelling, and some drainage at his surgical site**. What pathogens are most likely involved?
?
Gram-positive cocci
*[[Staphylococcus aureus]] is commonly seen in post-operative [[Inguinal Hernia]] repair mesh infections involving formation of biofilms.*

[Blocks 5 and 6] 65/M presents with **3-day history of fever, chills, and RUQ pain**. He is otherwise healthy and gives a **history of prior [[Cholecystectomy]]** in the distant past. On PE, he is **not jaundiced**. He is **febrile, tachycardic, and has significant tenderness over the RUQ**. He denies any history of alcohol use or recent travel. An ultrasound is obtained and shows a **hypoechoic intrahepatic lesion**. The most likely diagnosis is?
?
Pyogenic [[Hepatic Abscess]]
*Pyogenic liver abscess presents with fever with chills, jaundice, and RUQ pain. The most common route for infection is biliary sepsis. The history of [[Cholecystectomy]] is a possible cause for the formation of the pyogenic liver abscess.*

[Blocks 1 and 5] Which of the ff. is true regarding [[Hepatocellular Carcinoma]]?
A. Majority of cases arise in patients with chronic liver disease
B. Incidence of HCC has been declining over the last 2 decades
C. Hepatitis A is more likely to lead to HCC than Hepatitis B
D. Most patients are asymptomatic at the time of diagnosis
?
A. Majority of cases arise in patients with chronic liver disease
*Hepatitis B and C more commonly result in HCC (C is wrong). Incidence has been increasing in the past decades (B is wrong). Patients with HCC are usually symptomatic from chronic liver disease (D is wrong)*

[Blocks 1 and 5] Which of the ff. findings is not a usual sign of obstructive jaundice secondary to choledocholithiasis?
A. Yellowish discoloration of mucosa
B. Acholic stools
C. Tea-colored urine
D. Icteric sclera
?
A. Yellowish discoloration of mucosa
*B, C, and D are seen with obstructive jaundice. Acholic stools happen because bile does not enter the intestines to become [[Stercobilinogen]] that colors stool. Urine becomes tea-colored because bilirubin goes into the systemic circulation to become [[Urobilinogen]]. Icteric sclera is seen with patients who have [[Jaundice]]*

[Blocks 3 and 5] 47/F asymptomatic is incidentally found to have a **5-mm polyp and no stones** in her gallbladder on ultrasound examination. Which of the ff. is the best management option?
A. Open cholecystectomy with frozen section
B. Observation with repeat ultrasound examinations to evaluate increase in polyp size
C. Requires for abdominal CT scan to characterize polyp
D. Laparoscopic cholecystectomy
?
B. Observation with repeat ultrasound examinations to evaluate increase in polyp size
*Ultrasound is the best available exam for gallbladder polyps. CT scan can only detect low density lesions and sensitivity for diagnosis is not enough to warrant routine use. As the patient is not symptomatic, no concurrent gallstones, and a diameter < 6 mm, there is no need for surgery/cholecystectomy*

[Blocks 5 and 6] 56/M smoker consults the clinic with **5-year history of right inguinal bulge which enlarged when lifting or on exertion and reduces when supine**. On PE, there is a note of dilated external ring with **palpable impulse** on the dorsum of the examining finger on exertion. What is the pathophysiology for this type of hernia?
?
Weakness of the abdominal wall musculature
*[[Inguinal Hernia]] is the most common type of hernia due to the weakness of the inguinal regions' muscular anatomy and the natural weakness of the deep ring and cord structures.*

[Blocks 4 and 5] Which of the ff. is the best indication for preoperative ERCP in a patient with [[Gallstones]]?
A. 3-mm CBD seen on ultrasonography
B. Alkaline phosphatase elevated twice the normal
C. Obstructive jaundice
D. Gallstone pancreatitis
?
C. Obstructive jaundice
*3 mm is not dilated enough to warrant an ERCP. Alkaline phosphatase levels are non-specific and has many causes for its elevation. ERCP can worsen [[Pancreatitis]]*

[Blocks 4 and 5] 62/F has **swelling in inguinal region of 1 year duration**. On PE, there is **reducible swelling** below the inguinal ligament lateral to the pubic tubercle. Which of the ff. is the next best step in management?
A. Watchful waiting
B. Pelvic CT scan
C. Shouldice repair
D. Mesh repair of femoral canal
?
D. Mesh repair of femoral canal
*As the swelling is below the inguinal ligament and lateral the pubic tubercle and the patient is female, a femoral hernia is suspected. There is no alternative to surgery for femoral hernia and should be treated with urgency.*

[Blocks 5 and 6] 70/M **previous construction worker** consults at GS3 OPD for **inguinoscrotal bulge** that he notices more during **prolonged standing or walking**. Past medical history revealed **previous surgery for vehicular crash** and intake of medications for **benign prostatic enlargement**. What is your diagnosis?
![[04 Hepatobiliary, Pancreatic, and Hernia Surgery-1669109327668.jpeg]] ![[04 Hepatobiliary, Pancreatic, and Hernia Surgery-1669109338702.jpeg]]
?
Indirect inguinal hernia
*An indirect [[Inguinal Hernia]] presents with dragging pain and swelling in the groin better seen while coughing and standing.*

[Block 1] A 36-year-old man has **1 week history of fever, RUQ pain, and diarrhea**. He has **chills and profuse sweating** at night. PE reveals **hepatomegaly**. Abdominal CT scan shows **well-rounded hypoattenuating lesion with thickened capsule** in the right lobe of the liver. Which of the following is correct regarding this condition?
A. This condition needs a course of Metronidazole treatment
B. This condition requires percutaneous drainage for treatment
C. Corticosteroids decrease the risk of progression of this condition
D. This condition is a disease of elderly patients
?
A. This condition needs a course of Metronidazole treatment
*A single liver abscess is likely caused by [[Entamoeba histolytica]]. The infection usually occurs in the right lobe spreading through the portal veins. On CT, they appear as peripherally enhancing, centrally hypoattenuating lesions*

[Block 1] A 39-year-old woman presents for further evaluation of a recently diagnosed **3-cm hepatic lesion found incidentally on abdominal ultrasound** performed to rule out cholelithiasis. Based on the imaging features, the lesion appears to be a **hepatic adenoma**. She is taking **oral contraceptives**. On discussion with the patient, it should be mentioned that hepatic adenomas, although typically benign, could potentially present with which of the following life-threatening events?
A. Portal vein thrombosis
B. Compression of the vena cava
C. Pulmonary embolus
D. Intraabdominal hemorrhage
?
D. Intraabdominal hemorrhage
*[[Hepatic Adenoma]] are prone to bleeding and may undergo malignant transformation.*

[Block 1] Which of the following patients has the greatest chance of having gallstones?
A. 30/M seaman with a 9-month contract to work on a cruise ship
B. 18/M obese gamer who spends 6 hours a day sitting in front of a computer
C. 35/F vegan fitness instructor
D. 45/F obese housewife on oral contraceptives
?
D. 45/F obese housewife on oral contraceptives
*Predisposing factors for [[Gallstones]] include cholesterol supersaturation, stasis, and increased [[Bilirubin]] secretion. Estrogen is also implicated as it increases cholesterol production in the liver and Progesterone reduces gallbladder motility.*

[Block 1] Imaging modality of choice for patient with known gallbladder polyp for surveillance is?
?
Ultrasound

[Block 1] You see a patient in the clinic with **asymptomatic gallstones**. In which of the following situations should you consider cholecystectomy for this patient?
A. The patient has sickle cell anemia
B. The patient recently has lost 50 pounds
C. All patients with gallstones should have a cholecystectomy
D. The patient is a 40-year-old woman who has had four children and is obese
?
A. The patient has sickle cell anemia
*Cholecystectomy for asymptomatic gallstones is done with large [[Gallstones]], non-functioning [[Gallbladder]], [[Spinal Cord Injury]], or with [[Sickle Cell Disease]]*

[Block 1] A 50/F stockbroker has a **2-year history of epigastric pain, described as a burning sensation that would subside in 4 days at least once every month**. Lately, she also describes **occasional intermittent right upper quadrant pain** that is described as sharp with **radiation to the right upper back and shoulder**. Which among the statements are true? (2023)
A. The patient developed gallstones as a result of the acidification of the stomach from the peptic ulcer disease
B. The patient has concurrent peptic ulcer disease and calculous cholecystitis that occurs in approximately 10- 20% of the population
C. Surgery that combines cholecystectomy and vagotomy is the surgical treatment of choice for this patient
D. Concomitant H. pylori infection with the peptic ulcer disease is a risk factor for gallstone formation
?
B. The patient has concurrent peptic ulcer disease and calculous cholecystitis that occurs in approximately 10- 20% of the population
*Gallstones are not linked with acidification of the stomach. [[Peptic Ulcers]] are treated medically and does not involve [[Vagotomy]]. Pigment stones are formed from bacterial or parasitic infections not H. pylori*

[Block 1] A patient with known history of **sclerosing cholangitis has 6-month history of painless jaundice**. **CA 19-9 is elevated**. CT scan shows **dilation of the intrahepatic bile ducts, gallbladder, and extrahepatic bile ducts down to the level of the pancreatic head**. MRCP shows **focal stricture in the lower portion of the common bile duct**. Staging and metastatic workup reveal **resectable** disease. What is the most appropriate treatment for this patient?
A. Common bile duct excision and hepaticojejunostomy
B. Liver transplant
C. Partial hepatectomy
D. Pancreaticoduodenectomy
?
D. Pancreaticoduodenectomy
*The elevation of [[CA 19-9]] is seen with [[Pancreatic Cancer]]. Sine the cancer is resectable, a Whipple should be performed (pancreaticoduodenectomy)*

[Block 1] Regarding diagnostics in patients with inguinal hernias, which of the following statements is correct?
A. An inguino-scrotal ultrasound can help differentiate the contents of the hernia
B. An inguinal hernia is a clinical diagnosis and further imaging is not needed prior to surgical intervention
C. CT scan and MRI of the inguinal area are contraindicated in patients with incarcerated inguinal hernias
D. A finger occlusion test can help differentiate between and indirect or femoral hernia
?
A. An inguino-scrotal ultrasound can help differentiate the contents of the hernia
*Further imaging is needed prior to surgical intervention. CT and MRI can be done in incarcerated hernias. Finger occlusion tests differentiates direct and indirect hernias*

[Block 1] A healthy 42-year-old man presents to your clinic referred by his primary care provider for a **palpable groin bulge**. He **denies symptoms of obstruction and significant impact on his activities**. On examination he has a **small, reducible left inguinal hernia**. What will you advise him regarding his risk of acute incarceration if his hernia is not repaired over the next 2 years?
A. He may have the surgery after 2 years as the risk increases after this time
B. He should undergo a mesh hernioplasty as soon as possible because of very high risk of incarceration
C. There is moderate risk of incarceration and it is his choice whether to have the surgery or not
D. Asymptomatic inguinal hernias can be safely observed as they have a low risk of incarceration
?
D. Asymptomatic inguinal hernias can be safely observed as they have a low risk of incarceration
*Symptomatic hernias are operated on electively. Asymptomatic and minimally symptomatic hernias are managed through watchful waiting.* 

[Block 1] A patient undergoes **mesh repair of inguinal hernia**. The surgeon encounters a **loop of small intestine protruding lateral to the inferior epigastric artery and vein on that side**. This type of hernia is most likely the result of which of the following?
A. Weakness of the conjoint tendon
B. Diastasis of small muscle fibers
C. Patent processus vaginalis
D. Congenital abscess of the iliopubic tract
?
C. Patent processus vaginalis
*Indirect hernias protrude lateral to inferior epigastric vessels. Failure of the [[Peritoneum]] to close keeps the [[Processus Vaginalis]] patent such that indirect hernias can happen at the site*

[Block 1] Which of the following is an absolute contraindication to laparoscopic inguinal hernia repair?::The only absolute contraindication would be the **inability to tolerate general anesthesia**

[Block 1] A patient with strangulated left inguinal hernia undergoes ileal resection with double-barrel ileostomy. Intraoperatively, the **bowels were frankly necrotic with purulent discharge within the hernia sac**. What is the patient’s wound classification?
?
Dirty
*Dirty wound classification is given for cutting into actively infected sites* 



