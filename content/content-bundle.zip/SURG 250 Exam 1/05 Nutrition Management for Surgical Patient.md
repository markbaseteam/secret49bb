---
banner_icon: 📝
tags: flashcards, SURG250
type: Exam
date: 2022-11-22
---
[Blocks 3 and 6] 79/M developed **acute abdominal pain, fever, tachycardia, hypotension**. CXR reveals **pneumoperitoneum** and taken to OR where a **right hemicolectomy and end ileostomy** is performed for R colon perforation. He has lost 40 lbs unintnetionally over past 3 months and his BMI is 34. His albumin is 1.2 g/dL and prealbumin is 14.3 mg/dL. He remains intubated in ICU with continued vasopressor requirement for hypotension. When would you initiate nutritional support for this patient?
?
Start [[Parenteral Nutrition]] immediately postoperatively
*Patient is malnourished and must be provided [[Nutrition Therapy]] but as he is intubated, parenteral route should be used*

[Blocks 5 and 6] Which of the ff. statements regarding surgical nutrition is true?
A. The best period to address malnutrition is the postoperative period, when the surgical disease has been addressed
B. When surgical patients are put on NPO, total parenteral nutrition is warranted
C. All surgical patients must be screened for nutrition status
D. All surgical patients are considered nutritionally at risk
?
C. All surgical patients must be screened for nutrition status
*The preoperative period is the best period to address malnutrition (A is wrong). NPO means nil per orem (fasting) thus, total parenteral nutrition is unwarranted (B is wrong). Surgical patients must undergo screening to determine if they are at risk (C is right and D is wrong).*

[Blocks 1 and 5] Which of the ff. is the most appropriate method for nutrition for a patient with [[Acute Pancreatitis]] and a concern for [[Aspiration Pneumonia]]?
A. Peripheral IV line - peripheral parenteral nutrition
B. Central line - total parenteral nutrition
C. Nasogastric tube - enteral tube feeds
D. Nasojejunal tube - enteral tube feeds
?
D. Nasojejunal tube - enteral tube feeds
*Enteral nutrition is still preferred over parenteral nutrition. Considering that the patient's condition affects the pancreas, the route should bypass this thus, D is the best choice*

[Block 1] Which of the following patients would benefit from early administration of parenteral nutrition?
A. A 43-year-old man with Crohn disease who has had multiple abdominal surgeries, most recently 3 days ago, who has 90 cm of small bowel remaining
B. A 65-year-old man who has postoperative ileus 2 days after a 10-cm small bowel resection with anastomosis
C. A previously well-nourished man who has been nothing by mouth (nil per os [NPO]) for 2 days and is being managed conservatively for small bowel obstruction
D. A 75-year-old man who is malnourished secondary to dysphagia
?
A. A 43-year-old man with Crohn disease who has had multiple abdominal surgeries, most recently 3 days ago, who has 90 cm of small bowel remaining
*[[Parenteral Nutrition]] is reserved for those with nonfunctional GIT. [[Enteral Nutrition]] is preferred for most patients*

