---
banner_icon: 📝
tags: flashcards, SURG250
type: Exam
date: 2022-11-22
---
[Blocks 1, 2, 3, 4, and 6] 47/F presents to the clinic with **isolated left IV palpable LN**. It has been present for the past **2 months and is unchanged in size**. She has a history of [[Total Thyroidectomy]] for **papillary thyroid cancer**. What is the recommended diagnostic modality?
?
Ultrasound-guided [[Fine Needle Aspiration Biopsy]]
*Cervical ultrasound is used to evaluate the thyroid bed and central and lateral cervical nodal compartments 6 and 12 months post-thyroidectomy and then annually for ≥3-5 years depending on the risk for recurrence. Sonographically suspicious nodes ≥8-10 mm should be biopsied for cytology with Tg measurement in the aspirate washout*

[Blocks 1 and 4] 50/F presented with **5x5 cm anterior neck mass** that **moves with deglutition**. She was eventually diagnosed to have **well-differentiated thyroid CA**. CXR revealed **multiple lung nodules**. The therapeutic management for this case is?
?
[[Total Thyroidectomy]] + Adjuvant radioactive iodine (RAI) ablation
*A thyroid mass that is >4 cm necessitates a total thyroidectomy. Patients with large, locally aggressive, or **metastatic** differentiated thyroid cancers like the patient also needs RAI ablation to go with the total thyroidectomy for the patient.*

[Blocks 1, 4, and 5] 50/F with **asymptomatic left thyroid nodule** measuring **1.2 cm** on ultrasound. **No prior history of neck radiation**. TSH is normal. FNA shows **Bethesda IV** classification. What is the next appropriate step?
?
Thyroid [[Lobectomy]]
*A Bethesda IV thyroid nodule is suspicious for follicular neoplasm and the suggested treatment prior to availability of molecular testing would be lobectomy.*

[Blocks 5 and 6] 45/F comes into the office with complaints of **lump she found on her neck** while showering. She denies any other symptoms and states she has not gained any weight. On exam, you notice a **2-cm nodule on her anterior neck**. Her TSH is normal and radionucleotide scan reveals a **cold nodule**. FNAB reveals **follicular architecture suspicious for malignancy**. What is the next best step?
A. Schedule for elective thyroid surgery
B. Request for thyroid and neck ultrasound
C. Prescribe thyroxine administration
D. Request for head and neck CT scan
?
A. Schedule for elective thyroid surgery
*Considering the architecture, this is likely a Bethesda IV nodule and the suggested management would be a lobectomy.*

[Blocks 1 and 5] 35/M presents with **solitary left cervical LN** that is mobile on examination. It has been present for **4 months and slowly increasing in size**. What is the best initial imaging modality?
?
Thyroid and neck ultrasound
*Considering that the neck structures are highly sensitive to radiation, radiography and CT should not be initial imaging modalities. Ultrasound is the best choice for initial imaging of head and neck structures even though MRI is also capable as it is costly and may not identify intranodal calcifications seen with metastatic nodes in thyroid CA.*

[Blocks 3, 5, and 6] 70/M present with **left preauricular mass, 6 x 5 cm**  associated with **trismus**. The best management strategy for this patient will be?
?
[[Fine Needle Aspiration Biopsy]]
*To be able to determine the appropriate management for the mass, a biopsy must be done. [[Core Needle Biopsy]] is not usually used for HEENT tumors.*

[Blocks 5 and 6] 42/F underwent **thyroid lobectomy** for a large nodule causing **compressive symptoms**. FNAB preoperatively showed a **benign colloid nodule**. What is the next step in treatment?
?
No further treatment
*The main indication for surgery in benign disease is compressive symptoms. Since the nodule has been managed, there is no need for further treatment.*

[Block 1] A 62-year-old man presents for evaluation of a **solitary neck mass**. On examination, you note a **firm, 2-cm level II lymph node**. The man’s history is **significant for a 40 pack-year smoking history** and **alcohol use of four beers per day**. What is the most likely cause of this neck mass?
?
Metastatic
*Considering that the patient has a history of tobacco and alcohol use, the mass is likely malignant in nature*

[Block 1] A 53-year-old man presents to your clinic with a **right-sided neck mass** that he noticed a few weeks ago when shaving his neck. He otherwise **denies fever, difficulty breathing, voice change, dysphagia, odynophagia, or unexpected weight loss**. He reports that he drinks **two to three glasses of wine per week**. Although he has a **history of infrequent marijuana use**, he otherwise denies ever smoking cigarettes or using tobacco products. After completing a thorough in-office head and neck examination, what is the next best course of action?
A. Noncontrast CT scan of the neck
B. Empiric 2-week course of antibiotics to cover aerobic and anaerobic bacteria
C. CT scan of the neck with IV contrast and empiric antibiotic course
D. CT scan of the neck with IV contrast and fine needle aspiration biopsy
?
D. CT scan of the neck with IV contrast and fine needle aspiration biopsy
*There is high chance for thyroid malignancy. [[CT Scan]] can be used to differentiate benign and malignant lesions of the thyroid and the [[Fine Needle Aspiration Biopsy]] is needed for definitive diagnosis*

[Block 2] A 50/ F patient presented with a **5x5cm anterior neck mass** that **moves with deglutition**. To determining if this mass is **hyperfunctioning**, the best laboratory test/s to be requested is/are
A. free T4 and TSH
B. anti-thyroglobulin antibodies
C. thyroglobulin (Tg)
D. free t3 and TSH
?
A. free T4 and TSH
*TSH and T4 are usually the hormones affected when there is abnormal functioning of the thyroid*

[Block 2] A 40-year-old woman is coming for her follow-up appointment after **total thyroidectomy**, **central neck dissection**, and **left lateral neck dissection** for **papillary thyroid cancer**. Her final pathology was consistent with **multifocal disease (largest tumor, 4cm), gross extrathyroidal extension, and 3 of 44 nodes positive for metastatic disease**. One of the nodes was 3.5cm. How would you risk-stratify this patient for persistent/recurrent disease after surgery?
A. She is at no risk for recurrence or persistent disease
B. She is high risk for persistent/ recurrent disease.
C. She is intermediate risk for disease recurrence and persistent disease.
D. She is low risk for disease recurrence and persistent disease.
?
B. She is high risk for persistent/ recurrent disease.
*Since the patient has multifocal disease and metastatic disease, there is high risk for recurrence or persistence post-operatively*

[Block 2] A 25 year old healthy woman present with a **solitary, enlarged left neck mass** that has been present for the past week. She reports **associated cough, rhinorrhea, and fever/chills with general malaise**, which began before she noticed the neck mass. The neck mass is **mobile, and tender to palpation** with some overlying skin erythema. She has **pharyngeal exudates and SARS-COV 2 swab is negative**. According to current guidelines, you still recommend isolation. What is the next best step in management of the neck mass?
A. Fine needle aspiration biopsy with empiric oral antibiotics while awaiting biopsy results
B. Observation for 2 or 4 weeks to ensure resolution of the mass
C. A course of oral antibiotics with observation for 2 to 4 weeks for complete resolution
D. Request for thyroid and neck ultrasound with empiric oral antibiotics.
?
A. Fine needle aspiration biopsy with empiric oral antibiotics while awaiting biopsy results
*Considering the rhinorrhea, fever, and chills, it is likely that this is caused by an infection possibly [[Pharyngitis]]. The FNAB can help in identifying the cause of the problem*

[Block 2] A 65 year old woman, a current smoker, presents with a **large, painless, slowly enlarging right sided parotid mass**. On examination, the physician is concerned because she felt a **smaller parotid mass on the contralateral side as well**. The patient does not have any signs of facial nerve weakness. Fine needle aspiration of the gland yields **acellular fluid and a pathologic diagnosis cannot be made**. What is the most likely diagnosis?
A. Pleomorphic adenoma
B. Benign bilateral papillary cystadenoma lymphomatosum
C. Malignant bilateral adenoid cystic carcinoma
D. Metastasis from oral squamous cell carcinoma
?
B. Benign bilateral papillary cystadenoma lymphomatosum
*Acellular fluid can rule out the carcinoma and adenoma. Cystadenoma is the likely diagnosis as they are usually mucous filled thus explaining the lack of cells on biopsy*

[Block 2] A 35-year-old presents with a **solitary back mass, which was hot, moveable, and nontender**. It currently measures **4 cm and has been present for 4 years, slowly increasing** in size. The best advice to the patient is:
A. Chest x-ray
B. Excision under local anesthesia 
C. Ultrasound
D. MRI
?
B. Excision under local anesthesia
*Considering that the mass has been there for a long time and it is slowly progressing, analysis through excision of the mass is the best way to manage the patient*

