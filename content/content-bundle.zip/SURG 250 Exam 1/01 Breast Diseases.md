---
banner_icon: 📝
tags: flashcards, SURG250
type: Exam
date: 2022-11-22
---
[Blocks 2 and 4] 38/F 2-cm mass in R breast. Lymph nodes are not palpable. Biopsy reveals [[Invasive Ductal Carcinoma]]. Past medical history includes [[Scleroderma]] and [[Diabetes Mellitus]]. What is the most appropriate initial treatment?
?
Total mastectomy with [[Sentinel Lymph Node Biopsy]]
*Total mastectomy is done for DCIS when there is a positive margin after wide local excision, ≥2 primary tumors, **radiation is not possible (collagen disease like scleroderma)**, tumor:breast size is not appropriate for conservative surgery, and pregnancy* 

[Blocks 3 and 6] 49/F with **10 cm** R breast mass associated with **skin ulceration**. No palpable axillary lymph nodes. Biopsy reveals invasive [[Breast Carcinoma]] ER(+), PR(+), and Her2(+). Metastatic work-up was negative for distant metastasis. Best management for this patient is?
?
Neoadjuvant Chemotherapy
*Patient has a big breast mass and neoadjuvant chemotherapy can reduce the size to make it amenable for surgical resection (usually after 3 doses) and [[Breast Conservation Surgery]] or early systemic control.*

[Blocks 3 and 6] 40/F with 1 year history of L breast mass. Presents to clinic with **12 cm** breast mass in outer quadrants, movable with areas of ulceration around 4 cm. No palpable axillary LNs. Wedge biopsy shows **fibroepithelial lesion**. Next step for management is?
?
Total Mastectomy
*Fibroepithelial lesion and large tumor size makes it likely that this is a [[Phyllodes Tumor]]. The management is usually wide local excision or total mastectomy. Considering its size, total mastectomy is the most likely management for the patient*

[Blocks 1 and 5] Which of the ff. is true regarding [[Lobular Carcinoma In Situ]]?
A. Benign disease hence does not require excision
B. Associated with increased risk of breast CA in ipsilateral and contralateral breast
C. Pre-malignant lesion hence should be excised completely
D. Associated with increased risk of breast CA hence mastectomy should be performed
?
B. Associated with increased risk of breast CA in ipsilateral and contralateral breast
*LCIS used to be considered stage 0 for breast CA but has recently been recategorized to a purely benign lesion. However, it poses increased risk for developing invasive breast CA that requires resection*

[Blocks 2 and 5] F presenting with core biopsy of **enlarging 2-cm breast mass** demonstrating **high-grade [[Phyllodes Tumor]]** with **sarcomatous change**. Which is the best management for the patient?
A. Excision with negative margins of ≥1 cm
B. Axillary LN Biopsy
C. Mastectomy
D. Postoperative radiation therapy
?
A. Excision with negative margins of ≥1 cm
*Sarcomatous change indicates a possible malignant tumor thus requiring complete excision with a 1-cm margin of normal appearing breast tissue. Axillary lymph node biopsy is not needed as they rarely metastasize and mastectomy is not needed as it is a relatively small tumor. Post-operative radiation is not required. (Schwartz)*

[Blocks 4 and 5] You are evaluating a patient in the breast clinic for **postoperative surveillance**. She underwent **partial mastectomy and [[Axillary Lymph Node Dissection]]** 6 months ago for **cT2N1 triple-negative** [[Invasive Ductal Carcinoma]] treated with **neoadjuvant chemotherapy**. She has since completed **adjuvant radiation therapy**. On examination, her mastectomy flaps are healthy and there is no underlying nodularity. You do not palpate any masses in the axilla nor do you note any fluctuance. However, you note **swelling of her arm** which she states has been present and worsening since she last saw you postop. What is her most likely diagnosis?
?
Lymphedema
*The most common cause for secondary lymphedema in the US is stated to be [[Axillary Lymph Node Dissection]] causing lymphedema of the arm. It can also be from radiation therapy and malignancy.*

[Block 1] A 53-year-old postmenopausal woman presents with a **1.5-cm right breast mass that is well defined, rubbery, and mobile on examination**. She has a similar palpable mass in the contralateral breast. She has a strong family history of breast cancer in three first-degree relatives. Core needle biopsy of the right breast mass reveals a **benign fibroepithelial lesion favoring fibroadenoma with a small focus of atypical ductal hyperplasia**. Which of this patient’s clinical characteristics is commonly associated with fibroadenoma?
?
Well-defined, mobile, rubbery mass on examination
*Simple [[Fibroadenoma]] is a benign solid mass typically seen with **young women**, often detected as **solitary breast masses that are 1-2 cm***

[Block 1] A 52 y.o. woman presents with **swollen right breast and nipple retraction**. Mammogram reveals a **BIRADS 4 lesion which is 2 cm in size**. Biopsy reveals carcinoma with **dermal lymphatic invasion**. The most likely diagnosis is?
?
Inflammatory [[Breast Carcinoma]]
*Dermal lymphatic invasion is a characteristic of inflammatory breast carcinoma*

[Block 1] A 45 y.o. female with **large, pendulous breast has a painless 4 cm mass** in left breast that is **smooth, firm and mobile**. Core needle biopsy reveals **stromal overgrowth with atypia and high mitotic rate**. What is the next best step in the management of this patient?
?
Wide local excision
*The case features a [[Phyllodes Tumor]] due to the stromal content. As there is evidence of atypia and high mitotic rate, it is suspected to be malignant and must be managed through wide local excision.*

[Block 1] A 25 y.o. breastfeeding patient complains of **painful right breast associated with fever and chills**. On PE, a 5 cm fluctuant, tender mass is palpable in the upper medial quadrant of right breast. The **overlying skin is intact with no nipple discharge**. Ultrasound shows **unilocular abscess**. What is the next step in treatment?
?
Ultrasound-guided [[Needle Aspiration]]
*Breast abscesses are managed with antibiotics, warm compression, incision and drainage with preoperative ultrasound to delineate extent of the drainage*

[Block 1] A 45 y.o. patient has **non-cyclical bilateral breast pain and tenderness**. She is not on any maintenance meds and has no family history of breast cancer. On PE, she has **several small, scattered lumps and palpable cords bilaterally but no large masses or lymphadenopathy** is found. Which of the following diagnostics should be requested?
?
[[Mammography]]
*Mammography is the best diagnostic to screen for [[Breast Carcinoma]] considering the non-cyclical nature of the disease and multiple lumps palpated. Ultrasound and MRI will only serve as adjuncts for mammography*

[Block 1] A 75-year-old woman undergoes stereotactic core needle biopsy of a **1.4-cm nodular architectural distortion only seen on mammography**. Which biopsy result found on her pathology report increases her breast cancer risk the most?
A. Apocrine metaplasia
B. Sclerosing adenosis
C. Ductal hyperplasia without atypia
D. Atypical ductal hyperplasia
?
D. Atypical ductal hyperplasia
*Atypical ductal or lobular hyperplasia have a four-fold increase for [[Breast Carcinoma]] risk.*
![[01 Breast Diseases-1669129164127.jpeg]]

[Block 2]A 55 year old woman with **no history of breast cancer** has a screening mammogram that shows a **5-mm new group of pleomorphic calcifications**. A core needle biopsy is performed, demonstrating **atypical ductal hyperplasia and sclerosing adenosis**. Which of the following best describes management of these findings?
A. Repeat mammogram to check if lesions are still present
B. Recommend excision biopsy
C. Order breast ultrasound to investigate if a mass is present to correlate with biopsy findings
D. Recommend bilateral risk-reducing mastectomies by age 60
?
B. Recommend excision biopsy
*Atypical hyperplasia represents transition into malignant disease thus, the management is excisional biopsy*

[Block 2] A 50-year-old woman is at the Breast Care Center for follow up. She has just **undergone a right total mastectomy, sentinel node biopsy, and immediate reconstruction** with an autologous tissue flap for a **2-cm node-negative, hormone receptor-positive, invasive ductal carcinoma**. How will you advise her for cancer surveillance?
A. Physical examination of the right reconstructed breast every 6 months with annual magnetic resonance imaging and mammography of both the reconstructed right breast and left breast for 5 years
B. Physical examination of the reconstructed right breast and left breast every 6 months, with bilateral mammography and magnetic imaging annually for 5 years.
C. Physical examination of the reconstructed right breast and left breast every 6 months for 5 years and annually thereafter, with annual mammography of the left breast.
D. Physical examination and annual mammography of both the reconstructed right breast and left breast, with chest CT scan and liver ultrasound for 10 years.
?
C. Physical examination of the reconstructed right breast and left breast every 6 months for 5 years and annually thereafter, with annual mammography of the left breast.
*Examination of the breasts is important to monitor for growth of new masses or other breast findings. Mammography is enough for screening and follow-up*

[Block 2] Mammography is indicated as initial evaluation in all the following situations EXCEPT
A. 45-year-old; breasts with multiple nodules but no dominant area
B. 38-year-old; complaining of breast pain, large fatty breasts without palpable nodules
C. 40-year-old, S/P MRM right for carcinoma, as surveillance of the opposite breast
D. 24-year-old; complaining of solitary, palpable, firm, moveable mass
?
D. 24-year-old; complaining of solitary, palpable, firm, moveable mass
*The young age of the patient and the characteristic of the mass makes it likely that it comes from [[Fibrocystic Changes]] which can be managed with assurance and pain relievers*

[Block 2 and 3] A 42/F presents with a **5 cm right bright mass** associated with [[Peau d'orange]]. CNB revealed **invasive breast CA, ER (+), PR (+). Her2 (+1)**. Metastatic work-up was **negative for distant metastasis**. The next best step in the management of this patient is:
A. Neoadjuvant chemotherapy
B. Total Mastectomy with Sentinel Lymph node biopsy
C. Neoadjuvant chemotherapy + Trastuzumab
D. Modified radical mastectomy
?
A. Neoadjuvant chemotherapy
*The breast mass is relatively large and chemotherapy can help downstage the tumor for [[Breast Conservation Surgery]]. [[Trastuzumab]] is not needed as 1+ is Her2 negative*

[Block 2] A 24/F consults at the Breast Clinic for **premenstrual breast pain and feeling of heaviness**. She also reports **occasional nodularities in both her breasts** or areas of lumpy tissue. There is **no family history of cancer**, and she has **not had any breast imaging done**. What is the most probable diagnosis and appropriate advise?
A. No diagnosis can be made without imaging. Request for breast ultrasound
B. She may have early breast cancer. Request mammogram ASAP
C. She presents with fibrocystic changes of the breast. Prescribe pain medications and give assurance
D. She has multiple fibroadenomas. Excision of all nodules is warranted
?
C. She presents with fibrocystic changes of the breast. Prescribe pain medications and give assurance
*Premenstrual cyclical mastalgia is indicative of [[Fibrocystic Changes]]. They may present as bilateral alterations of texture*

[Block 2] A 60-year-old relative approaches you and inquires about a **5 cm palpable hard breast mass in her right breast**. What is the most important diagnostic procedure that she should undergo?
A. Chest radiography
B. Core needle biopsy
C. Breast ultrasonography
D. Mammography
?
B. Core needle biopsy
*Since the mass is large and hard, [[Core Needle Biopsy]] is advised to get a sample for diagnosis*

[Block 2] A 46/F is found to have a **3 cm, firm, smooth mass** in the upper outer quadrant of the breast. A screening **mammogram done 3 months ago showed normal findings**. A breast ultrasound done last week showed a **solitary cystic lesion**. The appropriate management at this time is
A. Aspiration
B. Excision of the cyst
C. Administration of estrogen
D. Repeat mammogram
?
A. Aspiration
*Management for a breast cyst is [[Needle Aspiration]]. It provides both diagnosis and treatment for the condition. Biopsy is only needed if there is a residual mass or recurrence of cysts*

[Block 3] A 43/F consulted for a **2 cm right breast mass which on UTZ-guided core needle biopsy** showed **mucinous CA**. No other significant PE findings. The next step most appropriate for this patient is?
A. Do metastatic work-up
B. Partial mastectomy
C. Lumpectomy with sentinel node biopsy
D. Neoadjuvant chemotherapy if patient is desirous of breast conservation treatment.
?
C. Lumpectomy with sentinel node biopsy
*Metastatic work-up is not needed as [[Mucinous Carcinoma]] is relatively less aggressive and portends better prognosis. Neoadjuvant chemotherapy is not necessary as the mass is small enough to allow for wide local excision.*

[Block 3] 

